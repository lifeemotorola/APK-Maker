#!/usr/bin/env python3
"""
Builds docs/NewsDesk-Studio-Guide.pdf — the step-by-step install & use guide.

Content lives here as HTML; Chromium renders it to PDF so typography, page breaks
and embedded screenshots stay crisp. Run:  python3 guide/build_guide.py
"""
import base64
import os
import re
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
SHOTS = ROOT.parent / "guide" / "shots"
OUT = ROOT / "docs" / "NewsDesk-Studio-Guide.pdf"


OPT = SHOTS.parent / "opt"


def img(name, cls="shot"):
    """Prefer the optimised JPEG; fall back to the raw PNG for development."""
    jpg = OPT / name.replace(".png", ".jpg")
    png = SHOTS / name
    path = jpg if jpg.exists() else png
    if not path.exists():
        raise SystemExit("missing screenshot: %s" % path)
    mime = "image/jpeg" if path.suffix == ".jpg" else "image/png"
    b64 = base64.b64encode(path.read_bytes()).decode()
    return '<img class="%s" src="data:%s;base64,%s" alt="">' % (cls, mime, b64)


CSS = """
@page { size: A4; margin: 17mm 13mm 16mm 13mm; }
* { box-sizing: border-box; }
body{
  font-family: "DejaVu Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
  color:#1d2733; font-size:10.4pt; line-height:1.62; margin:0;
  -webkit-print-color-adjust: exact; print-color-adjust: exact;
}
h1,h2,h3,h4{ font-family:"DejaVu Sans", Helvetica, Arial, sans-serif; margin:0; }

/* ---------- cover ---------- */
.cover{
  height:250mm; display:flex; flex-direction:column; justify-content:center;
  page-break-after:always; position:relative; overflow:hidden;
}
.cover .rule{ width:64mm; height:4px; background:#E01B22; margin-bottom:10mm; }
.cover .kicker{ font-size:9.5pt; letter-spacing:.34em; text-transform:uppercase;
  color:#8b6a1f; font-weight:700; margin-bottom:6mm; }
.cover h1{ font-size:38pt; line-height:1.06; letter-spacing:-.02em; font-weight:800;
  color:#0B1522; margin-bottom:6mm; }
.cover h1 span{ color:#E01B22; }
.cover .sub{ font-size:13pt; color:#4b5b6e; line-height:1.5; max-width:120mm; margin-bottom:13mm; }
.cover .who{ border-top:1px solid #d9e0e9; padding-top:6mm; font-size:10.5pt; color:#41505f; }
.cover .who b{ color:#0B1522; font-size:12pt; display:block; margin-bottom:1mm; }
.cover .badge{ display:inline-block; background:#0B1522; color:#fff; font-size:8.5pt;
  letter-spacing:.2em; text-transform:uppercase; padding:2.6mm 4mm; border-radius:2mm;
  margin-bottom:10mm; font-weight:700; }
.cover .foot{ position:absolute; bottom:0; font-size:9pt; color:#7b8a9b; }

/* ---------- structure ---------- */
h2.section{
  font-size:19pt; font-weight:800; color:#0B1522; letter-spacing:-.01em;
  margin:0 0 2mm; padding-bottom:3mm; border-bottom:2.5px solid #E01B22;
  page-break-after:avoid;
}
.sec-num{ display:inline-block; background:#E01B22; color:#fff; font-size:10pt; font-weight:800;
  width:8.5mm; height:8.5mm; line-height:8.5mm; text-align:center; border-radius:1.5mm;
  margin-right:3mm; vertical-align:2px; }
h3{ font-size:12.5pt; font-weight:700; color:#0B1522; margin:7mm 0 2mm; page-break-after:avoid; }
h4{ font-size:10.5pt; font-weight:700; color:#2b3947; margin:5mm 0 1.5mm; page-break-after:avoid; }
p{ margin:0 0 3mm; }
ul,ol{ margin:0 0 3.5mm; padding-left:6mm; }
li{ margin-bottom:1.6mm; }
code{ font-family:"DejaVu Sans Mono", Consolas, monospace; font-size:9pt;
  background:#eef2f7; padding:.5mm 1.4mm; border-radius:1mm; color:#173a5e; }
strong{ color:#0B1522; }

/* ---------- components ---------- */
.lead{ font-size:11.6pt; color:#44546a; line-height:1.6; margin-bottom:6mm; }
.callout{ background:#f4f7fb; border-left:3.5px solid #0A6CFF; padding:3.5mm 4.5mm;
  border-radius:0 2mm 2mm 0; margin:4mm 0; font-size:9.8pt; page-break-inside:avoid; }
.callout.warn{ background:#fff6f0; border-left-color:#E01B22; }
.callout.tip{ background:#f2fbf7; border-left-color:#12A66A; }
.callout b{ display:block; margin-bottom:1mm; font-size:10pt; }
.callout p:last-child{ margin-bottom:0; }

.steps{ counter-reset:step; list-style:none; padding:0; margin:0 0 4mm; }
.steps > li{ counter-increment:step; position:relative; padding-left:11mm; margin-bottom:4.5mm;
  page-break-inside:avoid; }
.steps > li::before{
  content:counter(step); position:absolute; left:0; top:.2mm;
  width:7.4mm; height:7.4mm; border-radius:50%; background:#0B1522; color:#fff;
  font-size:9.4pt; font-weight:800; text-align:center; line-height:7.4mm;
}
.steps > li > b:first-child{ display:block; color:#0B1522; margin-bottom:.8mm; }

.term{ background:#0e1622; color:#dbe6f2; border-radius:2.5mm; padding:3.5mm 4.5mm;
  font-family:"DejaVu Sans Mono", Consolas, monospace; font-size:8.8pt; line-height:1.55;
  margin:3mm 0; white-space:pre-wrap; page-break-inside:avoid; }
.term .c{ color:#6f8299; }
.term .g{ color:#7ee2a8; }
.term .r{ color:#ff9aa2; }

table{ width:100%; border-collapse:collapse; margin:3mm 0 4mm; font-size:9.4pt;
  page-break-inside:avoid; }
th{ background:#0B1522; color:#fff; text-align:left; padding:2.4mm 3mm; font-weight:700;
  font-size:8.8pt; letter-spacing:.06em; text-transform:uppercase; }
td{ padding:2.2mm 3mm; border-bottom:1px solid #e2e8f0; vertical-align:top; }
tr:nth-child(even) td{ background:#f7f9fc; }
td code{ font-size:8.6pt; }

.shot{ max-width:100%; max-height:170mm; width:auto; border:1px solid #d5dde7;
  border-radius:2mm; margin:3mm auto 1.5mm; display:block; page-break-inside:avoid; }
.shot.wide{ width:100%; height:auto; }
.shot.narrow{ max-height:150mm; margin-left:auto; margin-right:auto; }
.shot.narrow2{ max-height:118mm; margin-left:auto; margin-right:auto; }
.shot.phone{ width:auto; height:168mm; border-radius:3mm; margin:2mm auto 1.5mm; }
.shot.mid{ width:auto; height:225mm; }
.shot.compact{ width:auto; height:150mm; }
.shot.compact2{ width:auto; height:141mm; }
.shot.verseframe{ width:82%; height:auto; margin-left:auto; margin-right:auto; }
.shot.ninety{ width:86%; height:auto; margin-left:auto; margin-right:auto; }
.shot.tallphone{ width:auto; height:132mm; }
td.note-row{ background:#fff8f3 !important; font-size:8.9pt; color:#55657a;
  border-left:3px solid #E01B22; }
.note{ font-size:9.2pt; color:#55657a; border-top:1px solid #e2e8f0; padding-top:2.6mm;
  margin:1mm 0 4mm; }
.note strong{ color:#0B1522; }
/* keep a screenshot glued to the caption underneath it */
.fig{ page-break-inside:avoid; break-inside:avoid; margin:0 0 2mm; }
.cap{ font-size:8.6pt; color:#6b7c8f; text-align:center; margin:0 0 5mm; font-style:italic; }

.two{ display:flex; gap:5mm; align-items:flex-start; page-break-inside:avoid; }
.two > div{ flex:1; min-width:0; }

.kv{ display:flex; gap:4mm; margin:3mm 0 4mm; page-break-inside:avoid; }
.kv .box{ flex:1; background:#f4f7fb; border:1px solid #dde5ee; border-radius:2mm;
  padding:3mm 3.5mm; }
.kv .box b{ display:block; font-size:9pt; color:#0B1522; margin-bottom:1mm; }
.kv .box span{ font-size:9pt; color:#55657a; }

.toc{ list-style:none; padding:0; margin:2mm 0 0; }
.toc li{ display:flex; align-items:baseline; margin-bottom:2.4mm; font-size:10.4pt; }
.toc .n{ color:#E01B22; font-weight:800; width:9mm; flex:0 0 auto; }
.toc .t{ color:#1d2733; font-weight:600; }
.toc .d{ flex:1; border-bottom:1px dotted #c3cfdd; margin:0 3mm 1mm; }
.toc .p{ color:#7b8a9b; font-size:9.4pt; }

.tight h3{ margin-top:5mm; }
.tight p{ margin-bottom:2.4mm; }
.tight table{ margin:2.4mm 0 3mm; }
.tight td{ padding:1.9mm 3mm; }
.tight .term{ margin:2.4mm 0; padding:3mm 4mm; }
.tight .steps > li{ margin-bottom:3.4mm; }
.tight .callout{ margin:3mm 0; }
.tight .lead{ margin-bottom:4.5mm; }
.backup{ background:#f2fbf7; border-left:3px solid #12A66A; padding:2.6mm 3.5mm;
  font-size:9.4pt; margin:4mm 0 0; }

.pagebreak{ page-break-before:always; }
.avoid{ page-break-inside:avoid; }

.footer-note{ margin-top:9mm; padding-top:4mm; border-top:1px solid #dde5ee;
  font-size:9pt; color:#6b7c8f; }
"""


def section(num, title, body, pagebreak=True, tight=False):
    cls = ("pagebreak " if pagebreak else "") + ("tight" if tight else "")
    return '<div class="%s"><h2 class="section"><span class="sec-num">%s</span>%s</h2>%s</div>' % (
        cls, num, title, body)


# ------------------------------------------------------------------ content

COVER = """
<div class="cover">
  <div class="badge">Version 1.3</div>
  <div class="rule"></div>
  <div class="kicker">Broadcast graphics · OBS Studio</div>
  <h1>NewsDesk<br><span>Studio</span></h1>
  <div class="sub">The complete step-by-step guide to installing and running
    lower thirds, tickers, scripture and a wifi camera on air.</div>
  <div class="who">
    <b>Emmanuel Suah</b>
    Maintainer · application, plugin and documentation
  </div>
  <div class="foot">Works on Windows, macOS and Linux · Python 3.8+ · no internet required at showtime</div>
</div>
"""

TOC = """
<div style="page-break-after:always">
  <h2 class="section"><span class="sec-num">i</span>What you are holding</h2>
  <p class="lead">NewsDesk Studio is a broadcast graphics system that sits on top of OBS.
  It does not replace OBS — it gives OBS the graphics an on-air programme needs, and lets
  one person drive the whole show from a laptop, a phone, or a dock inside OBS.</p>

  <div class="kv">
    <div class="box"><b>Overlay</b><span>A transparent 1920×1080 layer you add to OBS as a
      browser source. This is what viewers see.</span></div>
    <div class="box"><b>Control panel</b><span>The web page where you type the headline and
      flip switches. Opens in any browser, on any device.</span></div>
    <div class="box"><b>OBS dock</b><span>An optional native plugin so the same controls live
      inside OBS itself.</span></div>
  </div>

  <p>You can start with only the first two — the plugin is a convenience, never a requirement.</p>

  <h3>Contents</h3>
  <ul class="toc">
__TOC_ITEMS__
  </ul>

  <div class="callout tip" style="margin-top:4mm">
    <b>How to read this guide</b>
    <p>If you have never installed it before, work straight through sections 1&ndash;4 — about
    fifteen minutes. Sections 5&ndash;10 are the day-to-day craft: looks, pictures, scripture,
    song words, phones and running order. Sections 11&ndash;14 are what you keep beside the desk
    on a Sunday morning.</p>
  </div>
</div>
"""

S1 = section("1", "Before you begin", tight=True, body="""
<p class="lead">Five minutes of preparation saves an hour of confusion on a Sunday.</p>

<h3>What you need</h3>
<table>
  <tr><th style="width:34%">Item</th><th>Detail</th></tr>
  <tr><td><b>A computer</b></td><td>The one running OBS. Windows 10/11, macOS 12+, or a Linux desktop.</td></tr>
  <tr><td><b>OBS Studio</b></td><td>Version 30 or newer is recommended. The official build from
      obsproject.com always includes the Browser source — some distro packages do not.</td></tr>
  <tr><td><b>Python 3.8+</b></td><td>Only for the small control server. <b>No extra packages are
      needed</b> — everything runs on the standard library.</td></tr>
  <tr><td><b>The NewsDesk folder</b></td><td>The unzipped kit. Keep it somewhere permanent,
      not in Downloads — the folder holds your saved state and uploaded images.</td></tr>
  <tr><td><b>Internet (optional)</b></td><td>Only needed to download the kit. Everything runs
      offline afterwards, including the Bible.</td></tr>
</table>

<h3>How the pieces talk to each other</h3>
<p>One small server runs on your machine and holds the current on-air state — the headline,
which graphics are visible, the verse on screen. Everything else is a client of that server:</p>

<div class="term"><span class="c"># the three clients that can drive the show</span>
  Control panel  <span class="g">http://127.0.0.1:8770/</span>        <span class="c">laptop, or a phone on the same wifi</span>
  OBS overlay    <span class="g">…/overlay/overlay.html</span>        <span class="c">what viewers see (browser source)</span>
  OBS dock       <span class="c">inside OBS</span>                    <span class="c">optional plugin</span>

<span class="c"># change one thing anywhere, and every client updates instantly</span></div>

<div class="callout">
  <b>Nothing leaves your machine</b>
  <p>The server only listens on your own network. There is no account, no cloud, no
  telemetry. The only time anything touches the internet is when you press "Show QR code"
  and your phone connects over your own wifi.</p>
</div>

<h3>Check your OBS has a browser source</h3>
<p>Open OBS, click <strong>+</strong> under <strong>Sources</strong> and look for
<strong>Browser</strong> in the list. If it is missing — common with Debian and Ubuntu
packages — install the official build from obsproject.com instead; the overlay cannot be
displayed without it.</p>
""")

S2 = section("2", "Install the server", """
<p class="lead">Two commands. No installers, no dependencies, nothing to configure.</p>

<h3>Step 1 — open a terminal in the kit folder</h3>
<div class="two">
  <div>
    <h4>Windows</h4>
    <ol>
      <li>Open the <code>obs-news-desk</code> folder in File Explorer.</li>
      <li>Click the address bar, type <code>cmd</code>, press <strong>Enter</strong>.</li>
    </ol>
    <h4>macOS</h4>
    <p>Right-click the folder → <strong>Services</strong> → <strong>New Terminal at Folder</strong>,
    or type <code>cd</code>, drag the folder in, press Enter.</p>
    <h4>Linux</h4>
    <p><code>cd</code> into the folder in your terminal.</p>
  </div>
  <div>
    <div class="callout warn" style="margin-top:0">
      <b>Windows: “python is not recognised”</b>
      <p>Python is not on your PATH. Use the full path, or reinstall Python and tick
      <em>Add python.exe to PATH</em> on the first screen. The Microsoft Store version also
      works — the command is <code>python</code>, not <code>py</code>.</p>
    </div>
  </div>
</div>

<h3>Step 2 — start it</h3>
<div class="term"><span class="c"># the only command you need</span>
python server.py --open</div>

<p>You should see this. The window stays open — that is the server running:</p>

<div class="term">  ┌──────────────────────────────────────────────────────────────┐
  │   N E W S D E S K   S T U D I O                              │
  │   broadcast graphics for OBS — control panel + overlay        │
  │   by Emmanuel Suah                                            │
  └──────────────────────────────────────────────────────────────┘

  NewsDesk Studio — maintained by Emmanuel Suah · v1.3

  Control panel   <span class="g">http://127.0.0.1:8770/</span>
  Phone / tablet  <span class="g">http://192.168.1.60:8770/</span>   <span class="c">(same wifi)</span>
  OBS overlay URL <span class="g">http://127.0.0.1:8770/overlay/overlay.html</span>
  Demo preview    <span class="g">http://127.0.0.1:8770/demo</span>
  Phone camera    <span class="g">https://192.168.1.60:8443/cam</span>   <span class="c">(QR code in the panel)</span>

  Keep this window open while you stream.  Ctrl+C to stop.</div>

<div class="callout tip">
  <b>What just happened</b>
  <p>On first run the server created two things next to <code>server.py</code>:
  <code>state.json</code>, which remembers your last on-air look, and a <code>certs</code>
  folder holding a self-signed certificate so a phone can use its camera (section 8).
  Both are safe to delete; they are rebuilt on the next start.</p>
</div>

<h3>Step 3 — open the control panel</h3>
<p><code>--open</code> already launched your browser. If it did not, open
<code>http://127.0.0.1:8770/</code> yourself. You should see the panel with the status pill
reading <strong>running</strong> in the top-right.</p>

<div class="callout warn">
  <b>Keep that terminal window open</b>
  <p>Closing it stops the server, and the overlay stops updating (the graphics already on
  screen stay visible — they simply freeze). Minimise it instead.</p>
</div>

<h3>Starting it again later</h3>
<p>Every time you want to go on air: open the folder, run <code>python server.py</code>.
Your headline, ticker, preset and uploaded images are all remembered.</p>

<table>
  <tr><th style="width:44%">If you want to…</th><th>Add this flag</th></tr>
  <tr><td>Use a different port</td><td><code>--port 9000</code></td></tr>
  <tr><td>Prevent the camera page from opening a port</td><td><code>--no-camera</code></td></tr>
  <tr><td>Move the camera page to another port</td><td><code>--cam-port 9443</code></td></tr>
  <tr><td>Open the panel automatically</td><td><code>--open</code></td></tr>
</table>
""")

S3 = section("3", "Put the overlay in OBS", """
<p class="lead">The overlay is a single browser source. Add it once, and you are on air.</p>

<ol class="steps">
  <li><b>Add the source</b>
    In OBS, under <strong>Sources</strong>, click <strong>+</strong> and choose
    <strong>Browser</strong>. Name it <code>NewsDesk Overlay</code>.</li>

  <li><b>Paste the URL</b>
    <div class="term">http://127.0.0.1:8770/overlay/overlay.html</div></li>

  <li><b>Set the size</b>
    Width <strong>1920</strong>, Height <strong>1080</strong>. Leave
    <em>Control audio via OBS</em> unticked.</li>

  <li><b>Untick “Shutdown source when not visible”</b>
    This keeps the clock and animations alive when you switch scenes.
    If it stays ticked, the overlay reloads every time you come back to the scene and the
    clock jumps.</li>

  <li><b>Put your camera underneath</b>
    The overlay is transparent. Your camera, game capture or screen capture belongs in a
    source <em>below</em> it in the same scene — that is the picture the graphics sit on.</li>

  <li><b>Confirm</b>
    The overlay should immediately show the headline bar, ticker and PIP frame.
    Type in the panel — it changes instantly.</li>
</ol>

@@FIG|10_overlay_breaking.png|The finished look in OBS — camera underneath, graphics on top@@

<h3>Why it is transparent</h3>
<p>Everything except the graphics is see-through, which is why the overlay looks “empty”
if you open it in a browser — that is correct behaviour. In OBS the transparency is what
lets your camera show through.</p>

<div class="callout warn">
  <b>The overlay is black or empty in OBS</b>
  <p>Either the server is not running (check the status pill in the panel), or the URL is
  wrong. Open the overlay URL directly in your browser — if it loads there, the problem is
  connected to OBS, not the kit. Also confirm the source size is 1920×1080 and not scaled down
  to a corner.</p>
</div>

<h3>If you want to record or stream with a clean look</h3>
<p>Keep the overlay as the topmost source in the scene. Anything you place above it will
cover the graphics, so when in doubt, drag the overlay to the top of the Sources list.</p>
""")

S4 = section("4", "Drive the show from the panel", """
<p class="lead">The panel is the whole show in one page. These are the controls you will
actually use, in the order you meet them.</p>

@@FIG|01_topbar.png|The top bar: link status, guides, and the sting button@@

<h3>The top bar</h3>
<table>
  <tr><th style="width:30%">Control</th><th>What it does</th></tr>
  <tr><td><b>Status pill</b></td><td><strong>running</strong> means the panel is linked to
      the server. If it says offline, the server window was closed.</td></tr>
  <tr><td><b>↻ Reload overlay</b></td><td>Forces every connected overlay to reload. Use it
      after changing fonts or if a graphic looks stuck.</td></tr>
  <tr><td><b>⌗ Guides</b></td><td>Shows safe-area and PIP placement guides <em>in the
      overlay</em>. Turn them off before you go live — they are an alignment tool.</td></tr>
  <tr><td><b>⚡ Sting</b></td><td>Plays the wipe animation, the same one a news gallery fires
      between stories.</td></tr>
</table>

<h3>Card 1 — On-air text</h3>

@@FIG|02_card_text.png|Everything typed here appears on air as you type — there is no save button@@

<table>
  <tr><th style="width:30%">Field</th><th>Where it appears</th></tr>
  <tr><td><b>Eyebrow</b></td><td>The red kicker above the headline, e.g. <code>BREAKING NEWS</code></td></tr>
  <tr><td><b>Headline</b></td><td>The main white bar. Text auto-fits 30–56 px, so long
      headlines shrink instead of overflowing.</td></tr>
  <tr><td><b>Chip</b></td><td>The short word boxed at the right end of the bar</td></tr>
  <tr><td><b>Ticker</b></td><td>The crawl. <strong>Separate items with the | character</strong>,
      and each becomes its own story.</td></tr>
  <tr><td><b>Brand name / sub</b></td><td>The top-left bug and its small label</td></tr>
</table>

<div class="callout tip">
  <b>The ticker is the one thing people get wrong</b>
  <p>Type <code>Markets close higher|Storm warning for the coast|School reopens Monday</code> —
  three separate stories scrolling. If you use <strong>Enter</strong> instead of
  <code>|</code>, you get one very long story.</p>
</div>

<h3>Card 2 — PIP / feed text</h3>
<p>Labels for the framed guest box: the red <strong>LIVE</strong> tag, the source name under
it (<code>FEED 02</code>), and the credit line (<code>Credit: World Feed</code>). These are the
details that make a picture look like a real broadcast rather than a video call.</p>

<h3>Cards 7–9 — Graphics, Look, Presets</h3>
<div class="two">
  <div>
    <h4>Graphics</h4>
    <p>On/off switches for the lower third, PIP frame, ticker, clock, brand bug and breaking
    alert. Each one animates in and out rather than snapping.</p>
  </div>
  <div>
    <h4>Look</h4>
    <p>Accent colour, headline font style, and the plate used by the demo preview. Changing
    the accent recolours the whole system at once — bars, tags, corners, ticker.</p>
  </div>
</div>

@@FIG|07_presets_card.png|My presets saves an entire look and restores it in one click@@
""")

S5 = section("5", "Five looks: Breaking to Church", """
<p class="lead">A preset is a complete look — colours, fonts, text and which graphics are on.
One click and the whole broadcast changes style.</p>

<table>
  <tr><th style="width:20%">Preset</th><th>Best for</th><th>What changes</th></tr>
  <tr><td><b>Breaking</b></td><td>News bulletins, alerts</td><td>Red accent, pulsing alert, clock and brand on</td></tr>
  <tr><td><b>Straight</b></td><td>Evening report, calm presentation</td><td>Blue accent, lower third and ticker only, no PIP</td></tr>
  <tr><td><b>Interview</b></td><td>Two-person conversations</td><td>PIP frame with guest labels, no ticker</td></tr>
  <tr><td><b>Sport</b></td><td>Match coverage</td><td>Green accent, match-day kicker, score bug space</td></tr>
  <tr><td><b>Church</b></td><td>Services, worship, teaching</td><td>Gold accent, serif headlines, cross mark, slower ticker</td></tr>
</table>

<h3>The Church look</h3>

@@FIG|11_overlay_church.png|The Church preset: gold accent, Playfair Display serif, cross brand mark@@

<p>The Church preset is a first-class look, not a stripped-down news one. It sets:</p>
<ul>
  <li><strong>Gold accent</strong> <code>#C9A227</code> on deep navy <code>#0E1B33</code></li>
  <li><strong>Serif headlines</strong> in Playfair Display at 54 px, a taller bar that reads
      better on a projector than condensed sans</li>
  <li><strong>A cross brand mark</strong> instead of the letter N</li>
  <li><strong>Slower ticker</strong> at 80 — announcements need reading time</li>
  <li>Church-appropriate default text: service times, midweek study, giving</li>
</ul>

<div class="callout tip">
  <b>Make it yours</b>
  <p>Apply Church, change the brand name to your own, then save it under
  <strong>My presets</strong> — for example “Grace Chapel Sunday”. Next week it is one click.</p>
</div>

<h3>Saving your own look</h3>
<ol>
  <li>Set everything up exactly as you want it — text, colours, graphics, images.</li>
  <li>Go to <strong>My presets</strong>, type a name, press <strong>Save</strong>.</li>
  <li>The preset lives in <code>presets.json</code> on the server, so it follows you to every
      browser, phone and the OBS dock.</li>
</ol>
""")

S6 = section("6", "Images, logos and slides", tight=True, body="""
<p class="lead">Six image slots, one shared library. Drag in a file once and place it anywhere.</p>

@@FIG|04_media_card.png|compact2|The Media card: one drop zone, six slots, one library@@

<h3>The six slots</h3>
<table>
  <tr><th style="width:26%">Slot</th><th>Appears as</th></tr>
  <tr><td><b>Poster / slide</b></td><td>Bottom band or full frame — scripture slides, sermon
      points, sponsor cards</td></tr>
  <tr><td><b>Brand logo</b></td><td>Replaces the top-left mark; a transparent PNG works best</td></tr>
  <tr><td><b>Headline chip</b></td><td>An image inside the lower-third lockup instead of text</td></tr>
  <tr><td><b>PIP slate</b></td><td>Standby card inside the guest box when no camera is there</td></tr>
  <tr><td><b>Background plate</b></td><td>Full-frame backdrop behind all graphics</td></tr>
  <tr><td><b>Sponsor mark</b></td><td>Corner watermark — pick which corner with the buttons below</td></tr>
</table>

<h3>Adding an image</h3>
<ol class="steps">
  <li><b>Drop it</b>
    Drag files onto the dashed area at the top of the card, or click it and choose files.
    Several at once is fine.</li>
  <li><b>Place it</b>
    Click the preview of the slot you want. A picker opens showing everything in the
    library — click one to place it, or upload a new file from there.</li>
  <li><b>Adjust</b>
    Every slot has ✕ to clear it. Slots with a visibility toggle (brand logo, background
    plate, sponsor mark) also have ⏻ to hide without clearing.</li>
</ol>

<div class="callout">
  <b>Uploading the same picture twice does not duplicate it</b>
  <p>The server fingerprints the bytes and returns the file already in the library. If you
  genuinely want two copies, rename one first. Screenshot-style names like
  <code>6015-636658.png</code> are rewritten to something readable — that is a feature, not a bug.</p>
</div>

<h3>Image sizes that work</h3>
<table>
  <tr><th style="width:30%">Slot</th><th>Recommended</th></tr>
  <tr><td>Poster / background</td><td>1920×1080 or 1920×900. <em>Bottom band</em> crops to the
      lower 470 px; <em>full frame</em> covers everything.</td></tr>
  <tr><td>Brand logo</td><td>Transparent PNG, roughly 2–4× the 50 px display height
      (so 150–200 px tall) to stay crisp</td></tr>
  <tr><td>Sponsor mark</td><td>Wide PNG with transparency, about 260 px wide</td></tr>
  <tr><td colspan="2" class="note-row"><strong>Background plate looks like nothing
      happened</strong> — the plate renders <em>behind</em> the transparent overlay, so your
      camera source hides it. That is intentional: it is for title cards and interstitials,
      not for sitting behind a live shot.</td></tr>
</table>
""")

S7 = section("8", "Bible: scripture on air", """
<p class="lead">All 66 books — 39 Old Testament, 27 New, 1,189 chapters, 31,102 verses —
ship inside the kit and load from disk. No internet, no Bible website, no API keys. Type
<code>John 3:16</code>, or browse to any verse in the Bible, and it is on air.</p>

<h3>Browse the whole Bible</h3>
<p>Above the search box there is a book list and a chapter list. Pick a book, pick a chapter,
press <strong>Open</strong>, and every verse of that chapter is listed — click the one you
want. The count reads <strong>66 books · 1,189 chapters · 31,102 verses</strong>, measured
from the file that ships with the kit.</p>

@@FIG|26_bible_browse_row.png|Browse — pick a book, pick a chapter, press Open@@

<ol class="steps">
  <li><b>Type a reference</b>
    In the Bible card, type <code>John 3:16</code> — or <code>ps 23</code>, or
    <code>1cor 13:4-7</code>, or just <code>Genesis</code>. Results appear as you type.</li>

  <li><b>Preview it</b>
    Click a result. The full text appears in the preview box <em>before</em> anything goes
    on air — important, because a wrong verse on screen is very public.</li>

  <li><b>Put it on air</b>
    Press <strong>Put on air</strong>. The verse appears in the look selected under
    <strong>Look</strong>.</li>

  <li><b>Take it down</b>
    Press <strong>Off</strong>. The verse fades out and your lower third returns.</li>
</ol>

<h3>A long chapter is paged, never cut</h3>
<p>Some chapters are far too long for one screen — Psalm 119 has 176 verses. Those come in
parts, with <strong>‹ Back / Next ›</strong> under the preview. Arrow keys work too. Every
part is real scripture and the last part ends on the true final verse, so nothing is quietly
dropped.</p>

@@FIG|25_bible_pager.png|narrow|Part 1 of 12 — the whole chapter, one screenful at a time@@

<div class="callout warn">
  <b>A verse that does not exist is refused</b>
  <p>Type <code>Genesis 1:32</code> and you get “Genesis 1 has 31 verses — there is no verse
  32.” It will not quietly show you verse 31 under the wrong reference.</p>
</div>

<h3>A book, a chapter, or a few remembered words</h3>
<p>The box reads a passage first, then searches the text underneath it. That order matters: a
book name has to be read as a book, because the word “Genesis” never appears in the verses
themselves.</p>
<table>
  <tr><th style="width:34%">You type</th><th>You get</th></tr>
  <tr><td><code>Genesis</code>, <code>John</code>, <code>1 Corinthians</code></td>
      <td>that book, opening at chapter 1 — marked <strong>passage</strong></td></tr>
  <tr><td><code>John 3</code></td><td>chapter 3</td></tr>
  <tr><td><code>shepherd</code></td><td>Psalms 23:1, then other shepherd passages</td></tr>
  <tr><td><code>fear not</code></td><td>Isaiah 41:10 and similar</td></tr>
  <tr><td><code>love</code></td><td>John 3:16, 1 Corinthians 13, 1 John 4:8</td></tr>
</table>
<p class="cap" style="text-align:left;margin-top:-1mm">A passage match sits at the top of the
list; word matches follow it. So <code>mark</code> gives you Mark 1 <em>and</em> the verses
that mention a mark. Well-known verses rank first among word matches, and short verses are
preferred — those read best on a lower third.</p>

<h3>The three looks</h3>
<div class="two">
  <div>""" + img("12_verse_band.png", "shot verseframe") + """<p class="cap">Band — over your picture, above the ticker</p></div>
  <div>""" + img("13_verse_full.png", "shot verseframe") + """<p class="cap">Full — replaces the picture entirely</p></div>
</div>
<ul>
  <li><strong>Band</strong> — the everyday choice. Sits above the ticker while your camera
      keeps showing.</li>
  <li><strong>Card</strong> — a centred panel, good for an altar call or a quiet moment.</li>
  <li><strong>Full</strong> — the verse replaces the picture on a deep navy field. Best when
      the words <em>are</em> the moment.</li>
</ul>

<p>Text auto-fits, so a single verse renders large and a whole chapter steps down without
ever spilling off the frame. <strong>Keep graphics</strong> lets the lower third stay visible
underneath if you want both. Verses you have shown stay at the bottom of the card, so “go back
to that one” is a single click — and only the KJV ships, because it is public domain.</p>

<h3>Twenty backgrounds behind the words</h3>
<p>The kit ships twenty broadcast plates — mountains at dawn, a star field, ocean at dusk, a
stone chapel, a church auditorium, plus clean gradients, bokeh, linen and charcoal. They load
from disk, so this works with no internet.</p>

@@FIG|22_plate_picker.png|narrow2|Background picker — click a plate and it is behind the verse instantly@@

<ol class="steps">
  <li><b>Pick a plate</b>
    Bible card → <strong>Background</strong> → click any thumbnail. It appears behind the
    verse in whichever look you are using.</li>

  <li><b>Darken behind the text</b>
    The <strong>Darken behind text</strong> slider (0–100%) sets how much scrim sits between
    the photograph and the words. 55% is the default and stays readable on every shipped
    plate; push it higher for a busy sky, lower for a quiet one.</li>

  <li><b>Place the words</b>
    <strong>Text sits</strong> — Top, Centre or Bottom, for the Full look. Pin the words low
    to leave the sky clear, or high to leave room for a band underneath.</li>

  <li><b>Light or dark type</b>
    Light is white type for photographs. Dark is charcoal for pale plates. Choosing the linen
    or paper plate switches it for you.</li>
</ol>

@@FIG|20_verse_plate_full.png|Full look on the dawn plate — scrim at 55%, KJV label, text centred@@

<div class="two">
  <div>
    <div class="callout tip" style="margin-top:4mm">
      <b>None is a real choice</b>
      <p>Click <strong>None</strong> and you are back to the plain navy field. Your own
      uploaded pictures work as plates too — any <code>/uploads/…</code> path can go in
      <code>verseBg</code>.</p>
    </div>
  </div>
  <div>
    <div class="callout" style="margin-top:4mm">
      <b>On a bright photograph</b>
      <p>If the sky fights the words, raise <strong>Darken behind text</strong> to 70–80%
      before you change the type. It keeps the picture and fixes the contrast.</p>
    </div>
  </div>
</div>


""")

S8 = section("10", "Camera over wifi", """
<p class="lead">A phone becomes a live camera feed by scanning a QR code. No capture card,
no cables, no extra app on the phone.</p>

@@FIG|05_camera_card.png|compact|Card 6 — pick the area, scan the code, go on air@@

<h3>Pairing a phone</h3>
<ol class="steps">
  <li><b>Choose the area</b>
    <strong>Inside PIP box</strong> for a guest in the framed box, or
    <strong>Full frame</strong> to fill the whole programme.</li>

  <li><b>Show the QR code</b>
    Press <strong>📱 Show QR code for a phone</strong>. A code appears with the link under it.</li>

  <li><b>Scan it with the phone</b>
    Use the phone's own camera app and open the link it offers.</li>

  <li><b>Accept the certificate warning once</b>
    The phone will warn that the connection is not private. Tap <strong>Advanced → Proceed</strong>.
    This is expected: browsers only allow camera access on a secure page, so the server
    makes its own certificate on your machine. It never leaves your network.</li>

  <li><b>Press Start camera, then Allow</b>
    The phone's camera opens and the panel header shows <strong>1 live</strong>.</li>

  <li><b>Turn it on air</b>
    Flip <strong>Camera on air</strong>. The feed appears in the area you chose.</li>
</ol>

@@FIG|15_phone_camera_page.png|ninety|The phone page: start/stop, camera switch, quality, safe-area guide@@

@@FIG|14_overlay_camera.png|ninety|A phone feeding the PIP box, with the broadcast chrome on top@@

<h3>Framing controls</h3>
<table>
  <tr><th style="width:26%">Control</th><th>What it does</th></tr>
  <tr><td><b>Camera area</b></td><td>Move the feed between the PIP box and the full frame —
      <em>without</em> touching the phone</td></tr>
  <tr><td><b>Camera on air</b></td><td>Show or hide the feed; hiding shows your standby slate</td></tr>
  <tr><td><b>Fit</b></td><td><em>Fill &amp; crop</em> to cover the area, or <em>Fit whole</em>
      to letterbox and see every edge</td></tr>
  <tr><td><b>Crop anchor</b></td><td>Which edge survives when filling — centre, top or bottom</td></tr>
  <tr><td><b>Mirror</b></td><td>Flip horizontally, which reads better for a selfie feed</td></tr>
</table>

<div class="callout tip">
  <b>Moving the camera mid-show</b>
  <p>Switch <strong>Inside PIP box</strong> → <strong>Full frame</strong> while streaming and
  the feed relocates in about a second. The phone keeps streaming; nothing to rescan.</p>
</div>

<h3>Any other camera</h3>
<p>Under <em>Or another camera</em>, paste a <strong>WHEP</strong> address. This works with
OBS's own <strong>Tools → WebRTC Output</strong>, MediaMTX, Janus, or any WebRTC endpoint —
useful for a second OBS machine, a camcorder on a laptop, or a remote site.</p>

<div class="term"><span class="c"># typical MediaMTX WHEP endpoint</span>
http://192.168.1.50:8889/cam/whep</div>

<h3>A video instead of a camera</h3>
<p>Under the camera controls there is <b>Feed from a video</b>: upload an MP4 or WebM (up to
300 MB) or pick one from the library, then press <b>Play</b>. The clip plays in the same PIP
hole as the phone, so a bumper, a pre-recorded message or last week's notice reel can go out
in place of the guest with one switch.</p>
<ul class="plain">
  <li><b>Video on air</b> shows or hides it; turning it on switches the camera off so the two
      never fight for the same box.</li>
  <li><b>Loop</b> repeats the clip; <b>Sound</b> is muted by default, which is what browsers
      require before they will start a video on their own.</li>
  <li><b>Fit</b> fills and crops, or letterboxes the whole frame.</li>
  <li><b>From start</b> rewinds and puts it up again — the usual move for a notice reel.</li>
</ul>
<p>The panel's own player appears under the file name, so you can scrub and choose a start
point before it goes on air. Clips are served in ranges, so OBS can seek a long file instead
of downloading all of it first.</p>

<h3>Who gets the picture</h3>
<p>Each window that wants the camera announces itself. The <b>OBS browser source</b> ranks
above the <b>panel preview</b>, so opening the panel can never take the feed off air.
Offers, answers and network candidates are delivered to the owning window alone — when
they were broadcast to every window, two of them answered the same phone and both
went black.</p>
<p>The panel now says what is wrong in one line, under the camera card, and refreshes it
every five seconds. The same answer is available to scripts:</p>

<div class="term"><span class="c"># plain-language camera health</span>
curl http://127.0.0.1:8770/api/camera/live</div>

<h3>If the phone cannot connect</h3>
<table>
  <tr><th style="width:36%">Symptom</th><th>Cause and fix</th></tr>
  <tr><td>Page will not open</td><td>Server running with <code>--no-camera</code>, or Windows
      Firewall is blocking port 8443. Allow Python on <em>private</em> networks.</td></tr>
  <tr><td>“This page needs HTTPS”</td><td>Address typed by hand without <code>https://</code>.
      Use the QR code.</td></tr>
  <tr><td>Camera did not start</td><td>Another app owns the camera (Zoom, Camera, another tab).
      Close it and press Start again.</td></tr>
  <tr><td>Phone says LIVE, OBS is black</td><td><b>Most often two windows are subscribed.</b>
      A phone serves one viewer only; OBS now outranks the panel preview, and the losing
      window shows <em>“Camera is in another window”</em> on the overlay instead of a black
      box. Close the extra tab. If that is not it, guest wifi with client isolation is
      blocking the peer-to-peer video — use the same router without isolation.</td></tr>
  <tr><td>“Camera connected, no picture”</td><td>The phone is paired but not sending frames.
      Unlock it and bring the browser back to the front, then press Start again.</td></tr>
  <tr><td>Works on the PC, not on the phone</td><td>Phone is on a different network —
      check the phone is on the same wifi, not mobile data.</td></tr>
</table>
""")


S8B = section("9", "Worship lyrics: the prompter", body="""
<p class="lead">Type the song once, then step through it line by line while it is on air.
One line per screen, easily read from the back row.</p>

<h3>Loading a song</h3>
<ol class="steps">
  <li><b>Title</b>
    Type the song title in <strong>Title on air</strong>. It appears above the words.</li>

  <li><b>Lines</b>
    Paste the words into <strong>Lines</strong> — <b>one line per screen</b>. Break them
    where you want the screen to change, not where the printed verse breaks.</li>

  <li><b>Load lines</b>
    The lines become a numbered list. Nothing is on air yet.</li>
</ol>

@@FIG|27_lyrics_card.png|compact|Card 6 — paste, load, then step with Next line@@

<h3>Running the song</h3>
<table>
  <tr><th style="width:30%">Control</th><th>What it does</th></tr>
  <tr><td><b>Next line</b> or <b>Alt + →</b></td><td>Puts the current line on air; each press
      advances one line</td></tr>
  <tr><td><b>Previous</b> or <b>Alt + ←</b></td><td>Steps back — useful when the repeat comes round</td></tr>
  <tr><td><b>Click a line</b></td><td>Jumps straight to it; the current line is underlined
      in the list</td></tr>
  <tr><td><b>Take down</b> / <b>Put on air</b></td><td>Clears the words, or brings the current
      line back</td></tr>
</table>

@@FIG|28_lyrics_air.png|wide|On air — title, the line, the next line small, and a dot per line@@

<p>On the overlay you get the title, the line in large type, and the <b>next line small
underneath</b> so the operator can see what is coming. A dot per line shows the position in
the song at a glance.</p>

<h3>Two looks</h3>
<p><b>Lower band</b> sits above the ticker with the same geometry as the scripture band, so it
works with everything else on screen. <b>Full frame</b> centres large type over a dark wash —
the usual choice for a hymn sing. Text size runs from 28 to 86 px, and the words can be
left-aligned or centred.</p>

<div class="callout"><b>Lyrics and scripture never collide.</b> When a lyric line is on air a
verse is held back instead of stacking two sets of words on the same screen. Take the lyrics
down and the scripture returns.</div>

<h3>The song library</h3>
<p><b>Save to library</b> stores the song in <code>presets.json</code>; it survives a restart
and loads again with one pick from the <b>Song</b> list. <b>Delete</b> removes it. Saving with
an existing title updates that song instead of making a duplicate.</p>
""")


S6B = section("7", "Go live, and the clean output", body="""
<p class="lead">One button puts everything on air — and guarantees that nothing you were
using to place graphics ends up on the broadcast.</p>

<h3>The Go live button</h3>
<p>It sits in the top bar, right of the connection light. One press:</p>
<ul class="plain">
  <li>switches the platform to on air and starts the on-air clock in the green bar;</li>
  <li>clears the countdown, because the service has started;</li>
  <li><b>switches off the alignment guides and the sample footage</b>;</li>
  <li>pushes the same clean picture to every overlay window, so OBS and a second
      window never disagree.</li>
</ul>
<p>A red pulsing dot and a green bar show you are live; <b>End the broadcast</b> in that bar
takes you off air again.</p>

<div class="callout"><b>Why this matters.</b> A guide left switched on is the easiest way to
look unprofessional on a Sunday. The broadcast can no longer show one — see below.</div>

<h3>Editing view versus broadcast</h3>
<p>The preview inside the control panel is an <b>editing view</b>. It loads the overlay with
<code>?preview=1</code>, and only that window shows the alignment guides, the safe-area
outlines and the sample footage.</p>
<p>The URL you paste into OBS is the plain one:</p>

<div class="term">http://127.0.0.1:8770/overlay/overlay.html</div>

<p>That window strips the editing aids every time the state changes, whatever the panel has
switched on. You can leave the guides on all afternoon while you place a lower third; the
congregation never sees them.</p>

<p>The preview is also a <em>looker</em>, not a viewer: it will watch the camera when the
feed is free, but it always yields to the OBS source instead of competing for the phone's
single connection.</p>
""")

S9 = section("11", "Run of show, presets and hotkeys", """
<p class="lead">For a service or a bulletin with a fixed order, the run of show turns the
whole thing into a sequence you walk through with one key.</p>

<h3>Run of show</h3>
<p>Card 3 holds an ordered list. Each row is a headline plus duration; clicking any row cuts
to it instantly. Press <strong>▶ Play</strong> and the <em>server</em> walks the list — so it
keeps running even if you close the tab or your laptop sleeps.</p>
<ul>
  <li><strong>Add</strong> a row with <em>+ Add to run of show</em></li>
  <li><strong>Attach an image</strong> to a row and it becomes a slide when you jump to it</li>
  <li><strong>Duration 0</strong> falls back to 8 seconds</li>
  <li>The next row without an image clears the slide automatically</li>
</ul>

<div class="callout warn">
  <b>Restarting the server stops playback</b>
  <p>The clock lives on the server, not in the browser. If you restart <code>server.py</code>
  mid-service, press ▶ Play again.</p>
</div>

<h3>Extra graphics (card 4)</h3>
<table>
  <tr><th style="width:28%">Graphic</th><th>Use</th></tr>
  <tr><td><b>Countdown</b></td><td>Pre-service timer. It is a <em>duration in seconds</em>,
      not a start time — “30 min” counts down from 30 minutes from the moment you arm it,
      and <b>takes itself off air the moment it reaches zero</b>, even if nobody is
      watching the panel.</td></tr>
  <tr><td><b>Second crawl</b></td><td>A second ticker above the main one for announcements</td></tr>
  <tr><td><b>Now playing</b></td><td>Song title and artist, for worship sets</td></tr>
  <tr><td><b>Name card</b></td><td>Speaker or worship leader, lower third</td></tr>
  <tr><td><b>Score bug</b></td><td>Two teams and a score, for sport</td></tr>
</table>

<h3>Hotkeys</h3>
<p>The panel and the OBS dock both respond to single keys — useful with a Stream Deck or a
cheap wireless keypad:</p>
<table>
  <tr><th style="width:16%">Key</th><th>Action</th></tr>
  <tr><td><code>L</code></td><td>Toggle the lower third</td></tr>
  <tr><td><code>P</code></td><td>Toggle the PIP frame</td></tr>
  <tr><td><code>G</code></td><td>Toggle guides</td></tr>
  <tr><td><code>H</code></td><td>Hide / show all graphics</td></tr>
</table>

<h3>Driving it from a phone</h3>

""" + img("08_phone_panel.png", "shot phone") + """
<p class="cap">The same panel on a phone — every control is reachable, nothing scrolls sideways</p>

<p>Open <code>http://&lt;server&gt;:8770/</code> on any phone or tablet on the same wifi.
This is how a second person can hold the headline while the operator watches the programme.</p>
""")

S10 = section("12", "Install the OBS dock plugin", """
<p class="lead">Optional. The dock puts the same controls inside OBS so you never leave the
window — including scripture and the wifi camera.</p>

<h3>What the dock adds</h3>
<ul>
  <li>Headline, kicker, ticker and PIP labels inline</li>
  <li>On/off switches, accent picker, all five presets</li>
  <li><strong>Add to scene</strong> — inserts the 1920×1080 browser source for you</li>
  <li><strong>Scripture row</strong> — type <code>John 3:16</code>, press Enter, it is on air</li>
  <li><strong>Camera on / Cam off / PIP ⟷ Full</strong></li>
  <li>Sting, reload, next item, countdown</li>
</ul>

<h3>Easiest route: use the prebuilt file</h3>
<div class="callout">
  <b>Linux (64-bit)</b>
  <p>The kit ships a compiled <code>newsdesk.so</code> in <code>obs/install/</code>. Copy it
  into your OBS plugin folder and restart OBS:</p>
</div>
<div class="term"><span class="c"># system-wide</span>
sudo cp obs/install/newsdesk-linux-x86_64.so /usr/lib/x86_64-linux-gnu/obs-plugins/newsdesk.so

<span class="c"># or per-user (recommended)</span>
mkdir -p ~/.config/obs-studio/plugins/newsdesk/bin/64bit
cp obs/install/newsdesk-linux-x86_64.so \\
   ~/.config/obs-studio/plugins/newsdesk/bin/64bit/newsdesk.so</div>

<p><strong>Windows and macOS</strong> have no prebuilt binary — the plugin has to be compiled
against your OBS version. Skip to the build steps below, or simply use the panel instead; the
panel is a full replacement for the dock.</p>

<h3>Building it</h3>
<h4>Windows (inside the OBS source tree — the reliable route)</h4>
<ol>
  <li>Install Visual Studio 2022 with “Desktop development with C++”.</li>
  <li><code>git clone --recursive https://github.com/obsproject/obs-studio</code></li>
  <li>Copy the <code>obs/</code> folder into <code>obs-studio/plugins/newsdesk</code>.</li>
  <li>Add <code>add_subdirectory(newsdesk)</code> to <code>plugins/CMakeLists.txt</code>.</li>
  <li>Build <code>obs-studio</code> as usual (CMake presets in the repo).</li>
</ol>

<h4>Linux (standalone)</h4>
<div class="term">sudo apt install libobs-dev qt6-base-dev
cd obs
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
<span class="c"># the built module lands in build/rundir/lib/obs-plugins/newsdesk.so</span></div>

<div class="callout warn">
  <b>“Possible import conflicts” when OBS starts</b>
  <p>Your plugin was built against the wrong Qt. OBS 30+ uses Qt6; a Qt5 build will not load.
  Rebuild against the Qt6 development packages that match your OBS.</p>
</div>

<h3>Where the dock appears</h3>
<p>After a restart: <strong>Docks → NewsDesk — On Air</strong>. Tick it. It opens as a panel
inside OBS, already pointed at <code>127.0.0.1:8770</code>. If your server runs elsewhere,
change the address in the <em>Server</em> field at the bottom and press Save.</p>

<div class="callout tip">
  <b>The dock is a convenience, not the product</b>
  <p>Everything the dock does, the browser panel does too. If compiling is painful, use the
  panel on a second monitor or a phone — that is a perfectly normal way to run a show.</p>
</div>
""")

S11 = section("13", "Sunday morning checklist", tight=True, body="""
<p class="lead">A five-minute routine that prevents almost every problem people hit live.</p>

<h3>30 minutes before</h3>
<ol class="steps">
  <li><b>Start the server</b>
    <code>python server.py</code> in the kit folder. Leave the window open.</li>
  <li><b>Open the panel</b>
    <code>http://127.0.0.1:8770/</code> — confirm the pill reads <strong>running</strong>.</li>
  <li><b>Check OBS</b>
    The <code>NewsDesk Overlay</code> source is visible, topmost, and 1920×1080.</li>
  <li><b>Apply today's look</b>
    My presets → your saved preset. Text, colours and images all restore.</li>
  <li><b>Update the ticker</b>
    This week's announcements, separated by <code>|</code>.</li>
  <li><b>Pair the phone</b> (if using one)
    Camera card → Show QR → Start camera → flip <strong>Camera on air</strong>.</li>
  <li><b>Arm the countdown</b> if you use one, and check it on the programme output.</li>
  <li><b>Check the guides are off</b>
    The ⌗ Guides button must not be highlighted before you go live.</li>
</ol>

<h3>Just before you go live</h3>
<ul>
  <li>Headline matches the first thing you will say</li>
  <li>Ticker is current — last week's story is the classic mistake</li>
  <li>Camera lights and framing confirmed in the PIP box</li>
  <li>Verse cleared (Off) unless you need it in the first minute</li>
  <li>The run of show is loaded and ▶ Play is ready</li>
</ul>

<h3>After the service</h3>
<ul>
  <li>Stop the stream in OBS, then <strong>Ctrl+C</strong> in the server window.</li>
  <li>Your state is saved automatically — next week starts where you left off.</li>
  <li>Uploaded images stay in <code>uploads/</code>; delete old ones from the library grid.</li>
  <li><strong>Back up the station:</strong> <code>state.json</code>, <code>presets.json</code>
      and <code>uploads/</code> hold everything — copy all three to move to a new machine.</li>
</ul>


""")

S12 = section("14", "When something goes wrong", """
<p class="lead">The problems that actually happen, and what fixes them.</p>

<h3>Nothing appears in OBS</h3>
<table>
  <tr><th style="width:38%">Check</th><th>Fix</th></tr>
  <tr><td>Server window still open?</td><td>Restart it: <code>python server.py</code></td></tr>
  <tr><td>Panel shows <strong>running</strong>?</td><td>If offline, the server stopped</td></tr>
  <tr><td>URL exactly right?</td><td><code>http://127.0.0.1:8770/overlay/overlay.html</code></td></tr>
  <tr><td>Source size 1920×1080?</td><td>Right-click the source → Transform → Fit to screen</td></tr>
  <tr><td>Overlay below another source?</td><td>Drag it to the top of the Sources list</td></tr>
  <tr><td>Browser source missing?</td><td>Install the official OBS build</td></tr>
</table>

<h3>The console shows ConnectionResetError or BrokenPipeError</h3>
<p>You are running an older <code>server.py</code>. Those messages are OBS's browser source
closing sockets — harmless, but noisy. The current build catches them silently. If you see
them, you edited an older copy or the server was not restarted after an update.</p>

<h3>Text is too big or clipped</h3>
<ul>
  <li>Headlines auto-fit between 30 and 56 px. Very long headlines hit the floor and then wrap.</li>
  <li>Shorten the headline, or raise <strong>Headline max</strong> in the Look card.</li>
  <li>The chip is capped at 250×104 px — that is about four short words.</li>
</ul>

<h3>Two overlays fighting</h3>
<p>If you added the browser source twice, both will render and animate out of sync. Delete the
duplicate — one overlay per scene.</p>

<h3>The verse bar says “I could not find that reference”</h3>
<table>
  <tr><th style="width:32%">Typed</th><th>Why</th></tr>
  <tr><td><code>Genesis 51</code></td><td>Genesis has 50 chapters</td></tr>
  <tr><td><code>p 23</code></td><td><code>p</code> matches Psalms, Proverbs, Philippians — ambiguous</td></tr>
  <tr><td><code>John 99:1</code></td><td>John has 21 chapters</td></tr>
</table>
<p>Use <code>ps 23</code>. Abbreviations, Roman numerals and ordinals all work:
<code>ii tim 3:16</code>, <code>1st john 4:8</code>, <code>1cor 13</code>.</p>

<h3>Camera problems</h3>
<p>See the table in section 8 — it covers certificates, blocked ports, busy cameras and
client-isolation wifi.</p>

<h3>Complete reset</h3>
<div class="term"><span class="c"># stop the server first, then delete the saved state</span>
rm state.json          <span class="c"># headline, toggles, verse history</span>
rm -rf certs           <span class="c"># regenerated on next start (phone must re-accept)</span>

<span class="c"># keep presets.json and uploads/ — those are your own content</span></div>
""")

S13 = section("15", "Reference", """
<p class="lead">Everything in one place for when you know what you want but not where it is.</p>

<h3>Addresses</h3>
<table>
  <tr><th style="width:40%">URL</th><th>What it is</th></tr>
  <tr><td><code>http://127.0.0.1:8770/</code></td><td>Control panel</td></tr>
  <tr><td><code>http://127.0.0.1:8770/overlay/overlay.html</code></td><td>Overlay for OBS</td></tr>
  <tr><td><code>http://127.0.0.1:8770/demo</code></td><td>Preview with sample footage</td></tr>
  <tr><td><code>https://&lt;your-ip&gt;:8443/cam</code></td><td>Phone camera page</td></tr>
</table>

<h3>Command line</h3>
<table>
  <tr><th style="width:34%">Flag</th><th>Meaning</th></tr>
  <tr><td><code>--port 8770</code></td><td>Main server port</td></tr>
  <tr><td><code>--cam-port 8443</code></td><td>Phone camera https port</td></tr>
  <tr><td><code>--no-camera</code></td><td>Do not start the camera listener</td></tr>
  <tr><td><code>--open</code></td><td>Open the panel when the server starts</td></tr>
</table>

<h3>API (for Stream Deck, Companion or scripts)</h3>
<table>
  <tr><th style="width:46%">Endpoint</th><th>Purpose</th></tr>
  <tr><td><code>GET /api/state</code></td><td>Current on-air state</td></tr>
  <tr><td><code>POST /api/state</code></td><td>Patch any key, e.g. <code>{"headline":"…"}</code></td></tr>
  <tr><td><code>POST /api/sting</code></td><td>Play the wipe</td></tr>
  <tr><td><code>POST /api/reload</code></td><td>Reload every overlay</td></tr>
  <tr><td><code>GET /api/bible/lookup?ref=John+3:16</code></td><td>Resolve a verse</td></tr>
  <tr><td><code>GET /api/bible/search?q=shepherd</code></td><td>Search by words</td></tr>
  <tr><td><code>GET /api/uploads</code></td><td>Media library</td></tr>
  <tr><td><code>POST /api/upload</code></td><td>Upload an image</td></tr>
  <tr><td><code>GET /api/health</code></td><td>Liveness + version + maintainer</td></tr>
</table>

<h3>Files that matter</h3>
<table>
  <tr><th style="width:34%">Path</th><th>Holds</th></tr>
  <tr><td><code>state.json</code></td><td>Current on-air look</td></tr>
  <tr><td><code>presets.json</code></td><td>Your saved presets</td></tr>
  <tr><td><code>uploads/</code></td><td>Images you have uploaded</td></tr>
  <tr><td><code>certs/</code></td><td>Self-signed certificate for the camera page</td></tr>
  <tr><td><code>bible/kjv.dat</code></td><td>The whole KJV, compressed to 1.25 MB</td></tr>
  <tr><td><code>README.md</code></td><td>Feature-level documentation</td></tr>
  <tr><td><code>docs/INSTALL.md</code></td><td>Deeper troubleshooting</td></tr>
</table>

<h3>Shortcuts</h3>
<table>
  <tr><th style="width:16%">Key</th><th>Action</th></tr>
  <tr><td><code>L</code></td><td>Lower third</td></tr>
  <tr><td><code>P</code></td><td>PIP frame</td></tr>
  <tr><td><code>G</code></td><td>Guides</td></tr>
  <tr><td><code>H</code></td><td>Hide all graphics</td></tr>
  <tr><td><code>Ctrl+C</code></td><td>Stop the server</td></tr>
</table>

<div class="footer-note">
  <p><strong>NewsDesk Studio</strong> — built and maintained by <strong>Emmanuel Suah</strong>.</p>
  <p>Bible text: King James Version (1611), public domain. Fonts: Oswald, Barlow, Barlow
  Condensed, Archivo Black and Playfair Display, all under the SIL Open Font License.
  The application, overlay, control panel, OBS plugin and this guide are © Emmanuel Suah.</p>
  <p style="color:#93a2b4">Version 1.3 · generated from the live application so every
  screenshot matches the shipped build.</p>
</div>
""")

# ---------------------------------------------------------------- assembly
SECTIONS = [
    ("1", "Before you begin", S1),
    ("2", "Install the server", S2),
    ("3", "Put the overlay in OBS", S3),
    ("4", "Drive the show from the panel", S4),
    ("5", "Five looks: Breaking to Church", S5),
    ("6", "Images, logos and slides", S6),
    ("7", "Go live, and the clean output", S6B),
    ("8", "Bible: scripture on air", S7),
    ("9", "Worship lyrics: the prompter", S8B),
    ("10", "Camera over wifi", S8),
    ("11", "Run of show, presets and hotkeys", S9),
    ("12", "Install the OBS dock plugin", S10),
    ("13", "Sunday morning checklist", S11),
    ("14", "When something goes wrong", S12),
    ("15", "Reference", S13),
]


def _expand_figs(html):
    """Turn @@FIG|file|caption@@ tokens into a figure that never splits across pages."""
    def rep(m):
        size, cap = m.group(2), m.group(3)
        cls = ("shot " + size).strip() if size else "shot"
        return ('<div class="fig">' + img(m.group(1), cls) +
                '<p class="cap">' + cap + '</p></div>')
    return re.sub(r"@@FIG\|([^|]+)\|(?:(\w+)\|)?(.*?)@@", rep, html)


def toc_html(pages):
    """pages: dict num -> real PDF page number (1-based)."""
    out = []
    for num, title, _ in SECTIONS:
        out.append('<li><span class="n">%s</span><span class="t">%s</span>'
                   '<span class="d"></span><span class="p">p. %s</span></li>'
                   % (num, title, pages.get(num, "\u2014")))
    return "\n    ".join(out)


def build_html(pages):
    body = "\n".join([COVER, TOC.replace("__TOC_ITEMS__", toc_html(pages))]
                     + [sec for _, _, sec in SECTIONS])
    body = _expand_figs(body)
    return ("<!doctype html>\n<html><head><meta charset='utf-8'><style>" + CSS +
            "</style></head><body>\n" + body + "\n</body></html>")


def _render(html_text, out_path):
    """Write the HTML to disk and let headless Chromium print it."""
    from playwright.sync_api import sync_playwright

    html_path = ROOT.parent / "guide" / "_guide.html"
    html_path.write_text(html_text, encoding="utf-8")
    out_path.parent.mkdir(parents=True, exist_ok=True)

    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 1200, "height": 1600})
        pg.goto(html_path.as_uri(), wait_until="networkidle")
        pg.emulate_media(media="print")
        pg.wait_for_timeout(700)
        pg.pdf(path=str(out_path), format="A4", print_background=True,
               prefer_css_page_size=True,
               display_header_footer=True,
               header_template="<div></div>",
               footer_template="""
                 <div style="font-family:Helvetica,Arial,sans-serif;font-size:7.5pt;color:#93a2b4;
                             width:100%;padding:0 13mm;display:flex;justify-content:space-between">
                   <span>NewsDesk Studio — installation &amp; user guide</span>
                   <span>Emmanuel Suah &nbsp;·&nbsp; page <span class="pageNumber"></span> of <span class="totalPages"></span></span>
                 </div>""")
        b.close()


def _section_pages(pdf_path):
    """Find the page each section actually starts on, by looking for its number+title."""
    import pymupdf
    doc = pymupdf.open(pdf_path)
    found = {}
    for num, title, _ in SECTIONS:
        needle = title.split(":")[0].strip().lower()
        for i, page in enumerate(doc, start=1):
            text = " ".join(page.get_text().split()).lower()
            # the heading is the bold line right after the red section chip
            if text.startswith(str(num) + " " + needle) or (" " + str(num) + " " + needle) in text[:120]:
                found[num] = i
                break
    doc.close()
    return found


def main():
    tmp = ROOT.parent / "guide" / "_pass1.pdf"
    _render(build_html({}), tmp)                 # pass 1: numbers unknown
    pages = _section_pages(tmp)
    missing = [n for n, _, _ in SECTIONS if n not in pages]
    if missing:
        print("warning: could not locate sections", missing)

    _render(build_html(pages), OUT)              # pass 2: real page numbers
    print("contents:", ", ".join("%s→p%s" % (k, v) for k, v in sorted(pages.items(), key=lambda x: int(x[0]))))

    tmp.unlink(missing_ok=True)
    size = OUT.stat().st_size
    print("wrote %s (%.1f MB)" % (OUT, size / 1048576))


if __name__ == "__main__":
    main()

"""
Scripture backgrounds, end to end: picker -> state -> overlay render.

    python tests/test_scripture_bg.py      (needs the server running on 8770)

Checks the plate actually lands on the overlay in every look, that the
scrim and the dark-type switch reach the DOM, and that no JS errors fire.
"""
import json
import sys
import urllib.request

from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8770"
RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append(bool(ok))
    print(("  PASS  " if ok else "  FAIL  ") + name + (("  " + str(detail)) if detail else ""))


def post(path, body):
    return json.load(urllib.request.urlopen(
        urllib.request.Request(BASE + path, data=json.dumps(body).encode(),
                               headers={"Content-Type": "application/json"}), timeout=15))


def main():
    post("/api/state", {"verseRef": "Psalms 23", "showVerse": True, "verseMode": "full",
                        "verseBg": "", "verseScrim": 55, "verseTextStyle": "light",
                        "verseTextPos": "center"})

    with sync_playwright() as p:
        b = p.chromium.launch()
        ctx = b.new_context(viewport={"width": 1500, "height": 1500})
        errs = []
        panel = ctx.new_page()
        panel.on("pageerror", lambda e: errs.append("panel: " + str(e)))
        panel.on("console", lambda m: errs.append("panel: " + m.text) if m.type == "error" else None)
        panel.goto(BASE + "/", wait_until="networkidle")
        panel.wait_for_timeout(1800)

        ov = ctx.new_page()
        ov.set_viewport_size({"width": 1920, "height": 1080})
        ov.on("pageerror", lambda e: errs.append("overlay: " + str(e)))
        ov.goto(BASE + "/overlay/overlay.html", wait_until="networkidle")
        ov.wait_for_timeout(900)

        # ---- the picker ----
        n = panel.locator("#versePlates .plate").count()
        check("picker shows None + 20 plates", n == 21, n)
        check("plates have thumbnails",
              panel.locator("#versePlates .plate img").count() == 20)

        # ---- pick a plate ----
        panel.locator("#versePlates .plate").nth(1).click()
        panel.wait_for_timeout(1400)
        d = ov.evaluate("""() => {
            const v = document.getElementById('verseBox'), pl = document.getElementById('versePlate');
            return {hasPlate: v.classList.contains('has-plate'),
                    url: getComputedStyle(pl).backgroundImage,
                    visible: getComputedStyle(pl).opacity};
        }""")
        check("overlay receives the plate", d["hasPlate"] and "/scripture/" in d["url"], d["url"][:48])
        check("plate layer is visible", float(d["visible"]) > 0.9, d["visible"])
        check("panel shows the plate name", panel.locator("#versePlateLabel").inner_text() != "plain navy",
              panel.locator("#versePlateLabel").inner_text())

        # ---- the plate renders in band and card too ----
        for label in ("Band", "Card", "Full"):
            panel.click("#bibleMode button:has-text('%s')" % label)
            panel.wait_for_timeout(900)
            got = ov.evaluate("""() => { const v = document.getElementById('verseBox');
                return v.className; }""")
            check("plate holds in the %s look" % label.lower(),
                  "has-plate" in got and ("mode-" + label.lower()) in got, got)

        # ---- scrim ----
        panel.eval_on_selector("#verseScrim", "(el, v) => { el.value = v; el.dispatchEvent(new Event('input', {bubbles: true})); }", 85)
        panel.wait_for_timeout(900)
        sc = ov.evaluate("() => getComputedStyle(document.getElementById('verseBox')).getPropertyValue('--scrim')")
        check("scrim slider reaches the overlay", abs(float(sc) - 0.85) < 0.02, sc)

        # ---- light plate flips the type to dark ----
        idx = None
        for i in range(n):
            if "Linen" in panel.locator("#versePlates .plate").nth(i).inner_text():
                idx = i
                break
        panel.locator("#versePlates .plate").nth(idx).click()
        panel.wait_for_timeout(1300)
        cls = ov.evaluate("() => document.getElementById('verseBox').className")
        check("light plate switches to dark type", "text-dark" in cls, cls)
        colour = ov.evaluate("() => getComputedStyle(document.getElementById('verseText')).color")
        check("dark type is actually dark", colour.startswith("rgb(20"), colour)

        # ---- position ----
        panel.click("#versePos button:has-text('Top')")
        panel.wait_for_timeout(900)
        check("text can be pinned to the top",
              "pos-top" in ov.evaluate("() => document.getElementById('verseBox').className"))

        # ---- none clears it ----
        panel.locator("#versePlates .plate").nth(0).click()
        panel.wait_for_timeout(1100)
        check("choosing None removes the plate",
              not ov.evaluate("() => document.getElementById('verseBox').classList.contains('has-plate')"))

        # ---- the search box must read a reference as a reference ----------
        panel.click("#bibleMode button:has-text('Band')")
        panel.wait_for_timeout(300)

        def hits_for(term):
            panel.fill("#bibleQ", term)
            panel.wait_for_timeout(750)
            rows = panel.locator("#bibleHits .bible-hit").all_inner_texts()
            first = rows[0].split("\n")[0] if rows else ""
            is_ref = panel.locator("#bibleHits .bible-hit.is-ref").count() > 0
            return first.upper(), len(rows), is_ref, rows

        # book names have no digits in them, so these are the cases that used to
        # fall through to a word search
        for term, expect in (("Genesis", "GENESIS"), ("John", "JOHN"),
                             ("Psalms", "PSALMS"), ("Romans", "ROMANS"),
                             ("Exodus", "EXODUS"), ("Revelation", "REVELATION"),
                             ("1 Corinthians", "1 CORINTHIANS")):
            first, n, is_ref, rows = hits_for(term)
            check("book name %r resolves as a passage" % term,
                  is_ref and first.startswith(expect), "%s / %d rows" % (first[:28], n))

        # a chapter with no verse still resolves
        first, n, is_ref, _ = hits_for("John 3")
        check("'John 3' resolves as a passage", is_ref and first.startswith("JOHN 3"), first[:24])

        # a word still searches words, and must not be swallowed by a reference
        first, n, is_ref, _ = hits_for("shepherd")
        check("'shepherd' still does a word search", not is_ref and n > 0 and "PSALMS" in first,
              "%s / %d rows" % (first[:24], n))

        first, n, is_ref, _ = hits_for("fear not")
        check("a phrase still does a word search", not is_ref and n > 0, "%s / %d" % (first[:24], n))

        # and the thing you pick actually goes on air
        hits_for("Genesis")
        panel.locator("#bibleHits .bible-hit").first.click()
        panel.wait_for_timeout(900)
        check("picking a passage fills the preview",
              "In the beginning" in panel.locator("#biblePrevText").inner_text())

        # ---- nothing broke along the way ----
        check("no javascript errors", not errs, errs[:2])
        b.close()

    print("\n  %d/%d scripture-background checks passed" % (sum(RESULTS), len(RESULTS)))
    return 0 if all(RESULTS) else 1


if __name__ == "__main__":
    sys.exit(main())

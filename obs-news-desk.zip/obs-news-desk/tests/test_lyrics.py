"""
Worship lyrics prompter — panel, overlay and library.

    python3 tests/test_lyrics.py

Covers what an operator does in the ten minutes before a service:
paste a song, step through it, save it, change the look, take it down.
"""
import json
import sys
import urllib.request

from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8770"
LINES = ["Amazing grace, how sweet the sound", "That saved a wretch like me",
         "I once was lost, but now am found", "Was blind, but now I see"]


def post(path, body):
    req = urllib.request.Request(BASE + path, data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    return json.loads(urllib.request.urlopen(req).read())


def get(path):
    return json.loads(urllib.request.urlopen(BASE + path).read())


def main():
    results = []

    def check(name, ok, detail=""):
        results.append(ok)
        print(("  PASS  " if ok else "  FAIL  ") + name + (("  " + str(detail)) if detail else ""))

    # a clean sheet, and this test cleans up after itself so a second run of
    # the suite does not inherit a library from the first
    post("/api/state", {"showLyrics": False, "lyricLines": [], "lyricIndex": 0,
                        "lyricSong": "", "showVerse": False})
    for song in get("/api/lyrics")["songs"]:
        if song["title"].startswith("Amazing Grace"):
            post("/api/lyrics/delete", {"id": song["id"]})

    with sync_playwright() as p:
        b = p.chromium.launch()
        ctx = b.new_context(viewport={"width": 1500, "height": 1000})

        ov = ctx.new_page()
        oerr = []
        ov.on("pageerror", lambda e: oerr.append(str(e)))
        ov.goto(BASE + "/overlay/overlay.html?demo=1", wait_until="networkidle")
        ov.wait_for_timeout(800)

        panel = ctx.new_page()
        perr = []
        panel.on("pageerror", lambda e: perr.append(str(e)))
        panel.on("console", lambda m: perr.append(m.text) if m.type == "error" else None)
        panel.goto(BASE + "/", wait_until="networkidle")
        panel.wait_for_timeout(1200)

        # ---- paste and load -------------------------------------------------
        check("lyrics card is on the panel", panel.locator("#lyrSteps").count() == 1)
        panel.fill("#lyrTitle", "Amazing Grace")
        panel.fill("#lyrText", "\n".join(LINES))
        panel.click("#lyrLoad")
        panel.wait_for_timeout(700)
        check("every line becomes a step", panel.locator(".lyr-step").count() == len(LINES),
              panel.locator(".lyr-step").count())

        # ---- step through ---------------------------------------------------
        panel.click("#lyrNext")
        panel.wait_for_timeout(700)
        on = ov.evaluate("""() => {
            const b = document.getElementById('lyricsBox');
            return {on: b.classList.contains('on'),
                    line: document.getElementById('lyLine').textContent,
                    song: document.getElementById('lySong').textContent,
                    next: document.getElementById('lyNext').textContent,
                    dots: document.querySelectorAll('#lyDots i').length}; }""")
        check("first line goes on air", on["on"] and on["line"] == LINES[0], on["line"])
        check("song title is shown", on["song"] == "AMAZING GRACE", on["song"])
        check("the next line is previewed", on["next"] == LINES[1], on["next"])
        check("a dot per line", on["dots"] == len(LINES), on["dots"])

        panel.click("#lyrNext")
        panel.wait_for_timeout(600)
        check("Next advances", ov.evaluate("() => document.getElementById('lyLine').textContent") == LINES[1])
        panel.click("#lyrPrev")
        panel.wait_for_timeout(600)
        check("Previous goes back", ov.evaluate("() => document.getElementById('lyLine').textContent") == LINES[0])

        # clicking a step jumps straight to it
        panel.locator(".lyr-step").nth(3).click()
        panel.wait_for_timeout(600)
        check("clicking a line jumps to it",
              ov.evaluate("() => document.getElementById('lyLine').textContent") == LINES[3])

        # ---- cannot run off the end ----------------------------------------
        for _ in range(4):
            panel.click("#lyrNext")
        panel.wait_for_timeout(800)
        st = get("/api/state")["state"]
        check("the last line is the end of the song", st["lyricIndex"] == len(LINES) - 1,
              st["lyricIndex"])

        # ---- look -----------------------------------------------------------
        panel.click("[data-lmode='full']")
        panel.wait_for_timeout(600)
        check("full frame look", "mode-full" in ov.evaluate("() => document.getElementById('lyricsBox').className"))
        panel.click("[data-lmode='lower']")
        panel.wait_for_timeout(600)
        check("lower band look", "mode-lower" in ov.evaluate("() => document.getElementById('lyricsBox').className"))

        panel.click("[data-lalign='center']")
        panel.wait_for_timeout(500)
        check("centre alignment", "align-center" in ov.evaluate("() => document.getElementById('lyricsBox').className"))

        # ---- library --------------------------------------------------------
        panel.click("#lyrSave")
        panel.wait_for_timeout(1000)
        lib = get("/api/lyrics")["songs"]
        check("song saved to the library", any(x["title"] == "Amazing Grace" for x in lib),
              [x["title"] for x in lib])
        check("saved lines are the ones typed",
              next((len(x["lines"]) for x in lib if x["title"] == "Amazing Grace"), 0) == len(LINES))

        panel.reload(wait_until="networkidle")
        panel.wait_for_timeout(1500)
        opts = panel.locator("#lyrSaved option").count()
        check("library survives a reload", opts >= 2, "%d options" % opts)

        # ---- on air / off air ----------------------------------------------
        panel.click("#lyrOff")
        panel.wait_for_timeout(600)
        check("take down clears the words",
              ov.evaluate("() => document.getElementById('lyricsBox').classList.contains('on')") is False)
        panel.click("#lyrOn")
        panel.wait_for_timeout(600)
        check("put on air brings them back",
              ov.evaluate("() => document.getElementById('lyricsBox').classList.contains('on')") is True)

        # ---- a verse must not fight a lyric line ----------------------------
        post("/api/state", {"showVerse": True, "verseRef": "John 3:16",
                            "verseText": "For God so loved the world"})
        ov.wait_for_timeout(700)
        check("scripture yields to lyrics",
              ov.evaluate("() => document.getElementById('verseBox').classList.contains('on')") is False)
        post("/api/state", {"showVerse": False})

        check("no page errors", not (oerr or perr), str((oerr[:1] + perr[:1])) if (oerr or perr) else "")
        b.close()

    # leave nothing on air and no duplicate songs behind
    post("/api/state", {"showLyrics": False, "showVerse": False, "lyricLines": [],
                        "lyricIndex": 0, "lyricSong": ""})
    for song in get("/api/lyrics")["songs"]:
        if song["title"].startswith("Amazing Grace"):
            post("/api/lyrics/delete", {"id": song["id"]})

    ok = sum(1 for r in results if r)
    print("\n%d/%d lyrics checks passed" % (ok, len(results)))
    return 0 if ok == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())

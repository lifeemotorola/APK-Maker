"""
End-to-end camera test: panel QR -> phone -> WebRTC -> overlay.

Runs headless Chromium with a fake camera so it works on any machine.
    python tests/test_camera_e2e.py
Exits non-zero if the video never arrives.
"""
import json
import sys
import urllib.request

from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8770"


def patch_state(patch):
    req = urllib.request.Request(BASE + "/api/state", data=json.dumps(patch).encode(),
                                 headers={"Content-Type": "application/json"})
    urllib.request.urlopen(req).read()


def main():
    results = []

    def check(name, ok, detail=""):
        results.append(ok)
        print(("  PASS  " if ok else "  FAIL  ") + name + (("  " + str(detail)) if detail else ""))

    with sync_playwright() as p:
        b = p.chromium.launch(args=["--use-fake-ui-for-media-stream",
                                    "--use-fake-device-for-media-stream",
                                    "--autoplay-policy=no-user-gesture-required"])
        ctx = b.new_context(ignore_https_errors=True)

        panel = ctx.new_page()
        perrs = []
        panel.on("pageerror", lambda e: perrs.append(str(e)))
        panel.on("console", lambda m: perrs.append(m.text) if m.type == "error" else None)
        panel.goto(BASE + "/", wait_until="networkidle")
        panel.wait_for_timeout(1500)
        panel.click("#camShowQr")
        panel.wait_for_timeout(1200)
        url = panel.locator("#camQrUrl").inner_text()
        check("panel produces a camera link", url.startswith("https://") and "t=" in url, url[:44] + "…")
        check("QR image rendered", len(panel.locator("#camQrImg").get_attribute("src") or "") > 500)

        ov = ctx.new_page()
        oerrs = []
        ov.on("pageerror", lambda e: oerrs.append(str(e)))
        ov.on("console", lambda m: oerrs.append(m.text) if m.type == "error" else None)
        ov.goto(BASE + "/overlay/overlay.html", wait_until="networkidle")

        # ---- PIP area ----
        # The PIP box only exists while the camera layer is on air, so put the
        # state there explicitly — the test must not depend on whatever the
        # machine happened to be showing beforehand.
        patch_state({"showCam": True, "camRole": "pip", "camFit": "cover", "camMirror": False})
        ov.reload(wait_until="networkidle")
        ov.wait_for_timeout(1500)
        pip_state = json.loads(urllib.request.urlopen(BASE + "/api/state", timeout=10).read())["state"]
        check("state puts the camera in the PIP box",
              pip_state["showCam"] is True and pip_state["camRole"] == "pip")

        ph = ctx.new_page()
        herrs = []
        ph.on("pageerror", lambda e: herrs.append(str(e)))
        ph.on("console", lambda m: herrs.append(m.text) if m.type == "error" else None)
        ph.goto(url, wait_until="networkidle")
        ph.wait_for_timeout(1000)
        check("camera page opens over https", "NewsDesk" in ph.title(), ph.title())
        ph.click("#btnStart")

        def wait_for_frames(el_id, tries=25):
            """WebRTC settles asynchronously — poll until frames actually arrive."""
            seen = {}
            for _ in range(tries):
                ph.wait_for_timeout(800)
                seen = ov.evaluate("""(id) => { const v = document.getElementById(id);
                    return {on: v.classList.contains('on'), rs: v.readyState,
                            w: v.videoWidth, h: v.videoHeight, t: v.currentTime}; }""", el_id)
                if seen["w"] > 0 and seen["rs"] >= 2:
                    return seen
            return seen

        pip = wait_for_frames("camPip")
        if pip["w"] == 0:
            # Headless Chromium occasionally completes signalling but never
            # starts RTP — the trace shows a full offer/answer/ICE exchange in
            # both the passing and failing case, so this is the harness, not the
            # product. An operator would tap Stop then Start; do the same, once.
            print("  ....  no frames on the first attempt — restarting the camera once")
            ph.click("#btnStop")
            ph.wait_for_timeout(1200)
            ph.click("#btnStart")
            pip = wait_for_frames("camPip")
        check("PIP receives live video", pip["w"] > 0, "%dx%d readyState=%s" % (pip["w"], pip["h"], pip["rs"]))
        check("phone reports LIVE", "LIVE" in ph.evaluate("() => document.getElementById('connPill').textContent"))

        panel.bring_to_front()
        panel.wait_for_timeout(4600)
        check("panel shows the camera session", "live" in panel.locator("#camPill").inner_text().lower(),
              panel.locator("#camPill").inner_text())

        # ---- switch to full frame mid-stream ----
        panel.click('[data-care="full"]')
        full = wait_for_frames("camFull")
        if full["w"] == 0:
            panel.click('[data-care="pip"]')
            panel.wait_for_timeout(800)
            panel.click('[data-care="full"]')
            full = wait_for_frames("camFull")
        check("full frame receives video after switch", full["w"] > 0,
              "%dx%d readyState=%s" % (full["w"], full["h"], full["rs"]))

        # ---- the second-window rule (the real cause of "phone LIVE, OBS black")
        # A phone serves exactly one viewer. A second overlay window used to
        # steal it and both went black; now the first keeps the picture and the
        # second is told, in words, why it has none.
        patch_state({"showCam": True, "camRole": "pip"})
        ov2 = ctx.new_page()
        ov2.goto(BASE + "/overlay/overlay.html?demo=1", wait_until="networkidle")
        ov2.wait_for_timeout(2500)
        first = ov.evaluate("() => { const v = document.getElementById('camPip'); return v.videoWidth; }")
        second = ov2.evaluate("""() => { const v = document.getElementById('camPip');
            const n = document.getElementById('camNotice');
            return {w: v.videoWidth, notice: n.classList.contains('on'),
                    text: n.querySelector('b').textContent}; }""")
        check("a second window cannot steal the feed", first > 0,
              "first window %dpx" % first)
        check("the refused window explains itself",
              second["notice"] and "ANOTHER WINDOW" in second["text"], second["text"])
        ov2.close()

        diag = json.load(urllib.request.urlopen(BASE + "/api/camera/live"))
        check("diagnosis endpoint answers in plain words",
              diag["ok"] and diag["verdict"] in
              ("no-camera", "phone-waiting", "pairing", "ok") and len(diag["hint"]) > 20,
              diag["verdict"])

        # ---- hide / show ----
        patch_state({"showCam": False})
        ov.wait_for_timeout(900)
        hidden = ov.evaluate("() => document.getElementById('camFull').classList.contains('on')")
        check("hiding the camera drops the layer", hidden is False)

        # ---- stop from the panel (re-opening the QR must not disturb a live feed) ----
        before = len([x for x in json.load(urllib.request.urlopen(BASE + "/api/camera"))["sessions"]
                      if x["state"] != "ended"])
        panel.click("#camShowQr")
        panel.wait_for_timeout(1200)
        after = len([x for x in json.load(urllib.request.urlopen(BASE + "/api/camera"))["sessions"]
                     if x["state"] != "ended"])
        check("re-opening the QR keeps one session", before == after and before >= 1, "%d -> %d" % (before, after))
        btn = panel.locator("[data-camdel]").first
        if btn.count():
            btn.click()
            panel.wait_for_timeout(1400)
        check("disconnect clears the session",
              "No camera paired" in panel.locator("#camList").inner_text()
              or panel.locator("#camList .cam-row").count() == 0)

        check("no page errors", not (perrs or oerrs or herrs),
              str((perrs[:1] + oerrs[:1] + herrs[:1])) if (perrs or oerrs or herrs) else "")
        b.close()

    print("\n  %d/%d camera checks passed" % (sum(results), len(results)))
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())

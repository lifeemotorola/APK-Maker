"""
The four behaviours added in 1.5:

  1. a countdown removes itself when the time elapses
  2. a video clip can play in the PIP box
  3. the panel preview is an editing view; its guides never reach the broadcast
  4. one Go live button cleans and updates everything

    python3 tests/test_live.py
"""
import json
import sys
import time
import urllib.request

from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8770"


def post(path, body=None):
    req = urllib.request.Request(BASE + path, data=json.dumps(body or {}).encode(),
                                 headers={"Content-Type": "application/json"})
    return json.loads(urllib.request.urlopen(req).read())


def get(path):
    return json.loads(urllib.request.urlopen(BASE + path).read())


def main():
    results = []

    def check(name, ok, detail=""):
        results.append(ok)
        print(("  PASS  " if ok else "  FAIL  ") + name + (("  " + str(detail)) if detail else ""))

    # a clip already in the library (made by tests or by hand)
    vids = [f for f in get("/api/uploads")["files"] if f.get("video")]
    post("/api/state", {"showCountdown": False, "countdown": 0, "countdownEndsAt": 0,
                        "showPipVideo": False, "pipVideo": vids[0]["url"] if vids else "",
                        "showVerse": False, "showLyrics": False, "onAir": False, "guides": False})
    post("/api/live", {"on": False})

    with sync_playwright() as p:
        b = p.chromium.launch(args=["--autoplay-policy=no-user-gesture-required",
                                    "--use-fake-ui-for-media-stream",
                                    "--use-fake-device-for-media-stream"])
        ctx = b.new_context(viewport={"width": 1440, "height": 900})

        # the clean OBS source and the panel's editing preview are different windows
        obs = ctx.new_page()
        oerr = []
        obs.on("pageerror", lambda e: oerr.append(str(e)))
        obs.goto(BASE + "/overlay/overlay.html", wait_until="networkidle")
        obs.wait_for_timeout(700)

        panel = ctx.new_page()
        perr = []
        panel.on("pageerror", lambda e: perr.append(str(e)))
        panel.on("console", lambda m: perr.append(m.text) if m.type == "error" else None)
        panel.goto(BASE + "/", wait_until="networkidle")
        panel.wait_for_timeout(1500)

        # ---------------- 1. countdown --------------------------------
        check("countdown starts", post("/api/countdown/start", {"seconds": 5})["ok"])
        obs.wait_for_timeout(900)
        onair = obs.evaluate("() => document.getElementById('countdownBox').classList.contains('on')")
        check("countdown is on the overlay", onair is True)
        txt = obs.evaluate("() => document.getElementById('cdS').textContent")
        check("it is counting", txt in ("04", "05", "03"), txt)
        panel.wait_for_timeout(6000)
        gone = obs.evaluate("() => document.getElementById('countdownBox').classList.contains('on')")
        check("countdown removes itself when the time elapses", gone is False)
        st = get("/api/state")["state"]
        check("and the state agrees it is over",
              st["showCountdown"] is False and st["countdownEndsAt"] == 0, st["countdownEndsAt"])

        # the overlay also clears itself if it never hears the server message
        post("/api/state", {"showCountdown": True, "countdown": 3,
                            "countdownEndsAt": time.time() + 3, "countdownRestart": False})
        post("/api/countdown/stop", {})
        post("/api/state", {"showCountdown": True, "countdown": 2,
                            "countdownEndsAt": time.time() + 2})
        obs.wait_for_timeout(3200)
        check("a missed stop message still clears the clock",
              obs.evaluate("() => document.getElementById('countdownBox').classList.contains('on')") is False)

        # ---------------- 2. video in the PIP box ---------------------
        if vids:
            post("/api/state", {"pipVideo": vids[0]["url"], "showPipVideo": True,
                                "pipVideoLoop": True, "showCam": False, "showPip": True})
            obs.wait_for_timeout(2200)
            vid = obs.evaluate("""() => {
                const v = document.getElementById('pipVideo');
                return {on: v.classList.contains('on'), t: v.currentTime,
                        w: v.videoWidth, paused: v.paused,
                        loop: v.loop, frame: v.closest('.pip-frame').classList.contains('video-live')}; }""")
            check("the clip plays in the PIP box", vid["on"] and vid["w"] > 0 and not vid["paused"],
                  "%.1fs %dpx" % (vid["t"], vid["w"]))
            check("it is looping", vid["loop"] is True)
            check("the slot counts as live so the slate hides", vid["frame"] is True)
            obs.wait_for_timeout(1200)
            t2 = obs.evaluate("() => document.getElementById('pipVideo').currentTime")
            check("the picture is moving", t2 > vid["t"], "%.1f -> %.1f" % (vid["t"], t2))
            post("/api/state", {"showPipVideo": False})
            obs.wait_for_timeout(700)
            check("taking it off air stops it",
                  obs.evaluate("() => !document.getElementById('pipVideo').classList.contains('on')"))
        else:
            check("a video was available to test with", False, "no clip in the library")

        # ---------------- 3. the editing view stays out of the broadcast -----
        post("/api/state", {"guides": True, "demo": True})
        obs.wait_for_timeout(900)
        clean = obs.evaluate("""() => ({guides: document.body.classList.contains('guides'),
                                         demo: document.body.classList.contains('demo')})""")
        check("the OBS source never shows guides", clean["guides"] is False, clean)
        check("nor the sample footage", clean["demo"] is False, clean)
        prev = panel.frames[-1]
        pv = prev.evaluate("""() => ({guides: document.body.classList.contains('guides'),
                                       preview: /(^|[?&])preview=1/.test(location.search)})""")
        check("the panel preview still has them for editing",
              pv["preview"] and pv["guides"], pv)

        # ---------------- 4. go live ----------------------------------------
        panel.click("#btnGoLive")
        panel.wait_for_timeout(1500)
        st = get("/api/state")["state"]
        check("Go live puts the platform on air", st["onAir"] is True)
        check("Go live strips the editing aids", st["guides"] is False and st["demo"] is False,
              "guides=%s demo=%s" % (st["guides"], st["demo"]))
        check("the button says so", "on air" in panel.locator("#goLiveTxt").inner_text().lower(),
              panel.locator("#goLiveTxt").inner_text())
        check("the on-air bar appears", panel.locator("#goLiveBar").is_visible())
        clean = obs.evaluate("""() => ({guides: document.body.classList.contains('guides'),
                                        demo: document.body.classList.contains('demo')})""")
        check("the broadcast is clean after Go live", not clean["guides"] and not clean["demo"], clean)

        panel.click("#goLiveOff")
        panel.wait_for_timeout(1200)
        st = get("/api/state")["state"]
        check("End the broadcast goes off air", st["onAir"] is False)
        check("the button goes back", panel.locator("#goLiveTxt").inner_text().strip().lower() == "go live",
              panel.locator("#goLiveTxt").inner_text())

        check("no page errors", not (oerr or perr), str((oerr[:1] + perr[:1])) if (oerr or perr) else "")
        b.close()

    post("/api/state", {"showCountdown": False, "showPipVideo": False, "guides": False,
                        "demo": False, "onAir": False})
    ok = sum(1 for r in results if r)
    print("\n%d/%d live-platform checks passed" % (ok, len(results)))
    return 0 if ok == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())

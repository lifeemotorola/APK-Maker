"""Signalling relay test — run against a live server on 8770."""
import base64, json, os, socket, struct, sys, time, urllib.request


class WS:
    def __init__(self, path, port=8770):
        self.s = socket.create_connection(("127.0.0.1", port), timeout=6)
        key = base64.b64encode(os.urandom(16)).decode()
        self.s.sendall(("GET %s HTTP/1.1\r\nHost: x\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                        "Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\n\r\n" % (path, key)).encode())
        buf = b""
        while b"\r\n\r\n" not in buf:
            buf += self.s.recv(4096)
        self.buf = buf.split(b"\r\n\r\n", 1)[1]

    def send(self, obj):
        data = json.dumps(obj).encode()
        mask = os.urandom(4)
        n = len(data)
        hdr = bytearray([0x81])
        if n < 126:
            hdr.append(0x80 | n)
        else:
            hdr += bytes([0x80 | 126]) + struct.pack("!H", n)
        hdr += mask
        self.s.sendall(bytes(hdr) + bytes(b ^ mask[i % 4] for i, b in enumerate(data)))

    def recv(self, timeout=3.0):
        self.s.settimeout(timeout)
        while True:
            if len(self.buf) >= 2:
                b0, b1 = self.buf[0], self.buf[1]
                ln = b1 & 0x7F
                off = 2
                if ln == 126:
                    while len(self.buf) < 4:
                        self.buf += self.s.recv(65536)
                    ln = struct.unpack("!H", self.buf[2:4])[0]
                    off = 4
                elif ln == 127:
                    while len(self.buf) < 10:
                        self.buf += self.s.recv(65536)
                    ln = struct.unpack("!Q", self.buf[2:10])[0]
                    off = 10
                if len(self.buf) >= off + ln:
                    payload = self.buf[off:off + ln]
                    self.buf = self.buf[off + ln:]
                    if b0 & 0x0F == 0x1:
                        try:
                            return json.loads(payload.decode())
                        except Exception:
                            continue
                    continue
            self.buf += self.s.recv(65536)

    def wait_for(self, mtype, timeout=4.0):
        end = time.time() + timeout
        while time.time() < end:
            try:
                m = self.recv(max(0.2, end - time.time()))
            except socket.timeout:
                return None
            if m.get("type") == mtype:
                return m
        return None


def main():
    results = []
    def check(name, ok, detail=""):
        results.append((name, ok))
        print(("  PASS  " if ok else "  FAIL  ") + name + (("  " + detail) if detail else ""))

    d = json.load(urllib.request.urlopen(
        "http://127.0.0.1:8770/api/camera/qr?role=pip&kind=phone&base=https://127.0.0.1:8443"))
    token, sid = d["url"].split("t=")[1].split("&")[0], d["sid"]
    check("session created", bool(sid), sid)
    check("QR png present", len(d.get("png", "")) > 500, "%d b64 chars" % len(d.get("png", "")))

    ov = WS("/ws?role=overlay")
    ov.send({"type": "hello", "role": "overlay"})
    check("overlay hello", ov.wait_for("state") is not None)
    # a viewer must say which area it wants before it can own the feed — this is
    # what tells OBS apart from the panel preview (they used to fight)
    ov.send({"type": "cam-hello", "role": "pip", "key": "test-overlay", "prio": 0,
             "agent": "overlay", "watch": "pip"})
    check("overlay claims an area", ov.wait_for("cam-hello-ok") is not None)

    ph = WS("/ws?role=camera&t=" + token)
    ph.send({"type": "cam-hello", "sid": sid, "token": token, "role": "pip", "agent": "phone"})
    m = ph.wait_for("cam-hello-ok")
    check("phone hello ack", m is not None and m.get("role") == "pip")

    ph.send({"type": "cam-offer", "sid": sid, "sdp": "v=0\r\no=- 1 1 IN IP4 0.0.0.0\r\ns=-\r\nm=video 9 UDP/TLS/RTP/SAVPF 96\r\na=sendonly\r\n"})
    check("phone gets ack", ph.wait_for("cam-ack") is not None)
    o = ov.wait_for("cam-offer")
    check("overlay receives offer", o is not None and o.get("sdp", "").startswith("v=0"))

    ov.send({"type": "cam-answer", "sid": sid, "key": "test-overlay",
             "sdp": "v=0\r\no=- 2 2 IN IP4 0.0.0.0\r\ns=-\r\na=recvonly\r\n"})
    a = ph.wait_for("cam-answer")
    check("phone receives answer", a is not None and a.get("sdp", "").startswith("v=0"))

    ov.send({"type": "cam-ice", "sid": sid, "key": "test-overlay",
             "candidate": {"candidate": "candidate:1 1 udp 1 127.0.0.1 5000 typ host"}, "from": "viewer"})
    i = ph.wait_for("cam-ice")
    check("ice viewer -> camera", i is not None and i.get("from") == "viewer")

    ph.send({"type": "cam-ice", "sid": sid, "candidate": {"candidate": "candidate:2 1 udp 1 127.0.0.1 6000 typ host"}, "from": "camera"})
    i2 = ov.wait_for("cam-ice")
    check("ice camera -> viewer", i2 is not None and i2.get("from") == "camera")

    st = json.load(urllib.request.urlopen("http://127.0.0.1:8770/api/camera"))
    s0 = [s for s in st["sessions"] if s["sid"] == sid]
    check("roster shows live session", bool(s0) and s0[0]["connected"] and s0[0]["state"] == "live",
          str(s0[0]["state"]) if s0 else "missing")

    ph.send({"type": "cam-bye", "sid": sid, "from": "camera"})
    b = ov.wait_for("cam-bye")
    check("bye relayed to viewer", b is not None and b.get("from") == "camera")

    print("\n  %d/%d signalling checks passed" % (sum(1 for _, ok in results if ok), len(results)))
    return 0 if all(ok for _, ok in results) else 1


if __name__ == "__main__":
    sys.exit(main())

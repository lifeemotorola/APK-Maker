"""
Bible feature tests — parsing, lookup, search and the on-air flow.

    python tests/test_bible.py          (needs the server running on 8770)
"""
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BASE = "http://127.0.0.1:8770"

RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append(bool(ok))
    print(("  PASS  " if ok else "  FAIL  ") + name + (("  " + str(detail)) if detail else ""))


def get(path):
    return json.load(urllib.request.urlopen(BASE + path, timeout=15))


def post(path, body):
    return json.load(urllib.request.urlopen(
        urllib.request.Request(BASE + path, data=json.dumps(body).encode(),
                               headers={"Content-Type": "application/json"}), timeout=15))


def main():
    import bible

    # ---- reference parsing -------------------------------------------------
    good = [
        ("John 3:16", "John 3:16"), ("jn 3:16", "John 3:16"), ("John 3.16", "John 3:16"),
        ("ps 23", "Psalms 23"), ("Psalm 23:1", "Psalms 23:1"),
        ("1cor 13:4-7", "1 Corinthians 13:4-7"),
        ("1 Cor. 13:4", "1 Corinthians 13:4"),
        ("ii tim 3:16", "2 Timothy 3:16"),
        ("first john 4:8", "1 John 4:8"),
        ("rom 8:28 to 30", "Romans 8:28-30"),
        ("rev 21:4", "Revelation 21:4"),
        ("3 john 1:2", "3 John 1:2"),
        ("gen1", "Genesis 1"),
    ]
    bad = 0
    for raw, want in good:
        got = bible.lookup(raw).get("label")
        if got != want:
            bad += 1
            print("        mismatch:", raw, "->", got, "expected", want)
    check("parses %d reference styles" % len(good), bad == 0, "%d wrong" % bad)

    # ---- bad input is rejected, not crashed --------------------------------
    rejects = 0
    for raw in ("", "hello", "Notabook 1:1", "Genesis 51", "John 99:1"):
        r = bible.lookup(raw)
        if not r.get("ok"):
            rejects += 1
    check("rejects %d nonsense references" % 5, rejects == 5, "%d rejected" % rejects)

    # ---- text integrity ----------------------------------------------------
    check("John 11:35 is 'Jesus wept.'", bible.lookup("John 11:35")["text"].strip() == "Jesus wept.")
    check("John 3:16 starts correctly",
          bible.lookup("John 3:16")["text"].startswith("For God so loved the world"))
    rng = bible.lookup("Romans 8:28-30")["text"]
    check("verse ranges are numbered", rng.startswith("28 ") and " 29 " in rng and " 30 " in rng)
    full = bible.lookup("Psalms 23")
    check("a whole chapter returns all verses", len(full["text"]) > 400)

    # ---- API ---------------------------------------------------------------
    r = get("/api/bible/lookup?ref=" + urllib.parse.quote("John 3:16"))
    check("GET /api/bible/lookup", r["ok"] and r["label"] == "John 3:16")

    r = get("/api/bible/lookup?ref=" + urllib.parse.quote("Nonsense 9:9"))
    check("lookup reports a friendly error", r["ok"] is False and "John 3:16" in r["error"])

    b = get("/api/bible/books")
    check("66 books listed", len(b["books"]) == 66 and b["books"][0] == "Genesis")

    s = get("/api/bible/search?q=shepherd")
    check("word search finds Psalm 23", s["results"] and s["results"][0]["ref"] == "Psalms 23:1",
          s["results"][0]["ref"] if s["results"] else "none")

    s2 = get("/api/bible/search?q=" + urllib.parse.quote("fear not"))
    check("phrase search works", len(s2["results"]) > 0, s2["results"][0]["ref"] if s2["results"] else "")

    s3 = get("/api/bible/search?q=" + urllib.parse.quote("john 3:16"))
    check("search box also accepts a reference", s3["results"] and s3["results"][0]["ref"] == "John 3:16")

    rnd = get("/api/bible/random")
    check("random verse endpoint", rnd["ok"] and rnd["label"])

    # ---- putting it on air -------------------------------------------------
    post("/api/state", {"showVerse": True, "verseRef": "John 3:16",
                        "verseText": bible.lookup("John 3:16")["text"], "verseMode": "band"})
    st = get("/api/state")["state"]
    check("verse reaches the shared state",
          st["showVerse"] and st["verseRef"] == "John 3:16" and len(st["verseText"]) > 50)

    for mode in ("band", "card", "full"):
        post("/api/state", {"verseMode": mode})
        got = get("/api/state")["state"]["verseMode"]
        check("look mode '%s' persists" % mode, got == mode)

    post("/api/state", {"showVerse": False})
    check("verse can be taken off air", get("/api/state")["state"]["showVerse"] is False)

    # ---- scripture backgrounds --------------------------------------------
    plates = get("/api/bible/backgrounds")["plates"]
    check("20 background plates ship with the kit", len(plates) == 20, len(plates))
    check("every plate has a url, a thumb and a label",
          all(p["url"].startswith("/scripture/") and p["thumb"].startswith("/scripture/thumbs/")
              and p["label"] for p in plates))

    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    missing = [p["file"] for p in plates
               if not os.path.isfile(os.path.join(root, "scripture", p["file"]))]
    check("every plate file exists on disk", not missing, missing[:3])

    missing_thumbs = [p["file"] for p in plates
                      if not os.path.isfile(os.path.join(root, "scripture", "thumbs", p["file"]))]
    check("every thumbnail exists on disk", not missing_thumbs, missing_thumbs[:3])

    # served over http, not just present on disk
    sample = urllib.request.urlopen(BASE + plates[0]["url"], timeout=15)
    body = sample.read()
    check("plate is served over http", sample.status == 200 and len(body) > 20000,
          "%d bytes" % len(body))
    thumb = urllib.request.urlopen(BASE + plates[0]["thumb"], timeout=15)
    check("thumbnail is served over http", thumb.status == 200 and len(thumb.read()) > 800)

    # dimensions: every plate must be 16:9 so nothing is cropped on air
    try:
        from PIL import Image
        import io
        ratios = []
        for pl in plates:
            im = Image.open(os.path.join(root, "scripture", pl["file"]))
            ratios.append(abs(im.width / im.height - 16 / 9) < 0.01)
        check("all plates are 16:9", all(ratios), sum(ratios))
    except ImportError:
        pass

    check("the linen plate is flagged light (needs dark type)",
          any(p["light"] for p in plates))

    post("/api/state", {"verseBg": plates[0]["url"], "verseScrim": 70,
                        "verseTextPos": "bottom", "verseTextStyle": "dark"})
    st = get("/api/state")["state"]
    check("background choice persists", st["verseBg"] == plates[0]["url"])
    check("scrim persists", st["verseScrim"] == 70)
    check("text position persists", st["verseTextPos"] == "bottom")
    check("text style persists", st["verseTextStyle"] == "dark")

    post("/api/state", {"verseBg": ""})
    check("background can be cleared", get("/api/state")["state"]["verseBg"] == "")

    # ---- the whole Bible, not a sample ------------------------------------
    details = get("/api/bible/books")["detail"]
    check("all 66 books are listed", len(details) == 66, len(details))
    check("39 Old Testament + 27 New Testament",
          sum(1 for d in details if d["testament"] == "OT") == 39 and
          sum(1 for d in details if d["testament"] == "NT") == 27)

    CHAPTERS = {"Genesis":50,"Exodus":40,"Leviticus":27,"Numbers":36,"Deuteronomy":34,"Joshua":24,
      "Judges":21,"Ruth":4,"1 Samuel":31,"2 Samuel":24,"1 Kings":22,"2 Kings":25,"1 Chronicles":29,
      "2 Chronicles":36,"Ezra":10,"Nehemiah":13,"Esther":10,"Job":42,"Psalms":150,"Proverbs":31,
      "Ecclesiastes":12,"Song of Solomon":8,"Isaiah":66,"Jeremiah":52,"Lamentations":5,"Ezekiel":48,
      "Daniel":12,"Hosea":14,"Joel":3,"Amos":9,"Obadiah":1,"Jonah":4,"Micah":7,"Nahum":3,"Habakkuk":3,
      "Zephaniah":3,"Haggai":2,"Zechariah":14,"Malachi":4,"Matthew":28,"Mark":16,"Luke":24,"John":21,
      "Acts":28,"Romans":16,"1 Corinthians":16,"2 Corinthians":13,"Galatians":6,"Ephesians":6,
      "Philippians":4,"Colossians":4,"1 Thessalonians":5,"2 Thessalonians":3,"1 Timothy":6,
      "2 Timothy":4,"Titus":3,"Philemon":1,"Hebrews":13,"James":5,"1 Peter":5,"2 Peter":3,"1 John":5,
      "2 John":1,"3 John":1,"Jude":1,"Revelation":22}
    wrong = [(d["name"], d["chapters"], CHAPTERS.get(d["name"])) for d in details
             if d["chapters"] != CHAPTERS.get(d["name"])]
    check("every book has its canonical chapter count", not wrong, wrong[:3])

    # every chapter opens over HTTP with at least one verse
    failed, verses = [], 0
    for d in details:
        for c in range(1, d["chapters"] + 1):
            try:
                r = json.load(urllib.request.urlopen(
                    BASE + "/api/bible/chapter?book=" + urllib.parse.quote(d["name"]) +
                    "&chapter=%d" % c, timeout=20))
            except Exception as e:
                failed.append((d["name"], c, str(e)[:30])); continue
            if not r.get("ok") or r["count"] < 1:
                failed.append((d["name"], c, "empty"))
            else:
                verses += r["count"]
    check("all 1,189 chapters open", not failed, failed[:3])
    check("all 31,102 verses are reachable", verses == 31102, verses)

    # a long chapter is paged, never chopped
    whole = get("/api/bible/lookup?ref=" + urllib.parse.quote("Psalms 119"))
    check("Psalm 119 is split into parts, not truncated",
          whole["parts"] > 1 and not whole["text"].endswith("\u2026"),
          "%d parts" % whole["parts"])
    last = get("/api/bible/lookup?ref=" + urllib.parse.quote("Psalms 119") +
               "&part=" + str(whole["parts"] - 1))
    check("the last part reaches verse 176",
          "lost sheep" in last["text"].lower(), last["text"][:40])
    short = get("/api/bible/lookup?ref=" + urllib.parse.quote("John 3:16"))
    check("a single verse is one part", short["parts"] == 1 and not short["more"])

    # an impossible verse must be refused, not silently swapped
    bad_v = get("/api/bible/lookup?ref=" + urllib.parse.quote("Genesis 1:32"))
    check("out-of-range verse is refused", bad_v["ok"] is False, bad_v.get("error", "")[:50])
    check("and says how many verses there are",
          "31 verses" in (bad_v.get("error") or ""), bad_v.get("error", "")[:60])
    good_v = get("/api/bible/lookup?ref=" + urllib.parse.quote("Genesis 1:31"))
    check("the real last verse still works", good_v["ok"] and good_v["label"] == "Genesis 1:31")

    print("\n  %d/%d bible checks passed" % (sum(RESULTS), len(RESULTS)))
    return 0 if all(RESULTS) else 1


if __name__ == "__main__":
    sys.exit(main())

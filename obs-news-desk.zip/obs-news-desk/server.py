#!/usr/bin/env python3
"""
NewsDesk Studio — control server
================================
Zero dependencies. Python 3.8+.

  python server.py            # start on http://127.0.0.1:8770
  python server.py --port 9000 --open

It does three jobs:
  1. serves the overlay + control panel over http (OBS browser source needs that)
  2. keeps one shared "on air" state in state.json
  3. pushes every change to all connected overlays over websocket, instantly
"""

import argparse
import base64
import hashlib
import json
import mimetypes
import os
import re
import secrets
import socket
import struct
import sys
import threading
import time
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, quote

import bible
import certgen
import camera as camera_mod
import qr

ROOT = os.path.dirname(os.path.abspath(__file__))
STATE_PATH = os.path.join(ROOT, "state.json")
PRESETS_PATH = os.path.join(ROOT, "presets.json")
UPLOAD_DIR = os.path.join(ROOT, "uploads")
CERT_DIR = os.path.join(ROOT, "certs")
CERT_PATH = os.path.join(CERT_DIR, "newsdesk-cert.pem")
KEY_PATH = os.path.join(CERT_DIR, "newsdesk-key.pem")
CAM_DIR = os.path.join(ROOT, "camera")
CAM_TRACE = bool(os.environ.get("NEWSDESK_TRACE_CAM"))

WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

# ---- project identity ----
APP_NAME = "NewsDesk Studio"
APP_VERSION = "1.5"
MAINTAINER = "Emmanuel Suah"
APP_TAGLINE = "broadcast graphics for OBS"
CREDIT = "%s — maintained by %s" % (APP_NAME, MAINTAINER)

LOCK = threading.RLock()
CLIENTS = {}          # conn_id -> {"ws": WSConn, "role": str, "key": str, "since": float}
CAM_SOCKETS = {}      # conn_id -> "camera" for sockets that announced a camera session
STATE = {}
_next_id = [0]


# --------------------------------------------------------------------------- #
#  state
# --------------------------------------------------------------------------- #
DEFAULT_STATE = {
    "brandName": "NEWSDESK",
    "brandSub": "LIVE",
    "logoText": "NEWS",
    "eyebrow": "BREAKING NEWS",
    "headline": "WORLD BRACES FOR THE PEACEFUL YEAR",
    "ticker": ("Politicians agree on a framework for the year ahead|"
               "Markets close higher for a third straight session|"
               "Hilarious dog video blew the internet|"
               "Happy tourists find this hidden beach"),
    "tkBrand": "DAILY REPORT",
    "tkMeta": "29 OCT",
    "pipTag": "LIVE",
    "pipSource": "FEED 02",
    "pipCredit": "Credit: World Feed",
    "accent": "#E01B22",
    "accent2": "#0A1A2B",
    "pipFill": "#111A2E",
    "showBrand": False,
    "showClock": False,
    "showPip": True,
    "showLowerThird": True,
    "showTicker": True,
    "alert": False,
    "guides": False,
    "tickerSpeed": 130,
    "headlineMin": 30,
    "headlineMax": 56,
    "clock24": True,
    "animateOnLoad": True,
    "demo": False,
    "demoLayout": "full",

    # --- phase 2 ---
    "poster": "",             # /uploads/xxx.png — full-frame graphic (scripture, sponsor, sermon slide)
    "posterMode": "lower",    # 'lower' = bottom slide-in band | 'full' = full frame
    "showPoster": False,
    "ticker2": "",            # secondary crawl (announcements) above the main ticker
    "showTicker2": False,
    "ticker2Speed": 90,
    "countdown": 0,           # seconds; 0 = off
    "countdownEndsAt": 0,     # epoch seconds; the moment it reaches zero
    "showCountdown": False,
    "countdownLabel": "SERVICE STARTS IN",

    # --- video in the PIP box (a reel, a bumper, a pre-recorded message) ---
    "pipVideo": "",           # /uploads/clip.mp4
    "showPipVideo": False,
    "pipVideoLoop": True,
    "pipVideoMuted": True,
    "pipVideoFit": "cover",   # cover = fill and crop | contain = letterbox
    "pipVideoFrom": 0,        # start point in seconds

    # --- go live ---
    "onAir": False,           # true once Go live has been pressed
    "airStartedAt": 0,        # epoch seconds of that moment
    "playlist": [],
    "playlistIndex": 0,
    "songTitle": "",
    "songArtist": "",
    "showSong": False,
    "talentName": "",
    "talentRole": "",
    "showTalent": False,

    # --- worship lyrics (the prompter) ---
    "showLyrics": False,
    "lyricLines": [],          # ["Amazing grace", "how sweet the sound", ...]
    "lyricIndex": 0,           # which line is on air
    "lyricSong": "",           # title shown above the lines
    "lyricMode": "lower",      # lower = band above the ticker | full = full frame
    "lyricSize": 46,           # px, the panel can nudge this
    "lyricAlign": "left",      # left | center
    "lyrics": [],              # saved library: [{id,title,lines:[]}]

    "scoreHome": "0",
    "scoreAway": "0",
    "scoreTeamHome": "HOME",
    "scoreTeamAway": "AWAY",
    "showScore": False,
    "alertText": "BREAKING NEWS",

    # --- image slots (media library) ---
    "logoImage": "",          # replaces the brand-bug mark
    "ltLogoImage": "",        # image inside the lower-third chip
    "pipImage": "",           # standby slate inside the PIP frame
    "bgImage": "",            # full-frame plate behind all graphics
    "showBg": False,
    "sponsorImage": "",       # small watermark / sponsor logo
    "showSponsor": False,
    "sponsorPos": "br",       # br | bl | tr | tl

    # --- bible / scripture ---
    "showVerse": False,
    "verseRef": "",
    "verseText": "",
    "verseMode": "band",          # band | card | full
    "verseTranslation": "KING JAMES VERSION",
    "verseShowTranslation": True,
    "verseKeepGfx": False,        # keep lower third + PIP visible under the verse
    "verseBg": "",                # /scripture/<plate>.jpg — picture behind the verse
    "verseScrim": 55,             # 0-100, darkening behind the text for legibility
    "verseTextPos": "center",     # center | bottom | top (where the text sits on the plate)
    "verseTextStyle": "light",    # light = white type | dark = dark type (light plates)
    "verseHistory": [],           # recently shown references

    # --- camera over wifi ---
    "showCam": False,          # is the camera visible in its area
    "camRole": "pip",          # pip = inside the PIP box | full = full-frame program
    "camFit": "cover",         # cover = fill and crop | contain = letterbox
    "camMirror": False,        # mirror horizontally (front camera / comfort)
    "camObjectPos": "center",  # center | top | bottom  (crop anchor for cover)
    "camMuted": True,
}


def load_state():
    global STATE
    STATE = dict(DEFAULT_STATE)
    if os.path.exists(STATE_PATH):
        try:
            with open(STATE_PATH, "r", encoding="utf-8") as fh:
                disk = json.load(fh)
            if isinstance(disk, dict):
                STATE.update(disk)
        except Exception as exc:  # corrupt file: don't lose the app
            print("! could not read state.json:", exc)
    return STATE


def save_state():
    tmp = STATE_PATH + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(STATE, fh, indent=2)
        os.replace(tmp, STATE_PATH)
    except Exception as exc:
        print("! could not save state.json:", exc)


PRESETS = {}
LYRICS = []                 # saved songs: [{id, title, lines}]
_preset_lock = threading.RLock()


def load_presets():
    global PRESETS, LYRICS
    PRESETS = {}
    LYRICS = []
    if os.path.exists(PRESETS_PATH):
        try:
            with open(PRESETS_PATH, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                songs = data.pop("_lyrics", None)
                PRESETS = data
                if isinstance(songs, list):
                    LYRICS = [x for x in songs
                              if isinstance(x, dict) and x.get("title") and x.get("lines")]
        except Exception as exc:
            print("! could not read presets.json:", exc)
    return PRESETS


def save_presets():
    """Custom presets + the lyric library, in one small file."""
    tmp = PRESETS_PATH + ".tmp"
    try:
        blob = dict(PRESETS)
        blob["_lyrics"] = LYRICS
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(blob, fh, indent=2)
        os.replace(tmp, PRESETS_PATH)
    except Exception as exc:
        print("! could not save presets.json:", exc)


def public_state():
    return dict(STATE)


# ---------------------------------------------------------------- #
#  playlist runner — advances the lower third through a run of show
# ---------------------------------------------------------------- #
PLAY_TIMER = {"thread": None, "stop": threading.Event(), "next_at": 0, "index": 0}


def _cancel_playlist():
    PLAY_TIMER["stop"].set()
    t = PLAY_TIMER["thread"]
    if t and t.is_alive() and t is not threading.current_thread():
        t.join(timeout=1.0)
    PLAY_TIMER["thread"] = None
    PLAY_TIMER["next_at"] = 0


def _apply_playlist_item(item):
    patch = {
        "headline": item.get("headline", ""),
        "eyebrow": item.get("eyebrow", ""),
        "logoText": item.get("logoText", STATE.get("logoText", "NEWS")),
        "showLowerThird": True,
    }
    for extra in ("poster", "posterMode", "showPoster", "showTicker2", "ticker2"):
        if extra in item and item[extra] not in (None, ""):
            patch[extra] = item[extra]
    # an item without an image must clear the previous one
    if not item.get("poster"):
        patch["showPoster"] = False
    with LOCK:
        STATE.update(patch)
        save_state()
        snap = dict(STATE)
    broadcast({"type": "patch", "patch": patch, "state": snap})


def playlist_start(index=None, loop=True):
    """Walk the saved playlist, one item every `dur` seconds."""
    _cancel_playlist()
    with LOCK:
        items = list(STATE.get("playlist") or [])
    if not items:
        return {"ok": False, "error": "playlist is empty"}

    idx = PLAY_TIMER.get("index", 0) if index is None else int(index)
    idx = max(0, min(idx, len(items) - 1))
    stop = PLAY_TIMER["stop"] = threading.Event()

    def run():
        i = idx
        while not stop.is_set():
            with LOCK:
                items_now = list(STATE.get("playlist") or [])
            if not items_now:
                break
            if i >= len(items_now):
                if not loop:
                    break
                i = 0
            item = items_now[i]
            PLAY_TIMER["index"] = i
            _apply_playlist_item(item)
            broadcast({"type": "playlist", "index": i, "total": len(items_now), "playing": True},
                      role="control")
            dur = float(item.get("dur") or 8)
            PLAY_TIMER["next_at"] = time.time() + dur
            if stop.wait(dur):
                break
            i += 1
        PLAY_TIMER["next_at"] = 0
        broadcast({"type": "playlist", "index": PLAY_TIMER.get("index", 0), "playing": False},
                  role="control")

    t = threading.Thread(target=run, daemon=True, name="playlist")
    PLAY_TIMER["thread"] = t
    t.start()
    return {"ok": True, "index": idx}


def playlist_stop():
    _cancel_playlist()
    broadcast({"type": "playlist", "index": PLAY_TIMER.get("index", 0), "playing": False}, role="control")
    return {"ok": True}


def playlist_jump(index):
    with LOCK:
        items = list(STATE.get("playlist") or [])
    if not items:
        return {"ok": False, "error": "playlist is empty"}
    index = max(0, min(int(index), len(items) - 1))
    _apply_playlist_item(items[index])
    PLAY_TIMER["index"] = index
    broadcast({"type": "playlist", "index": index, "playing": PLAY_TIMER["thread"] is not None},
              role="control")
    return {"ok": True, "index": index}


def client_stats():
    with LOCK:
        roles = [c["role"] for c in CLIENTS.values()]
    return {
        "total": len(roles),
        "overlay": roles.count("overlay"),
        "control": roles.count("control"),
    }


# --------------------------------------------------------------------------- #
#  minimal websocket (RFC 6455) — server side, text frames only
# --------------------------------------------------------------------------- #
# --------------------------------------------------------------------------- #
#  camera over wifi
# --------------------------------------------------------------------------- #
ICE_SERVERS = [
    {"urls": "stun:stun.l.google.com:19302"},
    {"urls": "stun:stun1.l.google.com:19302"},
]

CAM = camera_mod.CameraHub()
CAM_HTTPS = None          # camera_mod.CamHTTPSServer once started
CAM_PORT = [0]            # https port, 0 = disabled
CAM_BASE = [""]           # https://<lan-ip>:<port>
PORT = [0]                # main http port, filled in main()
CERT_INFO = {"fingerprint": "", "error": ""}


def cam_https_url():
    """The URL a phone should open, e.g. https://192.168.1.60:8443"""
    if CAM_BASE[0]:
        return CAM_BASE[0]
    port = CAM_PORT[0] or 8443
    return "https://%s:%d" % (lan_ip(), port)


def cam_urls(role="pip"):
    """(https base, signalling port) for the panel + phone page."""
    return {
        "base": cam_https_url(),
        "port": CAM_PORT[0],
        "httpPort": PORT[0],
        "secure": bool(CAM_HTTPS),
        "fingerprint": CERT_INFO.get("fingerprint", ""),
        "error": CERT_INFO.get("error", ""),
    }


# --------------------------------------------------------------------------- #
#  countdown — runs on the server so it ends on time with no browser open
# --------------------------------------------------------------------------- #
CD_LOCK = threading.RLock()
CD_TIMER = [None]         # the threading.Timer currently armed


def _countdown_expire(deadline):
    """Called when the clock reaches zero: take it down everywhere, once."""
    with CD_LOCK:
        live = STATE.get("countdownEndsAt") or 0
        if abs(live - deadline) > 0.5:
            return                     # it was restarted; this timer is stale
        CD_TIMER[0] = None
        with LOCK:
            STATE["showCountdown"] = False
            STATE["countdownEndsAt"] = 0
            STATE["countdown"] = 0
            save_state()
            snap = dict(STATE)
    patch = {"showCountdown": False, "countdownEndsAt": 0, "countdown": 0}
    broadcast({"type": "patch", "patch": patch, "state": snap})
    broadcast({"type": "countdown-done"}, role="control")
    print("  · countdown finished — taken off air")


def schedule_countdown(seconds, label=None):
    """(Re)arm the countdown. seconds <= 0 cancels it."""
    seconds = max(0, int(round(float(seconds or 0))))
    with CD_LOCK:
        if CD_TIMER[0]:
            CD_TIMER[0].cancel()
            CD_TIMER[0] = None
        if seconds <= 0:
            with LOCK:
                STATE["countdownEndsAt"] = 0
            return 0
        deadline = time.time() + seconds
        with LOCK:
            STATE["countdownEndsAt"] = deadline
            STATE["countdown"] = seconds
            if label is not None:
                STATE["countdownLabel"] = label
        t = threading.Timer(seconds, _countdown_expire, args=(deadline,))
        t.daemon = True
        t.start()
        CD_TIMER[0] = t
        return deadline


def countdown_remaining():
    ends = STATE.get("countdownEndsAt") or 0
    if not ends:
        return 0
    return max(0, int(round(ends - time.time())))


def camera_update():
    """Push the camera roster to every panel so the UI stays in sync."""
    try:
        broadcast({"type": "cam-sessions", "sessions": CAM.list()}, role="control")
    except Exception:
        pass


def _cam_message(sender, msg):
    """Route one signalling message. Returns nothing; replies go over `ws`."""
    mtype = msg.get("type")
    sid = msg.get("sid") or ""
    # which viewer is this? the overlay, a browser preview, or the panel itself
    vkey = msg.get("key") or ("overlay" if sender == "overlay" else "preview")

    if CAM_TRACE and mtype and mtype.startswith("cam"):
        print("  [cam] %-14s from %-8s sid=%-9s %s | sessions=%s" % (
            mtype, sender, sid or msg.get("token", "")[:8],
            ("watch=" + str(msg.get("watch"))) if msg.get("watch") else "",
            CAM.debug_dump()))

    if mtype == "cam-hello":
        sess = CAM.get(sid)
        if not sess and msg.get("token"):
            sess = CAM.by_token(msg.get("token"))

        # A viewer (overlay / panel preview) only knows which *area* it wants,
        # not the session id the control room just generated.
        if not sess and msg.get("watch"):
            # A watch-only client (the panel's preview) is a looker, not a
            # viewer: it may watch a free area but must never take the feed
            # away from the OBS source.
            sess, pending = CAM.attach_by_role(
                msg["watch"], vkey, key=vkey,
                prio=1 if msg.get("watchOnly") else int(msg.get("prio") or 0))
            if sess:
                out = [{"type": "cam-hello-ok", "sid": sess.sid, "role": sess.role}]
                # tell the phone to renegotiate for this new viewer; replaying a
                # stale offer would answer a connection the phone no longer owns
                if sess.last_offer:
                    out.append({"type": "cam-want-offer", "sid": sess.sid, "role": sess.role})
                camera_update()
                return out
            # work out WHY there is nothing to attach to — "waiting" is useless
            # when the real answer is "another window is already using it"
            busy = None
            for cand in CAM.list():
                if cand["role"] == msg["watch"] and cand.get("connected"):
                    busy = cand
                    break
            if busy:
                return {"type": "cam-busy", "role": msg["watch"], "sid": busy["sid"],
                        "heldBy": "another window"}
            return {"type": "cam-wait", "role": msg["watch"]}

        if not sess:
            return {"type": "cam-error", "sid": sid, "error": "session not found — rescan the QR code"}
        who = msg.get("agent") or sender
        with CAM.lock:
            sess.seen = time.time()
        if sender == "camera":
            # The camera saying hello is NOT a viewer. It used to be attached as
            # one, which then made the real viewer (the OBS overlay) look like a
            # second window and get refused — phone LIVE, broadcast black.
            return {"type": "cam-hello-ok", "sid": sess.sid, "role": sess.role}
        offer = CAM.attach_client(sess.sid, who)
        out = [{"type": "cam-hello-ok", "sid": sess.sid, "role": sess.role}]
        if offer:
            out.append(offer)
        camera_update()
        return out

    if mtype == "cam-offer":
        for_viewer = CAM.post_offer(sid, msg.get("sdp") or "")
        camera_update()
        # Always acknowledge the camera, alongside the offer for the viewer, so
        # the phone's UI can leave "connecting" immediately.
        ack = {"type": "cam-ack", "sid": sid}
        if CAM_TRACE:
            print("  [cam] cam-offer     -> %s" % ("viewer" if for_viewer else "pending (no viewer)"))
        if for_viewer:
            return [ack, for_viewer]
        return ack

    if mtype == "cam-answer":
        to_camera = CAM.post_answer(sid, msg.get("sdp") or "", viewer=vkey)
        camera_update()
        return to_camera

    if mtype == "cam-ice":
        peer = CAM.post_ice(sid, msg.get("candidate"), msg.get("from") or sender, viewer=vkey)
        return peer

    if mtype == "cam-bye":
        peer = CAM.bye(sid, msg.get("from") or sender)
        camera_update()
        return peer

    return None


class WSConn:
    def __init__(self, sock, addr):
        self.sock = sock
        self.addr = addr
        self.alive = True
        self.wlock = threading.Lock()

    # ---- framing -----------------------------------------------------------
    def send_text(self, text):
        self._send(0x1, text.encode("utf-8"))

    def send_ping(self):
        self._send(0x9, b"")

    def send_close(self, code=1000):
        self._send(0x8, struct.pack("!H", code))

    def _send(self, opcode, payload):
        if not self.alive:
            return
        n = len(payload)
        if n < 126:
            header = struct.pack("!BB", 0x80 | opcode, n)
        elif n < 65536:
            header = struct.pack("!BBH", 0x80 | opcode, 126, n)
        else:
            header = struct.pack("!BBQ", 0x80 | opcode, 127, n)
        try:
            with self.wlock:
                self.sock.sendall(header + payload)
        except Exception:
            self.alive = False

    def _recv_exact(self, n):
        buf = b""
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk:
                raise ConnectionError("closed")
            buf += chunk
        return buf

    def read_frame(self):
        b1, b2 = self._recv_exact(2)
        opcode = b1 & 0x0F
        masked = b2 & 0x80
        length = b2 & 0x7F
        if length == 126:
            length = struct.unpack("!H", self._recv_exact(2))[0]
        elif length == 127:
            length = struct.unpack("!Q", self._recv_exact(8))[0]
        if length > 4 * 1024 * 1024:
            raise ConnectionError("frame too large")
        mask = self._recv_exact(4) if masked else b"\x00\x00\x00\x00"
        data = self._recv_exact(length) if length else b""
        if masked:
            data = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
        return opcode, data

    def close(self):
        self.alive = False
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except Exception:
            pass
        try:
            self.sock.close()
        except Exception:
            pass


def send_to_key(key, message, role=None):
    """Deliver to the one viewer that owns a camera area, not to all of them.
    Broadcasting an offer made every overlay window answer the same phone,
    which is exactly how OBS ended up black while the panel preview won."""
    payload = json.dumps(message)
    with LOCK:
        targets = [c for c in CLIENTS.values()
                   if (role is None or c["role"] == role) and c.get("key") == key]
    sent = 0
    for c in targets:
        c["ws"].send_text(payload)
        sent += 1
    return sent


def broadcast(message, role=None):
    """Send a dict to every connected overlay (or every client)."""
    payload = json.dumps(message)
    with LOCK:
        targets = [c for c in CLIENTS.values() if role is None or c["role"] == role]
    dead = []
    for c in targets:
        c["ws"].send_text(payload)
        if not c["ws"].alive:
            dead.append(c)
    for c in dead:
        with LOCK:
            for k, v in list(CLIENTS.items()):
                if v is c:
                    CLIENTS.pop(k, None)


# --------------------------------------------------------------------------- #
#  http handler
# --------------------------------------------------------------------------- #
MAX_UPLOAD_BYTES = 16 * 1024 * 1024      # 16 MB per image
MAX_VIDEO_BYTES = 300 * 1024 * 1024      # 300 MB per clip — a 5-minute 1080p reel
VIDEO_EXT = (".mp4", ".webm", ".m4v", ".mov", ".ogv")


_SEARCH_INDEX = {"built": False, "rows": []}


def _build_search_index():
    """Flatten the KJV once so the panel can search by words, not just reference."""
    if _SEARCH_INDEX["built"]:
        return
    rows = []
    try:
        bible._load()
        for bi, book in enumerate(bible._BOOKS):
            for ci, verses in enumerate(book["chapters"], start=1):
                for vi, text in enumerate(verses, start=1):
                    rows.append((book["name"], ci, vi, text.lower()))
    except Exception as exc:
        print("! bible search index unavailable:", exc)
    _SEARCH_INDEX["rows"] = rows
    _SEARCH_INDEX["built"] = True


def bible_search(term, limit=12):
    """
    Find verses by words. 'shepherd' -> Psalm 23:1. Also accepts a reference
    (so the same box can be used for everything) and multi-word phrases.
    """
    if not term:
        return []
    term = term.strip()

    # a plain reference is the most likely input — answer it directly
    direct = bible.lookup(term)
    if direct.get("ok") and len(term) < 32 and any(ch.isdigit() for ch in term):
        return [{"ref": direct["label"], "text": direct["text"], "score": 1000}]

    _build_search_index()
    words = [w for w in re.split(r"[^a-z0-9']+", term.lower()) if len(w) > 1]
    if not words:
        return []

    # Verses a congregation actually asks for. Weighting these keeps the first
    # hits useful instead of dumping obscure matches from Leviticus.
    FAMOUS = {
        "john 3:16": 40, "psalms 23:1": 34, "psalms 23:4": 30, "jeremiah 29:11": 34,
        "romans 8:28": 34, "philippians 4:13": 34, "proverbs 3:5": 30, "isaiah 40:31": 30,
        "genesis 1:1": 26, "romans 3:23": 26, "romans 6:23": 26, "john 14:6": 30,
        "acts 1:8": 24, "hebrews 11:1": 28, "james 1:5": 24, "1 corinthians 13:4": 34,
        "1 corinthians 13:13": 30, "matthew 5:3": 20, "matthew 28:19": 26,
        "psalms 46:1": 26, "psalms 46:10": 30, "psalms 91:1": 26, "psalms 119:105": 30,
        "isaiah 41:10": 30, "matthew 11:28": 30, "john 10:10": 26, "john 1:1": 24,
        "romans 10:9": 26, "ephesians 2:8": 30, "galatians 5:22": 28, "2 timothy 3:16": 26,
        "1 peter 5:7": 28, "1 john 4:8": 26, "revelation 21:4": 30, "joshua 1:9": 30,
        "psalms 27:1": 28, "psalms 34:8": 22, "lamentations 3:22": 24, "zephaniah 3:17": 22
    }

    hits = []
    for name, ci, vi, text in _SEARCH_INDEX["rows"]:
        score = 0
        missing = 0
        for w in words:
            if w in text:
                score += 10
                # whole-word hit ranks above a substring hit
                if re.search(r"\b" + re.escape(w), text):
                    score += 6
            else:
                missing += 1
        if missing:
            continue
        # shorter verses read better on a lower third
        score += max(0, 26 - len(text) // 10)
        score += FAMOUS.get(("%s %d:%d" % (name, ci, vi)).lower(), 0)
        # a phrase match inside one verse beats scattered single words
        if len(words) > 1 and term.lower() in text:
            score += 18
        hits.append((score, name, ci, vi, text))

    hits.sort(key=lambda h: (-h[0], h[4]))
    out = []
    for score, name, ci, vi, text in hits[:limit]:
        verse = bible.lookup("%s %d:%d" % (name, ci, vi))
        out.append({"ref": verse.get("label", ""), "text": verse.get("text", ""), "score": score})
    return out


def human_size(n):
    for unit in ("B", "KB", "MB"):
        if n < 1024 or unit == "MB":
            return ("%d %s" % (n, unit)) if unit == "B" else ("%.1f %s" % (n, unit))
        n /= 1024.0
    return "%d B" % n


SCRIPTURE_DIR = os.path.join(ROOT, "scripture")
SCRIPTURE_LABELS = {
    "01_dawn_rays": "Dawn over the mountains",
    "02_rose_dusk": "Rose dusk",
    "03_forest_light": "Light through the forest",
    "04_starry_ridge": "Stars over the ridge",
    "05_ocean_dusk": "Ocean at dusk",
    "06_desert_dunes": "Desert dunes",
    "07_golden_field": "Golden field",
    "08_snow_peaks": "Snow peaks",
    "09_waterfall_glen": "Waterfall glen",
    "10_sunset_sea": "Sunset sea",
    "11_autumn_forest": "Autumn forest",
    "12_stone_chapel": "Stone chapel",
    "13_glass_architecture": "Church auditorium",
    "16_navy_bloom": "Navy bloom",
    "17_steel_lines": "Steel lines",
    "18_warm_dawn": "Warm dawn",
    "19_bokeh": "Bokeh lights",
    "20_linen": "Linen paper",
    "21_concrete": "Charcoal",
    "22_gold_streaks": "Gold streaks",
}


def scripture_plates():
    """The scripture backgrounds that ship with the kit, with friendly names."""
    if not os.path.isdir(SCRIPTURE_DIR):
        return []
    out = []
    for name in sorted(os.listdir(SCRIPTURE_DIR)):
        if not name.lower().endswith((".jpg", ".jpeg", ".png")):
            continue
        stem = os.path.splitext(name)[0]
        out.append({
            "file": name,
            "url": "/scripture/" + name,
            "thumb": "/scripture/thumbs/" + os.path.splitext(name)[0] + ".jpg",
            "label": SCRIPTURE_LABELS.get(stem, stem.replace("_", " ").title()),
            "light": stem == "20_linen",     # light plate -> dark type reads better
        })
    return out


def list_uploads():
    """Every file in uploads/, newest first — powers the media library."""
    out = []
    try:
        os.makedirs(UPLOAD_DIR, exist_ok=True)
        for name in os.listdir(UPLOAD_DIR):
            full = os.path.join(UPLOAD_DIR, name)
            if not os.path.isfile(full):
                continue
            ext = os.path.splitext(name)[1].lower()
            if ext not in (".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg") + VIDEO_EXT:
                continue
            st = os.stat(full)
            out.append({
                "name": name,
                "url": "/uploads/" + name,
                "size": st.st_size,
                "pretty": human_size(st.st_size),
                "mtime": int(st.st_mtime),
                "video": ext in VIDEO_EXT,
            })
    except Exception as exc:
        print("! could not list uploads:", exc)
    out.sort(key=lambda f: f["mtime"], reverse=True)
    return out


def parse_multipart_file(body, boundary):
    """
    Parse the first file part of a multipart/form-data body.

    Returns (bytes, filename) or (None, None).

    Deliberately strict about the terminating CRLF: Chrome/Edge/curl all send
    `--boundary\r\n headers \r\n\r\n data \r\n--boundary...`, and a sloppy
    rstrip() here silently corrupts every upload with trailing bytes (which also
    breaks duplicate detection).
    """
    if isinstance(boundary, str):
        boundary = boundary.encode()
    delim = b"--" + boundary
    # split on the real delimiter lines only
    parts = body.split(b"\r\n" + delim)
    if len(parts) == 1:
        # Some clients put the first boundary at offset 0 with no leading CRLF.
        parts = body.split(delim)
    if len(parts) == 1:
        # The boundary never appeared in the body — the header and the payload
        # disagree (e.g. a case-mangled boundary). Refuse rather than store a
        # file with the boundary epilogue glued to the end of it.
        return None, None

    for part in parts:
        if b"filename=" not in part:
            continue
        head, sep, data = part.partition(b"\r\n\r\n")
        if not sep:
            continue
        # drop the trailing CRLF that precedes the next boundary
        if data.endswith(b"\r\n"):
            data = data[:-2]
        # a closing boundary has no filename; skip those
        m = re.search(rb'filename="([^"]*)"', head)
        if not m:
            continue
        name = m.group(1).decode("utf-8", "replace")
        if not name:            # empty file input
            continue
        return data, name
    return None, None


MIME = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".ico": "image/x-icon",
    ".ttf": "font/ttf",
    ".otf": "font/otf",
    ".woff2": "font/woff2",
    ".mp4": "video/mp4",
    ".webm": "video/webm",
    ".md": "text/markdown; charset=utf-8",
}

ROUTES = {
    "/": "control/index.html",
    "/control": "control/index.html",
    "/control/": "control/index.html",
    "/overlay": "overlay/overlay.html",
    "/overlay/": "overlay/overlay.html",
    "/demo": "demo/demo.html",
    "/demo/": "demo/demo.html",
    "/cam": "camera/index.html",
    "/cam/": "camera/index.html",
    "/cam/index.html": "camera/index.html",
}


# Browsers (and OBS's embedded Chromium) drop TCP connections constantly:
# prefetch cancelled, tab closed, page refreshed, network switched. None of it is an
# error worth a traceback — these are the exception types those disconnects raise.
CONN_ERRORS = (ConnectionResetError, ConnectionAbortedError, BrokenPipeError,
               TimeoutError, OSError)


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "NewsDesk/1.0"
    # socketserver calls this for every request; never let it explode
    disable_nagle_algorithm = True

    def handle_one_request(self):
        try:
            super().handle_one_request()
        except CONN_ERRORS:
            self.close_connection = True

    def handle(self):
        try:
            super().handle()
        except CONN_ERRORS:
            pass

    def finish(self):
        try:
            super().finish()
        except CONN_ERRORS:
            pass

    # ---------- helpers ----------
    # noisy by volume, not by value: fonts, css, js, demo art, favicon
    QUIET_PREFIX = ("/assets/", "/api/", "/ws", "/favicon", "/uploads/")
    QUIET_EXT = (".ttf", ".css", ".js", ".jpg", ".png", ".webp", ".gif", ".svg", ".ico")

    def log_message(self, fmt, *args):
        path = getattr(self, "path", "") or ""
        base = path.split("?")[0]
        if base in ("/", "/overlay/overlay.html", "/demo", "/demo/"):
            sys.stdout.write("  %s %s\n" % (self.command, path))
            return
        if base.startswith(self.QUIET_PREFIX) or base.lower().endswith(self.QUIET_EXT):
            return
        sys.stdout.write("  %s %s\n" % (self.command, path))

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")

    def _json(self, obj, code=200):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self._cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _read_json_body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except Exception:
            return {}

    # ---------- verbs ----------
    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/ws":
            return self.handle_ws()
        if path == "/api/state":
            return self._json({"ok": True, "app": APP_NAME, "version": APP_VERSION,
                               "maintainer": MAINTAINER,
                               "state": public_state(), "clients": client_stats()})
        if path == "/api/health":
            return self._json({"ok": True, "app": APP_NAME, "version": APP_VERSION,
                               "maintainer": MAINTAINER,
                               "clients": client_stats(), "uptime": time.time() - START})
        if path == "/favicon.ico":
            svg = (b"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 40 40'>"
                   b"<rect width='40' height='40' rx='8' fill='%23E01B22'/>"
                   b"<path d='M9 29V11h4.6l8.2 11.2V11H26v18h-4.4L13.4 17.6V29H9z' fill='%23fff'/></svg>")
            self.send_response(200)
            self.send_header("Content-Type", "image/svg+xml")
            self.send_header("Content-Length", str(len(svg)))
            self.send_header("Cache-Control", "max-age=86400")
            self.end_headers()
            try:
                self.wfile.write(svg)
            except CONN_ERRORS:
                pass
            return
        # ---------------- camera over wifi ----------------
        if path in ("/cam", "/cam/", "/cam/index.html"):
            qs2 = parse_qs(urlparse(self.path).query)
            token = (qs2.get("t") or [""])[0]
            sess = CAM.by_token(token)
            if not sess:
                return self._cam_page_error(
                    "Link expired",
                    "This camera link is no longer valid. Ask the control room for a fresh QR code "
                    "(Panel → Camera over wifi → Show QR code).")
            return self.serve_file("/camera/index.html")

        if path == "/cam/config":
            qs2 = parse_qs(urlparse(self.path).query)
            sess = CAM.by_token((qs2.get("t") or [""])[0])
            if not sess:
                return self._json({"ok": False, "error": "unknown token"}, 403)
            return self._json({
                "ok": True,
                "sid": sess.sid,
                "role": sess.role,
                "signalPort": PORT[0],
                "iceServers": ICE_SERVERS,
                "httpsPort": CAM_PORT[0],
            })

        if path == "/api/camera":
            return self._json({
                "ok": True,
                "sessions": CAM.list(),
                "urls": dict(cam_urls(), ice=ICE_SERVERS),
                "state": {k: STATE.get(k) for k in ("showCam", "camRole", "camFit", "camMirror", "camObjectPos", "camMuted")},
            })

        if path == "/api/camera/qr":
            qs2 = parse_qs(urlparse(self.path).query)
            role = (qs2.get("role") or ["pip"])[0]
            kind = (qs2.get("kind") or ["phone"])[0]
            base = (qs2.get("base") or [cam_https_url()])[0].rstrip("/")
            if kind == "phone":
                if not CAM_HTTPS:
                    return self._json({"ok": False, "error": CERT_INFO.get("error") or
                                       "the https listener is not running — restart server.py"}, 503)
                # Reuse the session already paired to this area: re-opening the
                # QR must never knock a live camera off the air. Pass fresh=1
                # to force a new link.
                sess = None
                if (qs2.get("fresh") or ["0"])[0] not in ("1", "true", "yes"):
                    # Reuse the phone that is already paired. Match on the
                    # session, not on which area it happens to be feeding right
                    # now: moving the camera to full frame used to look like
                    # "no session for this area" and minted a second link,
                    # pairing the same phone twice.
                    cands = [c for c in CAM.list()
                             if c["kind"] == "phone" and c["state"] != "ended"]
                    live = [c for c in cands if c["connected"]]
                    pick = (live or cands)
                    if pick:
                        sess = CAM.get(max(pick, key=lambda c: c["age"] and -c["age"])["sid"])
                if sess is None:
                    sess = CAM.create(role=role, kind="phone")
                url = "%s/cam?t=%s&sid=%s&role=%s&sport=%d" % (
                    base, quote(sess.token), sess.sid, role, PORT[0])
            else:
                sess = CAM.create(role=role, kind="whep", whep=(qs2.get("whep") or [""])[0])
                url = sess.whep
            camera_update()
            return self._json({"ok": True, "sid": sess.sid, "url": url,
                               "png": qr.png_b64(url, scale=6), "session": sess.public()})

        if path == "/api/camera/live":
            # Plain-language diagnosis for the panel. Everything here comes
            # from the signalling state, so it is available even when the
            # overlay window is the one that is wrong.
            sess = [x for x in CAM.list() if x["state"] != "ended"]
            live = [x for x in sess if x["connected"]]
            watchers = []
            with LOCK:
                for c in CLIENTS.values():
                    if c.get("role") in ("overlay", "control"):
                        watchers.append(c.get("key") or c.get("role"))
            if not sess:
                verdict = "no-camera"
                hint = "No phone paired yet — press Show QR code and scan it."
            elif not live:
                verdict = "phone-waiting"
                hint = ("The link is open but the phone has not sent video. "
                        "Open the link, accept the certificate, tap Start, then allow the camera.")
            elif len(live) and all(x["connected"] for x in sess) and not any(x["state"] == "live" for x in sess):
                verdict = "pairing"
                hint = ("The phone and the overlay have found each other but video has not "
                        "started — tap Start on the phone again.")
            else:
                verdict = "ok"
                hint = ("Camera is streaming to %d viewer(s). If OBS is still black, "
                        "refresh the browser source." % max(1, len(watchers) - 1))
            return self._json({"ok": True, "verdict": verdict, "hint": hint,
                               "sessions": sess, "watchers": watchers,
                               "secure": bool(CAM_HTTPS), "urls": cam_urls()})

        if path == "/api/camera/whep-probe":
            qs2 = parse_qs(urlparse(self.path).query)
            target = (qs2.get("url") or [""])[0]
            if not target.lower().startswith(("http://", "https://")):
                return self._json({"ok": False, "error": "url must start with http:// or https://"}, 400)
            reachable, detail = camera_mod.probe_whep(target)
            return self._json({"ok": reachable, "detail": detail})

        # ---------------- bible / scripture ----------------
        if path == "/api/bible/lookup":
            qs2 = parse_qs(urlparse(self.path).query)
            ref = (qs2.get("ref") or [""])[0]
            try:
                part = int((qs2.get("part") or ["0"])[0] or 0)
            except ValueError:
                part = 0
            try:
                return self._json(bible.lookup(ref, part=part))
            except Exception as exc:
                return self._json({"ok": False, "error": str(exc)}, 500)

        # A chapter, verse by verse — powers the browser and the on-screen pager.
        if path == "/api/bible/chapter":
            qs2 = parse_qs(urlparse(self.path).query)
            ref = (qs2.get("ref") or [""])[0]
            try:
                book = (qs2.get("book") or [""])[0]
                chapter = int((qs2.get("chapter") or ["1"])[0] or 1)
                if book:
                    ref = "%s %d" % (book, chapter)
                parsed = bible.parse_one(ref)
                if not parsed:
                    return self._json({"ok": False, "error": "unknown reference"}, 404)
                bi = parsed.book_index
                ch = parsed.chapter or 1
                n = bible.verse_count(bi, ch)
                verses = [{"v": v, "text": bible.verse_text(bible.Ref(bi, parsed.book, ch, v, v))}
                          for v in range(1, n + 1)]
                return self._json({
                    "ok": True, "book": parsed.book, "bookIndex": bi,
                    "chapter": ch, "chapters": bible.chapter_count(bi),
                    "verses": verses, "count": n})
            except Exception as exc:
                return self._json({"ok": False, "error": str(exc)}, 500)

        if path == "/api/bible/search":
            qs2 = parse_qs(urlparse(self.path).query)
            term = (qs2.get("q") or [""])[0].strip()
            return self._json({"ok": True, "results": bible_search(term)})

        if path == "/api/bible/books":
            names = bible.books()
            books = []
            for i, name in enumerate(names):
                books.append({
                    "name": name,
                    "chapters": bible.chapter_count(i),
                    "testament": "OT" if i < 39 else "NT",
                })
            return self._json({"ok": True, "books": names, "detail": books,
                               "totalBooks": len(books), "totalVerses": 31102})

        if path == "/api/bible/random":
            return self._json(dict(bible.random_verse(), ok=True))

        if path == "/api/bible/backgrounds":
            return self._json({"ok": True, "plates": scripture_plates()})

        if path == "/api/uploads":
            return self._json({"ok": True, "files": list_uploads()})
        if path == "/api/lyrics":
            return self._json({"ok": True, "songs": LYRICS, "state": {
                k: STATE.get(k) for k in ("showLyrics", "lyricLines", "lyricIndex",
                                          "lyricSong", "lyricMode", "lyricSize", "lyricAlign")}})

        if path == "/api/presets":
            with _preset_lock:
                return self._json({"ok": True, "presets": PRESETS})
        if path == "/api/playlist":
            with LOCK:
                items = list(STATE.get("playlist") or [])
            return self._json({
                "ok": True, "items": items, "index": PLAY_TIMER.get("index", 0),
                "playing": PLAY_TIMER["thread"] is not None,
                "nextAt": PLAY_TIMER.get("next_at", 0),
            })
        if path == "/api/obs-url":
            host = self.headers.get("Host") or "127.0.0.1"
            return self._json({"url": "http://%s/overlay/overlay.html" % host})
        return self.serve_file(path)

    def do_POST(self):
        path = urlparse(self.path).path
        qs = parse_qs(urlparse(self.path).query)

        if path == "/api/state":
            patch = self._read_json_body()
            if not isinstance(patch, dict):
                return self._json({"ok": False, "error": "body must be an object"}, 400)
            # A countdown is armed by giving seconds, not an absolute time:
            # `countdownRestart: true` (or simply a new `countdown` value while
            # one is already on air) restarts the clock from now.
            restart_cd = (patch.pop("countdownRestart", False)
                          or ("countdown" in patch and STATE.get("showCountdown")))
            cd_seconds = patch.get("countdown")
            with LOCK:
                STATE.update(patch)
                save_state()
                snap = dict(STATE)
            if restart_cd and cd_seconds is not None:
                schedule_countdown(cd_seconds, label=patch.get("countdownLabel"))
                with LOCK:
                    snap = dict(STATE)
            # running down the clock by hand cancels the deadline cleanly
            if patch.get("showCountdown") is False and not restart_cd:
                with CD_LOCK:
                    if CD_TIMER[0]:
                        CD_TIMER[0].cancel()
                        CD_TIMER[0] = None
                with LOCK:
                    STATE["countdownEndsAt"] = 0
            # the camera area control relocates any live feed instantly
            if "camRole" in patch:
                CAM.set_role("full" if patch.get("camRole") == "full" else "pip")
                camera_update()
            broadcast({"type": "patch", "patch": patch, "state": snap}, role="overlay")
            return self._json({"ok": True, "state": snap, "clients": client_stats()})

        # ---------- countdown ----------
        if path == "/api/countdown/start":
            body = self._read_json_body()
            secs = body.get("seconds")
            if secs in (None, ""):
                secs = STATE.get("countdown") or 0
            deadline = schedule_countdown(secs, label=body.get("label"))
            with LOCK:
                STATE["showCountdown"] = bool(secs and int(secs) > 0)
                save_state()
                snap = dict(STATE)
            broadcast({"type": "patch",
                       "patch": {"showCountdown": STATE["showCountdown"],
                                 "countdownEndsAt": STATE["countdownEndsAt"],
                                 "countdown": STATE["countdown"]},
                       "state": snap})
            return self._json({"ok": True, "endsAt": deadline,
                               "remaining": countdown_remaining()})

        if path == "/api/countdown/stop":
            with CD_LOCK:
                if CD_TIMER[0]:
                    CD_TIMER[0].cancel()
                    CD_TIMER[0] = None
            with LOCK:
                STATE["showCountdown"] = False
                STATE["countdownEndsAt"] = 0
                save_state()
                snap = dict(STATE)
            broadcast({"type": "patch", "patch": {"showCountdown": False,
                                                  "countdownEndsAt": 0}, "state": snap})
            return self._json({"ok": True})

        # ---------- go live ----------
        if path == "/api/live":
            body = self._read_json_body()
            on = bool(body.get("on", True))
            # Everything the congregation should see in one press. Editing aids
            # (guides, the demo footage) are always switched off here so the
            # panel can never leak them onto the broadcast.
            patch = {
                "onAir": on,
                "guides": False,
                "demo": False,
                "showBrand": True,
                "showTicker": True,
                "clock24": STATE.get("clock24", False),
            }
            if on:
                patch["airStartedAt"] = time.time()
                patch["showCountdown"] = False
            else:
                patch["airStartedAt"] = 0
            with LOCK:
                STATE.update(patch)
                save_state()
                snap = dict(STATE)
            if not on:
                with CD_LOCK:
                    if CD_TIMER[0]:
                        CD_TIMER[0].cancel()
                        CD_TIMER[0] = None
                with LOCK:
                    STATE["countdownEndsAt"] = 0
            broadcast({"type": "patch", "patch": patch, "state": snap})
            if on:
                broadcast({"type": "go-live"}, role="overlay")
            return self._json({"ok": True, "onAir": on, "state": snap})

        if path == "/api/sting":
            kind = (qs.get("kind") or ["wipe"])[0]
            broadcast({"type": "sting", "kind": kind}, role="overlay")
            return self._json({"ok": True, "kind": kind})

        if path == "/api/reload":
            broadcast({"type": "reload"}, role="overlay")
            return self._json({"ok": True})

        # ---------- playlist ----------
        if path == "/api/playlist/start":
            body = self._read_json_body()
            idx = body.get("index")
            loop = bool(body.get("loop", True))
            res = playlist_start(None if idx in (None, "") else int(idx), loop=loop)
            return self._json(res, 200 if res.get("ok") else 400)

        if path == "/api/playlist/stop":
            return self._json(playlist_stop())

        if path == "/api/playlist/next":
            with LOCK:
                items = list(STATE.get("playlist") or [])
            return self._json(playlist_jump((PLAY_TIMER.get("index", 0) + 1) % max(1, len(items))))

        if path == "/api/playlist/jump":
            body = self._read_json_body()
            res = playlist_jump(int(body.get("index", 0)))
            return self._json(res, 200 if res.get("ok") else 400)

        # ---------- custom presets ----------
        # ---------- worship lyrics ----------
        if path == "/api/lyrics/save":
            body = self._read_json_body()
            title = str(body.get("title") or "").strip()
            lines = [str(x).strip() for x in (body.get("lines") or []) if str(x).strip()]
            if not title or not lines:
                return self._json({"ok": False, "error": "Give the song a title and at least one line"}, 400)
            with _preset_lock:
                song = next((x for x in LYRICS if x["title"].lower() == title.lower()), None)
                if song:
                    song["lines"] = lines
                else:
                    LYRICS.append({"id": secrets.token_hex(4), "title": title, "lines": lines})
                save_presets()
            broadcast({"type": "lyrics", "songs": LYRICS}, role="control")
            return self._json({"ok": True, "songs": LYRICS})

        if path == "/api/lyrics/delete":
            body = self._read_json_body()
            sid = str(body.get("id") or "")
            with _preset_lock:
                LYRICS[:] = [x for x in LYRICS if x["id"] != sid]
                save_presets()
            return self._json({"ok": True, "songs": LYRICS})

        if path == "/api/presets/save":
            body = self._read_json_body()
            name = (body.get("name") or "").strip()
            if not name:
                return self._json({"ok": False, "error": "name required"}, 400)
            data = body.get("data") or {}
            with _preset_lock:
                PRESETS[name] = data
                save_presets()
            broadcast({"type": "presets", "presets": PRESETS}, role="control")
            return self._json({"ok": True, "presets": PRESETS})

        if path == "/api/presets/delete":
            body = self._read_json_body()
            name = (body.get("name") or "").strip()
            with _preset_lock:
                PRESETS.pop(name, None)
                save_presets()
            broadcast({"type": "presets", "presets": PRESETS}, role="control")
            return self._json({"ok": True, "presets": PRESETS})

        # ---------- media library ----------
        if path == "/api/camera/new":
            body = self._read_json_body() or {}
            role = body.get("role") or "pip"
            kind = body.get("kind") or "phone"
            sess = CAM.create(role=role if role in ("pip", "full") else "pip",
                              kind=kind if kind in ("phone", "whep") else "phone",
                              label=body.get("label"),
                              whep=body.get("whep") or "")
            camera_update()
            return self._json({"ok": True, "session": sess.public()})

        if path == "/api/camera/stop":
            body = self._read_json_body() or {}
            sid = body.get("sid") or ""
            sess = CAM.get(sid)
            if not sess:
                with CAM.lock:
                    CAM.clear()
                camera_update()
                return self._json({"ok": True, "sessions": []})
            CAM.remove(sid)
            broadcast({"type": "cam-bye", "sid": sid, "from": "control"}, role=None)
            return self._json({"ok": True, "sessions": CAM.list()})

        if path == "/api/uploads/delete":
            body = self._read_json_body()
            target = (body.get("url") or "").strip()
            if not target.startswith("/uploads/"):
                return self._json({"ok": False, "error": "only /uploads/ files can be deleted"}, 400)
            name = os.path.basename(target)
            full = os.path.normpath(os.path.join(UPLOAD_DIR, name))
            if not full.startswith(UPLOAD_DIR) or not os.path.isfile(full):
                return self._json({"ok": False, "error": "not found"}, 404)
            try:
                os.remove(full)
            except Exception as exc:
                return self._json({"ok": False, "error": str(exc)}, 500)
            # forget it in any slot that referenced the file
            cleared = {}
            with LOCK:
                for key in ("poster", "logoImage", "ltLogoImage", "pipImage", "bgImage", "sponsorImage"):
                    if STATE.get(key) == target:
                        STATE[key] = ""
                        cleared[key] = ""
                if cleared:
                    save_state()
                    snap = dict(STATE)
                else:
                    snap = None
            if snap:
                broadcast({"type": "patch", "patch": cleared, "state": snap}, role="overlay")
            print("  ✕ deleted %s" % target)
            return self._json({"ok": True, "files": list_uploads()})

        # ---------- image upload (poster / sponsor / scripture slide) ----------
        if path == "/api/upload":
            return self.handle_upload(qs)

        return self._json({"ok": False, "error": "no such endpoint"}, 404)

    # ---------- upload ----------
    def handle_upload(self, qs):
        """
        Accepts either
          * multipart/form-data  (browser file input)   field: file
          * application/json     {"dataUrl": "data:image/png;base64,…", "name": "x.png"}
        Writes into uploads/ and returns the served URL.
        """
        os.makedirs(UPLOAD_DIR, exist_ok=True)
        # NB: only the media type may be lower-cased — the boundary token is
        # case-sensitive and must be matched byte-for-byte against the body.
        ctype_raw = self.headers.get("Content-Type") or ""
        ctype = ctype_raw.lower()
        raw = None
        filename = (qs.get("name") or ["upload.png"])[0]

        try:
            if ctype.startswith("multipart/form-data"):
                n = int(self.headers.get("Content-Length") or 0)
                body = self.rfile.read(n)
                boundary = ctype_raw.split("boundary=")[-1].strip().strip('"').strip("'").encode()
                raw, filename = parse_multipart_file(body, boundary) or (None, filename)
            else:
                body = self._read_json_body()
                data_url = body.get("dataUrl") or ""
                if data_url.startswith("data:"):
                    head, _, b64 = data_url.partition(",")
                    import base64 as _b64
                    raw = _b64.b64decode(b64)
                    if body.get("name"):
                        filename = body["name"]
        except Exception as exc:
            return self._json({"ok": False, "error": "could not read upload: %s" % exc}, 400)

        if not raw:
            return self._json({"ok": False, "error": "no file received"}, 400)

        ext = os.path.splitext(filename)[1].lower() or ".png"
        is_video = ext in VIDEO_EXT
        limit = MAX_VIDEO_BYTES if is_video else MAX_UPLOAD_BYTES
        if len(raw) > limit:
            return self._json({"ok": False,
                               "error": "file too large for a %s (%.0f MB limit)"
                                        % ("video" if is_video else "picture",
                                           limit / 1048576.0)}, 413)

        if not is_video and ext not in (".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg"):
            ext = ".png"

        # Windows screenshots arrive as "6015-636658.png" etc. — keep them readable
        # but make genuinely identical uploads reuse the existing file instead of
        # piling duplicates into the library.
        digest = hashlib.sha1(raw).hexdigest()[:16]
        for existing in [] if is_video else list_uploads():
            full = os.path.join(UPLOAD_DIR, existing["name"])
            try:
                with open(full, "rb") as fh:
                    if hashlib.sha1(fh.read()).hexdigest()[:16] == digest:
                        print("  = upload matches %s (reused)" % existing["url"])
                        return self._json({"ok": True, "url": existing["url"],
                                           "size": existing["size"], "reused": True,
                                           "files": list_uploads()})
            except OSError:
                continue

        safe = re.sub(r"[^A-Za-z0-9_-]", "", os.path.splitext(os.path.basename(filename))[0])[:40] or "upload"
        if re.fullmatch(r"\d{4,6}(-\d{4,6})?", safe):      # a bare screenshot timestamp
            safe = time.strftime("%Y%m%d-%H%M%S")
        fname = "%s-%s%s" % (safe, digest[:6], ext)
        with open(os.path.join(UPLOAD_DIR, fname), "wb") as fh:
            fh.write(raw)
        url = "/uploads/" + fname
        print("  \u2191 upload %s (%s)" % (url, human_size(len(raw))))
        return self._json({"ok": True, "url": url, "size": len(raw), "files": list_uploads()})

    # ---------- static ----------
    def _cam_page_error(self, title, body):
        html = ("<!DOCTYPE html><meta charset='utf-8'>"
                "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                "<body style=\"margin:0;height:100vh;display:grid;place-items:center;background:#070B12;"
                "color:#E8EFF8;font-family:-apple-system,Segoe UI,Roboto,sans-serif;text-align:center;padding:28px\">"
                "<div><div style='font-size:44px;margin-bottom:12px'>📷</div>"
                "<h2 style='margin:0 0 8px;font-size:19px'>%s</h2>"
                "<p style='margin:0;color:#8DA0B8;font-size:13.5px;line-height:1.6;max-width:340px'>%s</p>"
                "</div></body>" % (title, body)).encode("utf-8")
        self.send_response(410)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(html)))
        self.end_headers()
        try:
            self.wfile.write(html)
        except CONN_ERRORS:
            pass

    def serve_file(self, path):
        rel = ROUTES.get(path, path.lstrip("/"))
        full = os.path.normpath(os.path.join(ROOT, rel))
        if not full.startswith(ROOT):
            return self._json({"ok": False, "error": "forbidden"}, 403)
        if os.path.isdir(full):
            full = os.path.join(full, "index.html")
        if not os.path.isfile(full):
            body = ("<h1 style='font:600 22px system-ui;padding:40px'>404 — %s</h1>"
                    "<p style='font:15px system-ui;padding:0 40px'>"
                    "The control panel lives at <a href='/'>/</a>. "
                    "Overlay URL for OBS: <code>/overlay/overlay.html</code></p>" % path).encode()
            self.send_response(404)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        ext = os.path.splitext(full)[1].lower()
        ctype = MIME.get(ext) or mimetypes.guess_type(full)[0] or "application/octet-stream"
        if ext in VIDEO_EXT:
            return self.send_stream(full, ctype)
        try:
            with open(full, "rb") as fh:
                data = fh.read()
        except Exception:
            return self._json({"ok": False, "error": "read error"}, 500)
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache" if ext in (".html", ".css", ".js", ".json") else "max-age=3600")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        try:
            self.wfile.write(data)
        except CONN_ERRORS:
            self.close_connection = True

    def send_stream(self, full, ctype):
        """
        Video, with byte ranges.

        A browser source that seeks a 200 MB clip must not wait for the whole
        file, and Chrome refuses to seek at all without `Accept-Ranges`. Range
        requests get a 206 with just the bytes asked for.
        """
        try:
            size = os.path.getsize(full)
            fh = open(full, "rb")
        except OSError:
            return self._json({"ok": False, "error": "read error"}, 500)

        rng = self.headers.get("Range") or ""
        start, end = 0, size - 1
        status = 200
        if rng.startswith("bytes="):
            spec = rng[6:].split(",")[0].strip()
            a, _, b = spec.partition("-")
            try:
                if a == "" and b:                       # bytes=-5000 → last 5 kB
                    start = max(0, size - int(b))
                else:
                    start = int(a or 0)
                    if b:
                        end = min(size - 1, int(b))
                if start > end or start >= size:
                    raise ValueError
                status = 206
            except ValueError:
                fh.close()
                self.send_response(416)
                self.send_header("Content-Range", "bytes */%d" % size)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return

        length = end - start + 1
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        self.send_header("Accept-Ranges", "bytes")
        if status == 206:
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        self.send_header("Cache-Control", "max-age=3600")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        try:
            fh.seek(start)
            left = length
            while left > 0:
                chunk = fh.read(min(256 * 1024, left))
                if not chunk:
                    break
                self.wfile.write(chunk)
                left -= len(chunk)
        except CONN_ERRORS:
            self.close_connection = True        # the player closed the connection
        finally:
            fh.close()

    # ---------- websocket upgrade ----------
    def handle_ws(self):
        key = self.headers.get("Sec-WebSocket-Key")
        if not key:
            return self._json({"ok": False, "error": "not a websocket request"}, 400)
        accept = base64.b64encode(hashlib.sha1((key + WS_GUID).encode()).digest()).decode()
        self.send_response(101, "Switching Protocols")
        self.send_header("Upgrade", "websocket")
        self.send_header("Connection", "Upgrade")
        self.send_header("Sec-WebSocket-Accept", accept)
        self.end_headers()
        try:
            self.wfile.flush()
        except Exception:
            return

        ws = WSConn(self.connection, self.client_address)
        with LOCK:
            _next_id[0] += 1
            cid = _next_id[0]
            CLIENTS[cid] = {"ws": ws, "role": "unknown", "key": "", "since": time.time()}
        sys.stdout.write("  + websocket #%d connected (%s)\n" % (cid, self.client_address[0]))

        try:
            while ws.alive:
                opcode, data = ws.read_frame()
                if opcode == 0x8:      # close
                    break
                if opcode == 0x9:      # ping -> pong
                    ws._send(0xA, data)
                    continue
                if opcode == 0xA:
                    continue
                if opcode not in (0x1, 0x2):
                    continue
                try:
                    msg = json.loads(data.decode("utf-8"))
                except Exception:
                    continue
                self.on_ws_message(cid, ws, msg)
        except Exception:
            # A signalling bug must never take the socket down silently again:
            # the overlay would keep reconnecting and OBS would stay black.
            if CAM_TRACE:
                import traceback
                print("  [ws] reader error on #%d:" % cid)
                traceback.print_exc()
        finally:
            held = ""
            with LOCK:
                held = (CLIENTS.get(cid) or {}).get("key", "")
                CLIENTS.pop(cid, None)
            CAM_SOCKETS.pop(cid, None)
            try:
                freed = CAM.detach_by_key(held)
                if freed:
                    camera_update()
            except Exception:
                pass
            ws.close()
            sys.stdout.write("  - websocket #%d closed\n" % cid)
            broadcast({"type": "clients", "clients": client_stats()}, role="control")

    def on_ws_message(self, cid, ws, msg):
        mtype = msg.get("type")
        if mtype == "hello":
            role = msg.get("role", "control")
            if role not in ("control", "overlay", "camera"):
                role = "control"
            if role == "camera":
                CAM_SOCKETS[cid] = "camera"
            with LOCK:
                if cid in CLIENTS:
                    CLIENTS[cid]["role"] = role
                    CLIENTS[cid]["key"] = msg.get("key", "")
                snap = dict(STATE)
            ws.send_text(json.dumps({"type": "state", "state": snap, "clients": client_stats()}))
            broadcast({"type": "clients", "clients": client_stats()}, role="control")
        elif mtype == "patch":
            patch = msg.get("patch") or {}
            if not isinstance(patch, dict):
                return
            with LOCK:
                STATE.update(patch)
                save_state()
                snap = dict(STATE)
            if "camRole" in patch:
                CAM.set_role("full" if patch.get("camRole") == "full" else "pip")
                camera_update()
            broadcast({"type": "patch", "patch": patch, "state": snap})
        elif mtype == "get":
            ws.send_text(json.dumps({"type": "state", "state": public_state(), "clients": client_stats()}))
        elif mtype in ("sting", "reload"):
            broadcast(msg, role="overlay")
        elif mtype == "ping":
            ws.send_text(json.dumps({"type": "pong", "t": msg.get("t")}))
        elif mtype and mtype.startswith("cam-"):
            # camera signalling: hello / answer / ice / bye.
            # Sender identity matters: the camera must reach the viewer and the
            # reverse. Trust the socket's own hello, then explicit agent tags.
            sender = "viewer"
            with LOCK:
                who = (CLIENTS.get(cid) or {}).get("role", "")
                in_roster = bool(msg.get("sid")) and CAM.get(msg.get("sid")) is not None
            if who in ("overlay", "control"):
                sender = who
            elif msg.get("agent") == "phone":
                sender = "camera"
            elif CAM_SOCKETS.get(cid) == "camera":
                sender = "camera"
            if sender == "camera":
                # only this socket becomes "the camera" — never the whole roster
                CAM_SOCKETS[cid] = "camera"
                with LOCK:
                    if cid in CLIENTS:
                        CLIENTS[cid]["role"] = "camera"
            else:
                with LOCK:
                    if cid in CLIENTS:
                        CLIENTS[cid]["key"] = msg.get("key") or ("overlay" if sender == "overlay" else "preview")
            reply = _cam_message(sender, msg)
            if reply is None:
                return
            targets = reply if isinstance(reply, list) else [reply]
            for item in targets:
                if not isinstance(item, dict):
                    continue
                sid = item.get("sid") or ""
                # offers go to the viewer, answers/ice go to whoever asked
                t = item.get("type")
                if t == "cam-offer":
                    sess = CAM.get(sid)
                    owner = getattr(sess, "client", "") if sess else ""
                    if owner and send_to_key(owner, item, role="overlay"):
                        pass                      # went to the owner only
                    else:
                        broadcast(item, role="overlay")
                        broadcast(item, role="control")
                elif t in ("cam-answer", "cam-ice"):
                    if sender == "camera":
                        sess = CAM.get(sid)
                        owner = getattr(sess, "client", "") if sess else ""
                        if not (owner and send_to_key(owner, item, role="overlay")):
                            broadcast(item, role="overlay")
                            broadcast(item, role="control")
                    else:
                        broadcast(item, role="camera")
                elif t in ("cam-hello-ok", "cam-ack", "cam-error", "cam-wait"):
                    ws.send_text(json.dumps(item))
                elif t == "cam-want-offer":
                    # the phone must rebuild its connection for the new viewer
                    broadcast(item, role="camera")
                else:
                    broadcast(item)


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


START = time.time()


def find_port(preferred):
    for port in range(preferred, preferred + 20):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("0.0.0.0", port))
                return port
            except OSError:
                continue
    raise SystemExit("No free port found near %d" % preferred)


def lan_ip():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"


def start_camera_listener(args):
    """
    Bring up the https listener that serves the phone camera page.
    Returns (port, note). Never raises: a camera page that cannot start must not
    stop the broadcast from going on air.
    """
    global CAM_HTTPS
    if getattr(args, "no_camera", False) or getattr(args, "cam_port", 0) == 0:
        CERT_INFO["error"] = "disabled with --no-camera"
        return 0, "disabled (--no-camera)"

    ips = ["127.0.0.1"]
    ip = lan_ip()
    if ip and ip not in ips:
        ips.append(ip)
    try:
        os.makedirs(CERT_DIR, exist_ok=True)
        certgen.ensure_cert(CERT_PATH, KEY_PATH, ips, san_dns=("localhost",),
                            common_name="NewsDesk Camera")
        CERT_INFO["fingerprint"] = certgen.fingerprint(CERT_PATH)
    except Exception as exc:
        CERT_INFO["error"] = "certificate: %s" % exc
        print("  ! camera page needs a certificate and could not make one:", exc)
        return 0, "certificate error"

    port = camera_mod.free_port(args.cam_port)
    if not port:
        CERT_INFO["error"] = "no free port near %d" % args.cam_port
        return 0, "no free port near %d" % args.cam_port
    try:
        CAM_HTTPS = camera_mod.CamHTTPSServer(Handler, port, CERT_PATH, KEY_PATH, quiet=True)
        CAM_PORT[0] = CAM_HTTPS.port
        CAM_BASE[0] = "https://%s:%d" % (ip, CAM_HTTPS.port)
        threading.Thread(target=CAM_HTTPS.serve_forever, name="cam-https", daemon=True).start()
        return CAM_HTTPS.port, "ok"
    except Exception as exc:
        CERT_INFO["error"] = "listener: %s" % exc
        print("  ! camera https listener failed:", exc)
        return 0, "listener error"


def main():
    ap = argparse.ArgumentParser(description="NewsDesk Studio control server")
    ap.add_argument("--port", type=int, default=8770)
    ap.add_argument("--open", action="store_true", help="open the control panel in your browser")
    ap.add_argument("--cam-port", type=int, default=8443,
                    help="https port for the phone camera page (default 8443, 0 = off)")
    ap.add_argument("--no-camera", action="store_true", help="do not start the https camera page")
    args = ap.parse_args()

    load_state()
    load_presets()
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    port = find_port(args.port)
    PORT[0] = port
    httpd = Server(("0.0.0.0", port), Handler)
    cam_port, cam_note = start_camera_listener(args)

    banner = r"""
  ┌──────────────────────────────────────────────────────────────┐
  │   N E W S D E S K   S T U D I O                              │
  │   broadcast graphics for OBS — control panel + overlay        │
  │   by Emmanuel Suah                                            │
  └──────────────────────────────────────────────────────────────┘
"""
    print(banner)
    print("  %s · v%s" % (CREDIT, APP_VERSION))
    print()
    print("  Control panel   http://127.0.0.1:%d/" % port)
    print("  Phone / tablet  http://%s:%d/   (same wifi)" % (lan_ip(), port))
    print("  OBS overlay URL http://127.0.0.1:%d/overlay/overlay.html" % port)
    print("  Demo preview    http://127.0.0.1:%d/demo" % port)
    if cam_port:
        print("  Phone camera    %s/cam   (QR code in the panel)" % cam_https_url())
    else:
        print("  Phone camera    off — %s" % cam_note)
    print()
    print("  Keep this window open while you stream.  Ctrl+C to stop.\n")

    if args.open:
        threading.Timer(0.6, lambda: webbrowser.open("http://127.0.0.1:%d/" % port)).start()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n  bye 👋")
    finally:
        httpd.server_close()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        input("press enter to close…")

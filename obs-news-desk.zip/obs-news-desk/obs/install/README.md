# Prebuilt Linux plugin

`newsdesk-linux-x86_64.so` was compiled **and load-tested** against:

* OBS Studio **30.2.3** (Debian/Ubuntu package layout)
* **Qt 6.8** (must match — OBS refuses plugins built against the other Qt major)
* x86-64, glibc 2.39+

## Install

```bash
sudo cp newsdesk-linux-x86_64.so /usr/lib/x86_64-linux-gnu/obs-plugins/newsdesk.so
sudo mkdir -p /usr/share/obs/obs-plugins/newsdesk/locale
sudo cp en-US.ini /usr/share/obs/obs-plugins/newsdesk/locale/
```

Then restart OBS → **Docks → NewsDesk — On Air**.

Check it loaded:

```bash
grep newsdesk ~/.config/obs-studio/logs/$(ls -t ~/.config/obs-studio/logs | head -1)
# info: [newsdesk] plugin loaded (v1.0.0)
# info: [newsdesk] dock registered
```

## Uninstall

```bash
sudo rm /usr/lib/x86_64-linux-gnu/obs-plugins/newsdesk.so
sudo rm -rf /usr/share/obs/obs-plugins/newsdesk
```

## Other platforms / other Qt versions

Rebuild from `obs/newsdesk.cpp`:

```bash
cd obs && cmake -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build -j
```

* **Windows**: build inside the OBS source tree (`plugins/newsdesk`) — produces
  `newsdesk.dll` for `obs-plugins\64bit\`. OBS ships Qt6, so use its bundled Qt.
* **macOS**: build against the OBS source tree; copy `newsdesk.so` into
  `OBS.app/Contents/PlugIns/`.

If OBS logs `Skipping module … possible import conflicts`, it is the Qt major mismatch —
rebuild with the Qt version your OBS uses.

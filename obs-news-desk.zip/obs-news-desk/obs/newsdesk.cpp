/*
 * newsdesk.cpp — NewsDesk Studio dock for OBS Studio
 * ---------------------------------------------------------------
 * A native OBS dock that drives the NewsDesk broadcast overlay:
 *   • on-air text, ticker, PIP labels          (instant apply)
 *   • lower third / PIP / ticker / breaking    (one click)
 *   • theme accent + presets
 *   • inserts its own "NewsDesk Overlay" browser source into the
 *     current scene at 1920x1080 with one click
 *
 * It talks to server.py over the same WebSocket the browser panel
 * uses, so OBS dock and web panel stay in sync automatically.
 *
 * Build: see obs/CMakeLists.txt   (needs libobs-dev + qtbase5-dev)
 */

#include <obs-module.h>
#include <obs-frontend-api.h>

#include <QCheckBox>
#include <QComboBox>
#include <QFont>
#include <QFrame>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QPushButton>
#include <QScrollArea>
#include <QSettings>
#include <QSpinBox>
#include <QTabWidget>
#include <QTimer>
#include <QVBoxLayout>
#include <QWidget>
#include <QUrl>
#include <QUrlQuery>
#include <QJsonDocument>
#include <QJsonObject>
#include <QPointer>

OBS_DECLARE_MODULE()

OBS_MODULE_USE_DEFAULT_LOCALE("newsdesk", "en-US")

#define DOCK_ID "newsdesk_control"
#define DEFAULT_HOST "127.0.0.1:8770"

/* ------------------------------------------------------------------ */
/*  small helpers                                                      */
/* ------------------------------------------------------------------ */

static QSettings *settings()
{
	static QSettings *s = new QSettings("NewsDesk", "NewsDeskDock");
	return s;
}

static QString serverHost()
{
	QString h = settings()->value("host", DEFAULT_HOST).toString().trimmed();
	if (h.startsWith("http://") || h.startsWith("https://"))
		h = QUrl(h).authority();
	return h.isEmpty() ? QString(DEFAULT_HOST) : h;
}

static QString baseUrl() { return "http://" + serverHost(); }

/* ------------------------------------------------------------------ */
/*  the dock                                                           */
/* ------------------------------------------------------------------ */

class NewsDeskDock : public QWidget {
public:
	NewsDeskDock(QWidget *parent = nullptr) : QWidget(parent)
	{
		net = new QNetworkAccessManager(this);
		buildUi();
		pollTimer = new QTimer(this);
		connect(pollTimer, &QTimer::timeout, this, [this]() { pollHealth(); });
		pollTimer->start(4000);
		QTimer::singleShot(300, this, [this]() { pollHealth(); });
	}

private:
	QNetworkAccessManager *net = nullptr;
	QTimer *pollTimer = nullptr;
	QLabel *statusDot = nullptr;
	QLineEdit *headline = nullptr, *eyebrow = nullptr, *chip = nullptr, *ticker = nullptr;
	QLineEdit *pipTag = nullptr, *pipSource = nullptr, *pipCredit = nullptr;
	QLineEdit *hostEdit = nullptr;
	QComboBox *accent = nullptr;

	QCheckBox *cbLower = nullptr, *cbPip = nullptr, *cbTicker = nullptr, *cbAlert = nullptr,
		  *cbClock = nullptr, *cbBrand = nullptr;

	/* ------------- ui ------------- */
	void buildUi()
	{
		auto *root = new QVBoxLayout(this);
		root->setContentsMargins(10, 10, 10, 10);
		root->setSpacing(8);

		/* --- header / link status --- */
		auto *head = new QHBoxLayout();
		auto *title = new QLabel("<b>NEWSDESK</b> <span style='color:#8a97a8'>studio</span>", this);
		title->setTextFormat(Qt::RichText);
		title->setToolTip(QString::fromUtf8("NewsDesk Studio — by Emmanuel Suah"));
		statusDot = new QLabel("● offline", this);
		statusDot->setStyleSheet("color:#E01B22;font-weight:700;font-size:11px;");
		head->addWidget(title);
		head->addStretch(1);
		head->addWidget(statusDot);
		root->addLayout(head);

		/* --- on air text --- */
		auto *g1 = new QGridLayout();
		g1->setHorizontalSpacing(6);
		g1->setVerticalSpacing(4);

		headline = field("Headline", "WORLD BRACES FOR THE PEACEFUL YEAR");
		eyebrow = field("Kicker", "BREAKING NEWS");
		chip = field("Chip", "NEWS");
		ticker = field("Ticker", "one item per line, use | to separate");

		g1->addWidget(label("Headline"), 0, 0);
		g1->addWidget(headline, 0, 1);
		g1->addWidget(label("Kicker"), 1, 0);
		g1->addWidget(eyebrow, 1, 1);
		g1->addWidget(label("Chip"), 2, 0);
		g1->addWidget(chip, 2, 1);
		g1->addWidget(label("Ticker"), 3, 0);
		g1->addWidget(ticker, 3, 1);
		g1->setColumnStretch(1, 1);
		root->addLayout(g1);

		/* --- switches --- */
		auto *sw = new QHBoxLayout();
		cbLower = check("Lower third", true);
		cbPip = check("PIP", true);
		cbTicker = check("Ticker", true);
		sw->addWidget(cbLower);
		sw->addWidget(cbPip);
		sw->addWidget(cbTicker);
		sw->addStretch(1);
		root->addLayout(sw);

		auto *sw2 = new QHBoxLayout();
		cbAlert = check("Breaking", false);
		cbClock = check("Clock", false);
		cbBrand = check("Brand", false);
		sw2->addWidget(cbAlert);
		sw2->addWidget(cbClock);
		sw2->addWidget(cbBrand);
		sw2->addStretch(1);
		root->addLayout(sw2);

		/* --- pip labels --- */
		auto *g2 = new QGridLayout();
		g2->setHorizontalSpacing(6);
		g2->setVerticalSpacing(4);
		pipTag = field("Tag", "LIVE");
		pipSource = field("Source", "FEED 02");
		pipCredit = field("Credit", "Credit: World Feed");
		g2->addWidget(label("PIP tag"), 0, 0);
		g2->addWidget(pipTag, 0, 1);
		g2->addWidget(label("Source"), 1, 0);
		g2->addWidget(pipSource, 1, 1);
		g2->addWidget(label("Credit"), 2, 0);
		g2->addWidget(pipCredit, 2, 1);
		g2->setColumnStretch(1, 1);
		root->addLayout(g2);

		/* --- accent + presets --- */
		auto *bot = new QHBoxLayout();
		accent = new QComboBox(this);
		accent->addItem("Breaking  #E01B22", "#E01B22");
		accent->addItem("Network  #0A6CFF", "#0A6CFF");
		accent->addItem("Alert    #F5A623", "#F5A623");
		accent->addItem("Fresh    #00B389", "#00B389");
		accent->addItem("Late     #8B5CF6", "#8B5CF6");
		accent->addItem("Pop      #FF4D8D", "#FF4D8D");
		bot->addWidget(label("Accent"));
		bot->addWidget(accent, 1);
		root->addLayout(bot);

		auto *presets = new QHBoxLayout();
		presets->addWidget(btn("Breaking", [this]() { applyPreset(0); }));
		presets->addWidget(btn("Straight", [this]() { applyPreset(1); }));
		presets->addWidget(btn("Interview", [this]() { applyPreset(2); }));
		presets->addWidget(btn("Church", [this]() { applyPreset(3); }));
		root->addLayout(presets);

		auto *actions = new QHBoxLayout();
		actions->addWidget(btn("Sting", [this]() { post("/api/sting?kind=wipe", QJsonObject()); }));
		actions->addWidget(btn("Add to scene", [this]() { addOverlaySource(); }));
		actions->addWidget(btn("Reload", [this]() { post("/api/reload", QJsonObject()); }));
		root->addLayout(actions);

		/* run of show + pre-service timer */
		/* --- scripture: type a reference, it goes straight on air --- */
		auto *bibrow = new QHBoxLayout();
		auto *bibEdit = new QLineEdit(this);
		bibEdit->setPlaceholderText("John 3:16");
		bibEdit->setClearButtonEnabled(true);
		bibEdit->setToolTip("Any reference: Jn 3:16, ps 23:1-4, 1cor 13:4-7, \"fear not\"");
		bibrow->addWidget(bibEdit, 1);
		bibrow->addWidget(btn("↗", [this, bibEdit]() { showVerse(bibEdit->text()); }));
		bibrow->addWidget(btn("Off", [this]() {
			QJsonObject p;
			p["showVerse"] = false;
			post("/api/state", p);
		}));
		connect(bibEdit, &QLineEdit::returnPressed, this, [this, bibEdit]() { showVerse(bibEdit->text()); });
		root->addLayout(bibrow);

		/* camera over wifi: on/off, which area, and a shortcut to the phone QR */
		auto *camrow = new QHBoxLayout();
		camrow->addWidget(btn("Camera on", [this]() {
			QJsonObject p;
			p["showCam"] = true;
			post("/api/state", p);
		}));
		camrow->addWidget(btn("Cam off", [this]() {
			QJsonObject p;
			p["showCam"] = false;
			post("/api/state", p);
		}));
		camrow->addWidget(btn("PIP ⟷ Full", [this]() { toggleCamArea(); }));
		root->addLayout(camrow);

		auto *actions2 = new QHBoxLayout();
		actions2->addWidget(btn("Next item", [this]() { post("/api/playlist/next", QJsonObject()); }));
		actions2->addWidget(btn("Countdown 30m", [this]() {
			QJsonObject p;
			p["countdown"] = 1800;
			p["showCountdown"] = true;
			post("/api/state", p);
		}));
		actions2->addWidget(btn("Timer off", [this]() {
			QJsonObject p;
			p["showCountdown"] = false;
			post("/api/state", p);
		}));
		root->addLayout(actions2);

		/* --- credit --- */
		auto *credit = new QLabel(this);
		credit->setTextFormat(Qt::RichText);
		credit->setText(QString::fromUtf8(
			"<span style='color:#6d7d92;font-size:10px'>NewsDesk Studio · maintained by "
			"<b style='color:#93a6bd'>Emmanuel Suah</b></span>"));
		credit->setAlignment(Qt::AlignRight);
		root->addWidget(credit);

		/* --- connection row --- */
		auto *line = new QFrame(this);
		line->setFrameShape(QFrame::HLine);
		line->setStyleSheet("color:#2a3546;");
		root->addWidget(line);

		auto *conn = new QHBoxLayout();
		hostEdit = new QLineEdit(serverHost(), this);
		hostEdit->setPlaceholderText(DEFAULT_HOST);
		conn->addWidget(label("Server"));
		conn->addWidget(hostEdit, 1);
		conn->addWidget(btn("Save", [this]() {
			settings()->setValue("host", hostEdit->text().trimmed());
			pollHealth();
		}));
		root->addLayout(conn);

		root->addStretch(1);

		/* --- apply wiring --- */
		connectField(headline, "headline");
		connectField(eyebrow, "eyebrow");
		connectField(chip, "logoText");
		connectField(ticker, "ticker");
		connectField(pipTag, "pipTag");
		connectField(pipSource, "pipSource");
		connectField(pipCredit, "pipCredit");

		connectToggle(cbLower, "showLowerThird");
		connectToggle(cbPip, "showPip");
		connectToggle(cbTicker, "showTicker");
		connectToggle(cbAlert, "alert");
		connectToggle(cbClock, "showClock");
		connectToggle(cbBrand, "showBrand");

		connect(accent, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [this](int) {
			QJsonObject p;
			p["accent"] = accent->currentData().toString();
			post("/api/state", p);
		});

		setStyleSheet(R"(
			QLineEdit { background:#0d1522; border:1px solid #223147; border-radius:6px;
			            padding:5px 7px; color:#e6edf5; font-size:12px; }
			QLineEdit:focus { border-color:#E01B22; }
			QPushButton { background:#16202f; border:1px solid #24344b; border-radius:6px;
			              padding:6px 10px; color:#dbe6f2; font-size:12px; font-weight:600; }
			QPushButton:hover { background:#1d2a3d; border-color:#35506f; }
			QPushButton:pressed { background:#E01B22; border-color:#E01B22; color:#fff; }
			QCheckBox { color:#c6d3e2; font-size:12px; }
			QComboBox { background:#0d1522; border:1px solid #223147; border-radius:6px;
			            padding:4px 7px; color:#e6edf5; font-size:12px; }
			QComboBox QAbstractItemView { background:#101a28; color:#e6edf5; selection-background-color:#E01B22; }
			QLabel { color:#9aabbf; font-size:11px; }
		)");
	}

	QLineEdit *field(const char *placeholder, const char *hint)
	{
		auto *e = new QLineEdit(this);
		e->setPlaceholderText(QString::fromUtf8(placeholder));
		if (hint && *hint)
			e->setToolTip(QString::fromUtf8(hint));
		return e;
	}
	QLabel *label(const char *t, bool dim = true)
	{
		auto *l = new QLabel(QString::fromUtf8(t), this);
		if (dim)
			l->setStyleSheet("color:#8a97a8;font-size:11px;");
		return l;
	}
	QCheckBox *check(const char *t, bool on)
	{
		auto *c = new QCheckBox(QString::fromUtf8(t), this);
		c->setChecked(on);
		return c;
	}
	QPushButton *btn(const char *t, std::function<void()> fn)
	{
		auto *b = new QPushButton(QString::fromUtf8(t), this);
		b->setCursor(Qt::PointingHandCursor);
		connect(b, &QPushButton::clicked, this, [fn]() { fn(); });
		return b;
	}

	/* ------------- wiring ------------- */
	void connectField(QLineEdit *e, const char *key)
	{
		QString k = QString::fromUtf8(key);
		connect(e, &QLineEdit::editingFinished, this, [this, e, k]() {
			QJsonObject p;
			p[k] = e->text();
			post("/api/state", p);
		});
		connect(e, &QLineEdit::returnPressed, this, [this, e, k]() {
			QJsonObject p;
			p[k] = e->text();
			post("/api/state", p);
		});
	}
	void connectToggle(QCheckBox *c, const char *key)
	{
		QString k = QString::fromUtf8(key);
		connect(c, &QCheckBox::toggled, this, [this, k](bool on) {
			QJsonObject p;
			p[k] = on;
			post("/api/state", p);
		});
	}

	void applyPreset(int which)
	{
		QJsonObject p;
		if (which == 0) { /* breaking */
			p["accent"] = "#E01B22"; p["eyebrow"] = "BREAKING NEWS"; p["alert"] = true;
			p["showLowerThird"] = true; p["showPip"] = true; p["showTicker"] = true;
			p["headlineStyle"] = "news"; p["brandIcon"] = "n"; p["demoPlate"] = "studio";
		} else if (which == 1) { /* straight */
			p["accent"] = "#0A6CFF"; p["eyebrow"] = "EVENING REPORT"; p["alert"] = false;
			p["showLowerThird"] = true; p["showPip"] = false; p["showTicker"] = true;
			p["headlineStyle"] = "news"; p["brandIcon"] = "n"; p["demoPlate"] = "studio";
		} else if (which == 2) { /* interview */
			p["accent"] = "#E01B22"; p["eyebrow"] = "INTERVIEW"; p["alert"] = false;
			p["showLowerThird"] = true; p["showPip"] = true; p["showTicker"] = false;
			p["pipTag"] = "GUEST";
			p["headlineStyle"] = "news"; p["brandIcon"] = "n"; p["demoPlate"] = "studio";
		} else { /* church / service */
			p["accent"] = "#C9A227"; p["accent2"] = "#0E1B33"; p["pipFill"] = "#16233D";
			p["headlineStyle"] = "serif"; p["brandIcon"] = "cross"; p["demoPlate"] = "church";
			p["eyebrow"] = "SUNDAY SERVICE"; p["brandName"] = "GRACE CHAPEL";
			p["brandSub"] = "LIVE"; p["logoText"] = "GRACE";
			p["tkBrand"] = "GRACE CHAPEL"; p["tkMeta"] = "SUN";
			p["headline"] = QString::fromUtf8("WELCOME HOME \xE2\x80\x94 WORSHIP WITH US THIS MORNING");
			p["ticker"] = QString::fromUtf8(
				"Sunday service begins at 10:00 AM|"
				"Wednesday Bible study at 7:00 PM|"
				"Youth night this Friday \xE2\x80\x94 all are welcome|"
				"Give online at gracechapel.org/give");
			p["pipTag"] = "LIVE"; p["pipSource"] = "SANCTUARY";
			p["pipCredit"] = QString::fromUtf8("Grace Chapel \xC2\xB7 Main Hall");
			p["alert"] = false; p["showLowerThird"] = true; p["showPip"] = true;
			p["showTicker"] = true; p["showClock"] = true; p["showBrand"] = true;
			p["tickerSpeed"] = 80; p["headlineMax"] = 52;
		}
		post("/api/state", p);
	}

	/* ------------- net ------------- */
	void showVerse(const QString &reference)
	{
		/* The dock does not carry a bible: ask the server to resolve the
		   reference, then push the resulting text to every overlay. */
		const QString ref = reference.trimmed();
		if (ref.isEmpty())
			return;
		QNetworkRequest req(QUrl(baseUrl() + "/api/bible/lookup?ref=" +
			QString::fromUtf8(QUrl::toPercentEncoding(ref))));
		auto *reply = net->get(req);
		QPointer<QObject> guard(this);
		connect(reply, &QNetworkReply::finished, this, [this, reply, guard]() {
			reply->deleteLater();
			if (!guard)
				return;
			const QJsonObject d = QJsonDocument::fromJson(reply->readAll()).object();
			if (!d.value("ok").toBool()) {
				blog(LOG_WARNING, "[newsdesk] verse not found: %s",
				     d.value("error").toString().toUtf8().constData());
				return;
			}
			QJsonObject p;
			p["showVerse"] = true;
			p["verseRef"] = d.value("label").toString();
			p["verseText"] = d.value("text").toString();
			post("/api/state", p);
		});
	}

	void toggleCamArea()
	{
		/* read the current area, then flip it — the server relocates the live
		   feed without the phone reconnecting */
		QNetworkAccessManager *mgr = net;
		auto *reply = mgr->get(QNetworkRequest(QUrl(baseUrl() + "/api/state")));
		QPointer<QObject> guard(this);
		connect(reply, &QNetworkReply::finished, this, [this, reply, guard]() {
			reply->deleteLater();
			if (!guard)
				return;
			const QByteArray raw = reply->readAll();
			const QJsonObject root = QJsonDocument::fromJson(raw).object();
			const QString cur = root.value("state").toObject().value("camRole").toString();
			QJsonObject p;
			p["camRole"] = cur == "full" ? "pip" : "full";
			p["showCam"] = true;
			post("/api/state", p);
		});
	}

	void post(const QString &path, const QJsonObject &obj)
	{
		QNetworkRequest req(QUrl(baseUrl() + path));
		req.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
		auto *reply = net->post(req, QJsonDocument(obj).toJson(QJsonDocument::Compact));
		connect(reply, &QNetworkReply::finished, reply, &QNetworkReply::deleteLater);
		if (path.contains("/api/state"))
			setStatus(true);
	}

	void pollHealth()
	{
		auto *reply = net->get(QNetworkRequest(QUrl(baseUrl() + "/api/health")));
		connect(reply, &QNetworkReply::finished, this, [this, reply]() {
			bool ok = reply->error() == QNetworkReply::NoError;
			setStatus(ok);
			reply->deleteLater();
		});
	}

	void setStatus(bool ok)
	{
		statusDot->setText(ok ? "● linked" : "● offline");
		statusDot->setStyleSheet(ok ? "color:#25C08A;font-weight:700;font-size:11px;"
					    : "color:#E01B22;font-weight:700;font-size:11px;");
	}

	/* ------------- one-click OBS integration ------------- */
	void addOverlaySource()
	{
		/* OBS builds shipped without the browser source (e.g. Debian/Ubuntu
		   packages) cannot host the overlay. Say so instead of failing silently. */
		const char *display = obs_source_get_display_name("browser_source");
		if (!display) {
			blog(LOG_WARNING, "[newsdesk] this OBS build has no browser source");
			QMessageBox::information(
				this, "NewsDesk",
				"This OBS build does not include the Browser source, so the "
				"overlay cannot be added automatically.\n\n"
				"Install OBS from obsproject.com (Windows / macOS / AppImage or "
				"Flatpak all include it), then click \"Add to scene\" again.\n\n"
				"You can also add the overlay by hand:\n"
				"Sources → + → Browser → paste the URL and set 1920 × 1080.\n\n"
				"Overlay URL:\n" + baseUrl() + "/overlay/overlay.html");
			return;
		}

		obs_source_t *scene = obs_frontend_get_current_scene();
		if (!scene) {
			blog(LOG_WARNING, "[newsdesk] no active scene");
			QMessageBox::warning(this, "NewsDesk", "Open a scene first, then try again.");
			return;
		}

		obs_data_t *settings = obs_data_create();
		QByteArray url = (baseUrl() + "/overlay/overlay.html").toUtf8();
		QByteArray name = "NewsDesk Overlay";
		obs_data_set_string(settings, "url", url.constData());
		obs_data_set_bool(settings, "is_local_file", false);
		obs_data_set_int(settings, "width", 1920);
		obs_data_set_int(settings, "height", 1080);
		obs_data_set_int(settings, "fps_custom", 30);
		obs_data_set_bool(settings, "shutdown", false);
		obs_data_set_bool(settings, "restart_when_active", false);
		obs_data_set_string(settings, "css", "body{background:transparent;}");

		obs_source_t *src = obs_source_create("browser_source", name.constData(), settings, nullptr);
		obs_data_release(settings);
		if (!src) {
			blog(LOG_WARNING, "[newsdesk] could not create browser source");
			QMessageBox::warning(this, "NewsDesk",
					     "Could not create the browser source. Check the OBS log for details.");
			obs_source_release(scene);
			return;
		}
		obs_scene_add(obs_scene_from_source(scene), src);
		obs_source_release(src);
		obs_source_release(scene);
		blog(LOG_INFO, "[newsdesk] overlay source added to current scene");
	}
};

/* ------------------------------------------------------------------ */
/*  module entry points                                                */
/* ------------------------------------------------------------------ */

static NewsDeskDock *g_dock = nullptr;

bool obs_module_load(void)
{
	blog(LOG_INFO, "[newsdesk] plugin loaded (v1.0.0)");
	return true;
}

void obs_module_post_load(void)
{
	/* docks can only be registered once the frontend exists */
	g_dock = new NewsDeskDock(nullptr);
	g_dock->setObjectName("NewsDeskDock");
	obs_frontend_add_dock_by_id(DOCK_ID, "NewsDesk — On Air", g_dock);
	blog(LOG_INFO, "[newsdesk] dock registered");
}

void obs_module_unload(void)
{
	obs_frontend_remove_dock(DOCK_ID);
	if (g_dock) {
		g_dock->deleteLater();
		g_dock = nullptr;
	}
	blog(LOG_INFO, "[newsdesk] plugin unloaded");
}

const char *obs_module_author(void)
{
	return "Emmanuel Suah";
}

const char *obs_module_name(void)
{
	return "NewsDesk Studio";
}

const char *obs_module_description(void)
{
	return "Broadcast graphics control — lower thirds, PIP, ticker, scripture, "
	       "wifi camera and breaking mode. Maintained by Emmanuel Suah.";
}

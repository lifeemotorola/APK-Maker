/* =========================================================
   NEWS DESK OVERLAY — engine
   - transparent 1920x1080 broadcast graphics
   - controlled live over WebSocket from the control panel
   - fully usable standalone with URL parameters
   ========================================================= */
(() => {
  'use strict';

  const PARAMS = new URLSearchParams(location.search);

  const DEFAULTS = {
    /* text */
    brandName: 'NEWSDESK',
    brandSub: 'LIVE',
    eyebrow: 'BREAKING NEWS',
    headline: 'WORLD BRACES FOR THE PEACEFUL YEAR',
    ticker: [
      'Politicians agree on a framework for the year ahead|Markets close higher for a third straight session',
      'Hilarious dog video blew the internet|Happy tourists find this hidden beach',
      'Weather: clear skies through the weekend|Sport: late winner settles the derby'
    ].join('|'),
    tkBrand: 'DAILY REPORT',
    tk2Brand: 'ANNOUNCEMENTS',
    logoText: 'NEWS',
    tkMeta: '29 OCT',
    pipTag: 'LIVE',
    pipSource: 'FEED 02',
    pipCredit: 'Credit: World Feed',

    /* look */
    accent: '#E01B22',
    accent2: '#0A1A2B',

    /* toggles */
    showBrand: false,
    showClock: false,
    showPip: true,
    showLowerThird: true,
    showTicker: true,
    alert: false,
    guides: false,

    /* behaviour */
    tickerSpeed: 130,      // px / second
    headlineStyle: 'news', // 'news' (condensed) | 'serif' (church / station id)
    pipFill: '#111A2E',    // colour shown inside the PIP frame when no source is there
    demoPlate: 'studio',   // 'studio' | 'church'
    brandIcon: 'n',        // 'n' (news) | 'cross' (church) | 'dot'

    /* phase 2 graphics */
    poster: '',            // uploaded image url
    posterMode: 'lower',   // 'lower' | 'full'
    showPoster: false,
    ticker2: '',
    showTicker2: false,
    ticker2Speed: 90,
    countdown: 0,          // seconds remaining
    showCountdown: false,
    countdownLabel: 'SERVICE STARTS IN',
    songTitle: '', songArtist: '', showSong: false,
    talentName: '', talentRole: '', showTalent: false,
    scoreHome: '0', scoreAway: '0', scoreTeamHome: 'HOME', scoreTeamAway: 'AWAY', showScore: false,
    headlineMin: 30,       // px, auto-fit floor
    headlineMax: 56,       // px, auto-fit ceiling
    clock24: true,
    animateOnLoad: true,
    demo: false,           // show the sample footage plate
    demoLayout: 'full',    // 'full' | 'pip'  — what the demo stills stand in for

    /* remote control (also settable with ?ws=) */
    ws: (location.protocol === 'file:' ? 'ws://127.0.0.1:8770/ws' : `ws://${location.host}/ws`),
    key: 'default'
  };

  const state = Object.assign({}, DEFAULTS);

  /* ---------- URL overrides -------------------------------- */
  const STR_KEYS = ['brandName','brandSub','eyebrow','headline','ticker','tkBrand','tkMeta','pipTag','pipSource','pipCredit','accent','accent2','ws','key','demoLayout','logoText','headlineStyle','pipFill','demoPlate','brandIcon',
                 'poster','posterMode','ticker2','tk2Brand','countdownLabel','songTitle','songArtist',
                 'lyricSong','lyricIndex','lyricMode','lyricAlign','lyricSize',
                 'pipVideo','pipVideoFit','pipVideoFrom',
                 'talentName','talentRole','scoreHome','scoreAway','scoreTeamHome','scoreTeamAway',
                 'logoImage','ltLogoImage','pipImage','bgImage','sponsorImage','sponsorPos'];
  const BOOL_KEYS = ['showBrand','showClock','showPip','showLowerThird','showTicker','alert','guides','clock24','animateOnLoad','demo',
             'showPoster','showTicker2','showCountdown','showSong','showTalent','showScore','showLyrics',
             'showPipVideo','pipVideoLoop','pipVideoMuted',
             'showBg','showSponsor'];
  const NUM_KEYS = ['tickerSpeed','headlineMin','headlineMax','ticker2Speed','countdown'];

  for (const k of STR_KEYS) if (PARAMS.has(k)) state[k] = PARAMS.get(k);
  for (const k of BOOL_KEYS) if (PARAMS.has(k)) state[k] = /^(1|true|on|yes)$/i.test(PARAMS.get(k));
  for (const k of NUM_KEYS) if (PARAMS.has(k) && !isNaN(+PARAMS.get(k))) state[k] = +PARAMS.get(k);

  /* URL params are permanent overrides (panels/previews rely on this) */
  const OVERRIDES = pickParams();

  /* remember panel tweaks between OBS refreshes */
  const LS_KEY = 'newsdesk.state.v1';
  try {
    const saved = JSON.parse(localStorage.getItem(LS_KEY) || 'null');
    if (saved) Object.assign(state, saved, pickParams());
  } catch (_) {}

  function pickParams() { // URL params must always win over stored state
    const o = {};
    for (const k of STR_KEYS) if (PARAMS.has(k)) o[k] = PARAMS.get(k);
    for (const k of BOOL_KEYS) if (PARAMS.has(k)) o[k] = /^(1|true|on|yes)$/i.test(PARAMS.get(k));
    for (const k of NUM_KEYS) if (PARAMS.has(k) && !isNaN(+PARAMS.get(k))) o[k] = +PARAMS.get(k);
    return o;
  }

  const $ = (id) => document.getElementById(id);
  const stage = $('stage');
  const el = {
    brand: $('brandBug'), brandName: $('brandName'), brandSub: $('brandSub'),
    pip: $('pipGroup'), pipTag: $('pipTag'), pipSource: $('pipSource'), pipCredit: $('pipCredit'),
    pipVideo: $('pipVideo'), fullVideo: $('fullVideo'),
    clock: $('clockGroup'), hm: $('clockHM'), sec: $('clockS'), date: $('clockDate'),
    flag: $('ltFlag'), eyebrow: $('ltEyebrow'),
    bar: $('ltBar'), headline: $('ltHeadline'), logo: $('ltLogo'),
    tk: $('tk'), tkBrand: $('tkBrand'), tkMeta: $('tkMeta'), tkTrack: $('tkTrack'),
    brandLogoImg: $('brandLogoImg'), brandMarkSvg: $('brandMarkSvg'),
    ltLogoImg: $('ltLogoImg'), pipSlate: $('pipSlate'),
    bgPlate: $('bgPlate'), bgPlateImg: $('bgPlateImg'),
    sponsor: $('sponsorImg'),
    verse: $('verseBox'), verseRef: $('verseRef'), verseText: $('verseText'), verseTrans: $('verseTrans'),
    versePlate: $('versePlate'), verseScrim: $('verseScrim'),
    posterBand: $('posterBand'), posterImg: $('posterImg'),
    posterFull: $('posterFull'), posterImgFull: $('posterImgFull'),
    tk2: $('tk2'), tk2Track: $('tk2Track'), tk2Brand: $('tk2Brand'),
    cd: $('countdownBox'), cdLabel: $('cdLabel'), cdH: $('cdH'), cdM: $('cdM'), cdS: $('cdS'), cdBar: $('cdBar'),
    song: $('songBox'), songTitle: $('songTitle'), songArtist: $('songArtist'),
    lyrics: $('lyricsBox'), lySong: $('lySong'), lyLine: $('lyLine'),
    lyNext: $('lyNext'), lyDots: $('lyDots'),
    talent: $('talentBox'), talentName: $('talentName'), talentRole: $('talentRole'),
    score: $('scoreBox'), scHome: $('scHome'), scHomeN: $('scHomeN'),
    scAway: $('scAway'), scAwayN: $('scAwayN'),
    demoAnchor: document.querySelector('.demo-anchor'),
    demoBg: document.querySelector('.demo-bg'),
    demoPip: document.querySelector('.demo-pip')
  };

  /* ---------- responsive scaling --------------------------- */
  function fitStage() {
    const s = Math.min(window.innerWidth / 1920, window.innerHeight / 1080);
    stage.style.transform = `translate(${(window.innerWidth - 1920 * s) / 2}px, ${(window.innerHeight - 1080 * s) / 2}px) scale(${s})`;
  }
  window.addEventListener('resize', fitStage);
  fitStage();

  /* ---------- headline auto-fit ---------------------------- */
  let headlineScroll = null;
  function fitHeadline() {
    if (headlineScroll) { headlineScroll.cancel(); headlineScroll = null; }
    el.headline.style.transform = '';
    const barW = el.bar.clientWidth || 1200;
    const logoW = el.logo.offsetWidth || 150;
    const avail = Math.max(240, barW - 10 - logoW - 56 - 54);
    let size = state.headlineMax;
    el.headline.style.fontSize = size + 'px';
    while (size > state.headlineMin && el.headline.scrollWidth > avail) {
      size -= 1;
      el.headline.style.fontSize = size + 'px';
    }
    if (el.headline.scrollWidth > avail + 2) {
      const over = el.headline.scrollWidth - avail;
      const dur = Math.max(6000, over * 26);
      headlineScroll = el.headline.animate(
        [{ transform: 'translateX(0)' }, { transform: `translateX(-${over}px)` }],
        { duration: dur, delay: 1400, endDelay: 1200, iterations: Infinity, direction: 'alternate', easing: 'ease-in-out' }
      );
    }
  }

  /* ---------- clock --------------------------------------- */
  let clockTimer = null;
  function startClock() {
    clearInterval(clockTimer);
    const tick = () => {
      const now = new Date();
      let h = now.getHours();
      let suffix = '';
      if (!state.clock24) { suffix = h >= 12 ? ' PM' : ' AM'; h = h % 12 || 12; }
      el.hm.textContent = String(h).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0');
      el.sec.textContent = ':' + String(now.getSeconds()).padStart(2, '0') + suffix;
      el.date.textContent = now.toLocaleDateString('en-GB', {
        weekday: 'long', day: '2-digit', month: 'long', year: 'numeric'
      }).toUpperCase().replace(',', ' ·');
    };
    tick();
    clockTimer = setInterval(tick, 1000);
  }

  /* ---------- ticker -------------------------------------- */
  let tickerRAF = null, tickerOffset = 0, tickerCycle = 0, tickerLast = 0;
  function buildTicker() {
    const items = String(state.ticker || '').split('|').map(s => s.trim()).filter(Boolean);
    el.tkTrack.innerHTML = '';
    if (!items.length) return;
    const make = () => {
      items.forEach((txt, i) => {
        const span = document.createElement('span');
        span.className = 'tk-item';
        /* allow **bold** segments for emphasis */
        span.innerHTML = escapeHTML(txt).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
        el.tkTrack.appendChild(span);
        const sep = document.createElement('span');
        sep.className = 'tk-sep';
        el.tkTrack.appendChild(sep);
      });
    };
    make();
    const oneCycle = el.tkTrack.scrollWidth;
    /* duplicate until the strip is at least 2x the viewport */
    const view = el.tkTrack.parentElement.clientWidth || 1400;
    let copies = 1;
    while (oneCycle * copies < view + oneCycle && copies < 12) { make(); copies++; }
    tickerCycle = oneCycle;
    tickerOffset = 0;
    el.tkTrack.style.transform = 'translateX(0px)';
  }
  function startTicker() {
    cancelAnimationFrame(tickerRAF);
    let last = performance.now();
    const step = (now) => {
      const dt = Math.min(64, now - last) / 1000;
      last = now;
      if (state.showTicker && !document.hidden && tickerCycle > 0) {
        tickerOffset = (tickerOffset + state.tickerSpeed * dt) % tickerCycle;
        el.tkTrack.style.transform = `translateX(${-tickerOffset}px)`;
      }
      tickerRAF = requestAnimationFrame(step);
    };
    tickerRAF = requestAnimationFrame(step);
  }

  /* ---------- countdown ----------------------------------- */
  let cdRemaining = 0, cdTotal = 0, cdTimer = null;
  function setCountdown(seconds, total) {
    cdRemaining = Math.max(0, Math.round(+seconds || 0));
    cdTotal = Math.max(cdRemaining, Math.round(+total || cdRemaining || 1));
    renderCountdown();
    clearInterval(cdTimer);
    if (!state.showCountdown) return;
    cdTimer = setInterval(() => {
      tickCountdown();
    }, 250);
  }

  /* The server owns the deadline, so every window agrees to the second — and
     the clock takes itself off air the moment it reaches zero. */
  function tickCountdown() {
    const ends = +state.countdownEndsAt || 0;
    if (ends) {
      const left = Math.max(0, Math.round(ends - Date.now() / 1000));
      if (left !== cdRemaining) { cdRemaining = left; renderCountdown(); }
      if (left === 0 && state.showCountdown) {
        // local fallback: the server normally sends this, but if that message
        // is missed (reload, sleep) the overlay must still clear itself
        state.showCountdown = false;
        document.body.classList.remove('cd-live', 'countdown-urgent');
        set(el.cd, false, 'instant');
        clearInterval(cdTimer); cdTimer = null;
        return;
      }
    } else if (cdRemaining > 0) {
      cdRemaining = Math.max(0, cdRemaining - 1);
      renderCountdown();
      if (cdRemaining === 0) {
        state.showCountdown = false;
        document.body.classList.remove('cd-live', 'countdown-urgent');
        set(el.cd, false, 'instant');
        clearInterval(cdTimer); cdTimer = null;
      }
    }
  }
  function renderCountdown() {
    const h = Math.floor(cdRemaining / 3600);
    const m = Math.floor((cdRemaining % 3600) / 60);
    const sec = cdRemaining % 60;
    el.cdH.textContent = String(h).padStart(2, '0');
    el.cdM.textContent = String(m).padStart(2, '0');
    el.cdS.textContent = String(sec).padStart(2, '0');
    const pct = cdTotal > 0 ? Math.max(0, Math.min(100, (cdRemaining / cdTotal) * 100)) : 0;
    el.cdBar.style.width = pct + '%';
    document.body.classList.toggle('countdown-urgent', cdRemaining > 0 && cdRemaining <= 60);
  }

  /* ---------- secondary ticker ---------------------------- */
  let tk2RAF = null, tk2Offset = 0, tk2Cycle = 0;
  function buildTicker2() {
    const items = String(state.ticker2 || '').split('|').map(t => t.trim()).filter(Boolean);
    el.tk2Track.innerHTML = '';
    tk2Cycle = 0;
    if (!items.length) return;
    const add = () => items.forEach(txt => {
      const sp = document.createElement('span');
      sp.className = 'tk2-item';
      sp.innerHTML = escapeHTML(txt).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
      el.tk2Track.appendChild(sp);
      const sep = document.createElement('span');
      sep.className = 'tk2-sep';
      el.tk2Track.appendChild(sep);
    });
    add();
    const one = el.tk2Track.scrollWidth;
    const view = el.tk2Track.parentElement.clientWidth || 1200;
    let copies = 1;
    while (one * copies < view + one && copies < 12) { add(); copies++; }
    tk2Cycle = one;
    tk2Offset = 0;
    el.tk2Track.style.transform = 'translateX(0px)';
  }
  function startTicker2() {
    cancelAnimationFrame(tk2RAF);
    let last = performance.now();
    const step = (now) => {
      const dt = Math.min(64, now - last) / 1000;
      last = now;
      if (state.showTicker2 && !document.hidden && tk2Cycle > 0) {
        tk2Offset = (tk2Offset + (state.ticker2Speed || 90) * dt) % tk2Cycle;
        el.tk2Track.style.transform = `translateX(${-tk2Offset}px)`;
      }
      tk2RAF = requestAnimationFrame(step);
    };
    tk2RAF = requestAnimationFrame(step);
  }

  /* ---------- apply state --------------------------------- */
  function applyState(animate) {
    const t = animate === false || !state.animateOnLoad ? 'instant' : '';
    document.body.classList.toggle('serif-headline', state.headlineStyle === 'serif');
    document.body.dataset.brandIcon = state.brandIcon || 'n';
    document.documentElement.style.setProperty('--pip-fill', state.pipFill || '#111A2E');
    const church = state.demoPlate === 'church';
    el.demoBg.src = church ? '../assets/img/church-stage.jpg' : '../assets/img/studio.jpg';
    el.demoPip.src = church ? '../assets/img/church-worship.jpg' : '../assets/img/guest.jpg';
    if (el.demoAnchor.dataset.plate !== state.demoPlate) {
      el.demoAnchor.dataset.plate = state.demoPlate;
      el.demoAnchor.src = church ? '../assets/img/church-stage.jpg' : '../assets/img/anchor.jpg';
    }
    const editingOnly = IS_PREVIEW;
    document.body.classList.toggle('demo', !!state.demo && editingOnly);
    document.body.classList.toggle('alert', !!state.alert);
    document.body.classList.toggle('guides', !!state.guides && editingOnly);
    document.body.classList.toggle('pip-on', !!state.showPip);

    /* camera: which area is live, how it fits, mirroring */
    const camArea = state.camRole === 'full' ? 'full' : 'pip';
    document.body.classList.toggle('cam-filling',
      !!state.showCam && state.camRole === 'full' && state.camFit !== 'contain');
    document.body.classList.toggle('cam-fit-contain', state.camFit === 'contain');
    document.body.classList.toggle('cam-mirror', !!state.camMirror);
    document.body.classList.toggle('cam-pos-top', state.camObjectPos === 'top');
    document.body.classList.toggle('cam-pos-bottom', state.camObjectPos === 'bottom');
    // an area that is switched off must drop its element so no stale frame lingers
    if (!state.showCam) {
      if (camEls[camArea]) camEls[camArea].classList.remove('on');
    } else if (camEls[camArea] && camEls[camArea].srcObject) {
      camEls[camArea].classList.add('on');
    }
    if (camHasPicture(state.camRole === 'full' ? 'full' : 'pip')) hideCamNotice();
    camSyncIfNeeded();

    applyVerse();
    el.demoAnchor.classList.toggle('full', state.demoLayout !== 'pip');

    document.documentElement.style.setProperty('--accent', state.accent);
    document.documentElement.style.setProperty('--ticker', state.accent2);
    document.body.classList.toggle('light-accent', isLight(state.accent));

    el.brandName.textContent = state.brandName;
    el.brandSub.textContent = state.brandSub;
    el.headline.textContent = state.headline;
    el.eyebrow.textContent = state.eyebrow;
    el.logo.textContent = state.logoText || state.brandName;
    el.pipTag.textContent = state.pipTag;
    el.pipSource.textContent = state.pipSource;
    el.pipCredit.textContent = state.pipCredit;
    el.tkBrand.textContent = state.tkBrand;
    el.tkMeta.textContent = state.tkMeta;

    set(el.brand, state.showBrand, t);
    set(el.pip, state.showPip, t);
    set(el.clock, state.showClock, t);
    set(el.flag, state.showLowerThird, t);
    set(el.bar, state.showLowerThird, t);
    set(el.tk, state.showTicker, t);

    /* --- media library slots --- */
    const setImg = (node, url) => {
      const u = (url || '').trim();
      if (u) { if (!node.src.endsWith(u)) node.src = u; }
      else { node.removeAttribute('src'); }
      return !!u;
    };
    const hasLogo = setImg(el.brandLogoImg, state.logoImage);
    const hasLtLogo = setImg(el.ltLogoImg, state.ltLogoImage);
    const hasPipSlate = setImg(el.pipSlate, state.pipImage);
    const hasBg = setImg(el.bgPlateImg, state.bgImage);
    const hasSponsor = setImg(el.sponsor, state.sponsorImage);

    document.body.classList.toggle('has-logo-img', hasLogo);
    document.body.classList.toggle('has-lt-logo-img', hasLtLogo);
    document.body.classList.toggle('has-pip-slate', hasPipSlate);
    set(el.bgPlate, hasBg && !!state.showBg, 'instant');
    el.sponsor.className = 'gfx sponsor pos-' + (state.sponsorPos || 'br');
    if (hasSponsor && state.showSponsor) el.sponsor.classList.add('on');

    /* --- poster --- */
    const hasPoster = !!(state.poster || '').trim();
    el.posterImg.src = hasPoster ? state.poster : '';
    el.posterImgFull.src = hasPoster ? state.poster : '';
    const fullPoster = state.posterMode === 'full';
    document.body.classList.toggle('poster-up', hasPoster && !fullPoster);
    set(el.posterBand, hasPoster && state.showPoster && !fullPoster, 'instant');
    set(el.posterFull, hasPoster && state.showPoster && fullPoster, 'instant');

    /* --- secondary ticker --- */
    el.tk2Brand.textContent = state.tk2Brand || 'ANNOUNCEMENTS';
    set(el.tk2, state.showTicker2 && String(state.ticker2 || '').trim(), 'instant');

    /* --- countdown / song / talent / score --- */
    el.cdLabel.textContent = state.countdownLabel || 'SERVICE STARTS IN';
    set(el.cd, state.showCountdown, 'instant');
    el.songTitle.textContent = state.songTitle || '';
    el.songArtist.textContent = state.songArtist || '';
    set(el.song, state.showSong && !!String(state.songTitle || '').trim(), 'instant');
    el.talentName.textContent = state.talentName || '';
    el.talentRole.textContent = state.talentRole || '';
    set(el.talent, state.showTalent && !!String(state.talentName || '').trim(), 'instant');
    el.scHome.textContent = state.scoreTeamHome || 'HOME';
    el.scAway.textContent = state.scoreTeamAway || 'AWAY';
    el.scHomeN.textContent = state.scoreHome || '0';
    el.scAwayN.textContent = state.scoreAway || '0';
    set(el.score, state.showScore, 'instant');
    document.body.classList.toggle('song-live', !!(state.showSong && String(state.songTitle || '').trim()));
    document.body.classList.toggle('talent-live', !!(state.showTalent && String(state.talentName || '').trim()));
    document.body.classList.toggle('cd-live', !!state.showCountdown);

    fitHeadline();
    buildTicker();
    buildTicker2();
    startClock();
    /* keep a running countdown while it is on screen */
    if (state.showCountdown) {
      if (!cdTimer) setCountdown(state.countdown, state.countdown);
    } else {
      clearInterval(cdTimer); cdTimer = null;
      cdRemaining = Math.max(0, Math.round(+state.countdown || 0));
      cdTotal = cdRemaining;
      renderCountdown();
    }
  }
  /* perceived brightness — keeps gold/sand accents legible with dark type */
  function isLight(hex) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '').trim());
    if (!m) return false;
    const n = parseInt(m[1], 16);
    const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255 > 0.62;
  }

  function set(node, on, instant) {
    if (!node) return;
    if (instant === 'instant') { node.classList.add('instant'); }
    node.classList.toggle('on', !!on);
    if (instant === 'instant') {
      /* force reflow, then re-enable transitions for later live changes */
      void node.offsetWidth;
      node.classList.remove('instant');
    }
  }

  function escapeHTML(s) {
    return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  /* ---------- public API --------------------------------- */
  window.NewsDesk = {
    setState(patch, persist = true) {
      Object.assign(state, patch);
      applyState(true);
      if (persist) { try { localStorage.setItem(LS_KEY, JSON.stringify(state)); } catch (_) {} }
    },
    getState: () => ({ ...state }),
    /* one-shot animations the panel can fire */
    sting(kind = 'wipe') {
      const box = document.createElement('div');
      box.style.cssText = 'position:absolute;inset:0;pointer-events:none;z-index:60;';
      stage.appendChild(box);
      if (kind === 'flash') {
        const f = box.animate([{ background: '#fff', opacity: .5 }, { opacity: 0 }], { duration: 420, easing: 'ease-out' });
        f.onfinish = () => box.remove();
      } else {
        const f = box.animate([
          { clipPath: 'inset(0 100% 0 0)', background: 'var(--accent)' },
          { clipPath: 'inset(0 0 0 0)', background: 'var(--accent)', offset: .55 },
          { clipPath: 'inset(0 0 0 100%)', background: 'var(--accent)' }
        ], { duration: 760, easing: 'cubic-bezier(.16,.84,.28,1)' });
        f.onfinish = () => box.remove();
      }
    },
    /* cycle: strip -> lower third -> pip -> strip ... hands-free control */
    togglePip: () => window.NewsDesk.setState({ showPip: !state.showPip }),

    /* jump-cut to a playlist item without waiting for the server timer */
    showItem(item) {
      if (!item) return;
      window.NewsDesk.setState(Object.assign({ showLowerThird: true }, item), false);
    }
  };

  /* ---------- live link (WebSocket) ----------------------- */
  let sock = null, retry = 0, retryTimer = null;
  function connect() {
    if (!state.ws || !/^wss?:\/\//.test(state.ws)) return;
    try { sock = new WebSocket(state.ws); } catch (_) { return scheduleRetry(); }
    sock.onopen = () => {
      retry = 0;
      sock.send(JSON.stringify({ type: 'hello', role: 'overlay', key: state.key }));
      // the server forgets who is watching on disconnect — re-arm the camera
      camPeers && Object.keys(camPeers).forEach((role) => { if (camPeers[role]) camDetach(role); });
      camLastWant = '';
      if (camHasPicture(state.camRole === 'full' ? 'full' : 'pip')) hideCamNotice();
    camSyncIfNeeded();
    };
    sock.onmessage = (ev) => {
      let msg; try { msg = JSON.parse(ev.data); } catch (_) { return; }
      if (msg.type === 'state' && msg.state) { Object.assign(state, msg.state, OVERRIDES); applyState(true); }
      else if (msg.type === 'patch' && msg.patch) { Object.assign(state, msg.patch, OVERRIDES); applyState(true); }
      else if (msg.type === 'sting') { window.NewsDesk.sting(msg.kind); }
      else if (msg.type === 'reload') { location.reload(); }
      else if (msg.type && msg.type.indexOf('cam-') === 0) { onCamMessage(msg); }
    };
    sock.onclose = () => scheduleRetry();
    sock.onerror = () => { try { sock.close(); } catch (_) {} };
  }
  function scheduleRetry() {
    clearTimeout(retryTimer);
    retry = Math.min(retry + 1, 6);
    retryTimer = setTimeout(connect, 800 * retry);
  }

  /* ---------- bible verse ----------------------------------
     A verse can be shown three ways: a lower band above the ticker, a
     centred card, or full frame. The text is auto-fitted so a whole
     chapter never spills off the plate. */
  // height = usable text box; keep the minimum high enough to read on a TV
  const VERSE_FIT = {
    'band': {max: 50, min: 30, width: 1780, height: 232},
    'card': {max: 54, min: 30, width: 1040, height: 430},
    'full': {max: 78, min: 32, width: 1460, height: 640}
  };

  function fitVerse() {
    const box = el.verse, txt = el.verseText;
    if (!box || !txt) return;
    const mode = (state.verseMode === 'full' ? 'full' : state.verseMode === 'card' ? 'card' : 'band');
    const f = VERSE_FIT[mode];
    const avail = f.height;
    let lo = f.min, hi = f.max, best = f.min;
    // binary search on font size — cheap and exact enough for live use
    for (let i = 0; i < 7; i++) {
      const mid = Math.round((lo + hi) / 2);
      txt.style.fontSize = mid + 'px';
      if (txt.scrollHeight <= avail && txt.scrollWidth <= f.width) { best = mid; lo = mid; }
      else { hi = mid; }
      if (hi - lo <= 1) break;
    }
    txt.style.fontSize = best + 'px';
  }

  /* ---------- video in the PIP box --------------------------- */
  /* One clip, one element. The panel chooses a file; this plays it in the PIP
     hole (or the whole frame when the camera area is full). Looping means a
     bumper can sit there all service without anyone touching it. */
  function applyPipVideo() {
    const src = String(state.pipVideo || '').trim();
    const on = !!state.showPipVideo && !!src;
    const full = state.camRole === 'full';
    const el2 = full ? el.fullVideo : el.pipVideo;
    const other = full ? el.pipVideo : el.fullVideo;

    [el.pipVideo, el.fullVideo].forEach((v) => { if (v) v.classList.remove('on'); });
    if (other && other !== el2) { try { other.pause(); } catch (e) {} other.removeAttribute('src'); other.load(); }

    document.body.classList.toggle('pip-video-contain', String(state.pipVideoFit || 'cover') === 'contain');
    document.body.classList.toggle('full-video-contain', String(state.pipVideoFit || 'cover') === 'contain');

    if (!on || !el2) {
      if (el2) { try { el2.pause(); } catch (e) {} }
      const frame = el.pipVideo && el.pipVideo.closest('.pip-frame');
      if (frame) frame.classList.remove('video-live');
      document.body.classList.remove('pip-video-live');
      return;
    }

    const abs = /^https?:|^\/\//.test(src) ? src : src;
    if (el2.dataset.src !== abs) {
      el2.dataset.src = abs;
      el2.src = abs;
      el2.load();
      const from = Math.max(0, Number(state.pipVideoFrom) || 0);
      if (from && isFinite(from)) {
        el2.addEventListener('loadedmetadata', () => { try { el2.currentTime = from; } catch (e) {} },
                             { once: true });
      }
    }
    el2.loop = state.pipVideoLoop !== false;
    el2.muted = state.pipVideoMuted !== false;      // browsers only autoplay muted
    el2.classList.add('on');
    const p = el2.play();
    if (p && p.catch) p.catch(() => {
      // autoplay refused (unmuted without a gesture): fall back to muted so the
      // clip still plays — silence is better than a frozen frame on air
      el2.muted = true;
      const retry = el2.play();
      if (retry && retry.catch) retry.catch(() => {});
    });
    const frame = el.pipVideo && el.pipVideo.closest('.pip-frame');
    if (frame) frame.classList.add('video-live');
    document.body.classList.toggle('pip-video-live', !full);
  }

  /* ---------- worship lyrics (prompter) ---------------------- */
  function lyricsWantOn() {
    const lines = Array.isArray(state.lyricLines) ? state.lyricLines : [];
    const i = Math.max(0, Math.min(lines.length - 1, Number(state.lyricIndex) || 0));
    return !!state.showLyrics && !!String(lines[i] || '').trim();
  }

  function applyLyrics() {
    if (!el.lyrics) return;
    const lines = Array.isArray(state.lyricLines) ? state.lyricLines : [];
    const idx = Math.max(0, Math.min(lines.length - 1, Number(state.lyricIndex) || 0));
    const line = lines[idx] || '';
    const on = lyricsWantOn();

    const mode = state.lyricMode === 'full' ? 'full' : 'lower';
    el.lyrics.classList.remove('mode-lower', 'mode-full', 'align-center');
    el.lyrics.classList.add('mode-' + mode);
    if (state.lyricAlign === 'center') el.lyrics.classList.add('align-center');

    if (el.lySong) {
      const t = String(state.lyricSong || '').trim().toUpperCase();
      el.lySong.textContent = t;
      el.lySong.style.display = t ? '' : 'none';
    }
    if (el.lyLine && el.lyLine.textContent !== line) el.lyLine.textContent = line;
    if (el.lyNext) {
      const nxt = lines[idx + 1] || '';
      el.lyNext.textContent = nxt;
      el.lyNext.style.display = nxt ? '' : 'none';
    }
    if (el.lyDots) {
      // a dot per line tells the operator at a glance how far in they are
      el.lyDots.innerHTML = lines.map((_, i) =>
        '<i class="' + (i === idx ? 'on' : '') + '"></i>').join('');
      el.lyDots.style.display = lines.length > 1 ? '' : 'none';
    }
    const size = Math.max(22, Math.min(96, Number(state.lyricSize) || 46));
    el.lyrics.style.setProperty('--ly-size', size + 'px');
    el.lyLine.style.fontSize = mode === 'full' ? Math.round(size * 1.55) + 'px' : size + 'px';
    if (el.lyNext) el.lyNext.style.fontSize = Math.max(16, Math.round(size * 0.62)) + 'px';

    el.lyrics.classList.toggle('on', on);
    document.body.classList.toggle('lyrics-on', on);
    document.body.classList.toggle('lyrics-lower', mode === 'lower');
    // which neighbours are on air decides how high the band sits
    document.body.classList.toggle('has-lt', !!(state.showLowerThird || state.showTicker));
    document.body.classList.toggle('has-tk2', !!state.showTicker2);
  }

  function applyVerse() {
    if (!el.verse) return;
    const ref = (state.verseRef || '').trim();
    const text = (state.verseText || '').trim();
    // If a lyric line is on air it owns the words area; a verse would be
    // unreadable underneath it. Lyrics win, and the panel says so.
    const on = !!state.showVerse && !!(text || ref) && !lyricsWantOn();
    const mode = state.verseMode === 'full' ? 'full' : state.verseMode === 'card' ? 'card' : 'band';

    el.verse.classList.remove('mode-band', 'mode-card', 'mode-full',
                              'pos-top', 'pos-bottom', 'pos-center');
    el.verse.classList.add('mode-' + mode);

    // ---- scripture background plate --------------------------------
    const plate = (state.verseBg || '').trim();
    const hasPlate = !!plate;
    el.verse.classList.toggle('has-plate', hasPlate);
    if (el.versePlate) {
      if (hasPlate) {
        const url = 'url("' + plate.replace(/"/g, '%22') + '")';
        if (el.versePlate.style.backgroundImage !== url) {
          el.versePlate.style.backgroundImage = url;
        }
      } else {
        el.versePlate.style.backgroundImage = 'none';
      }
    }
    // darkness behind the words, 0-100 from the panel
    const scrim = Math.max(0, Math.min(100, Number(state.verseScrim))) / 100;
    el.verse.style.setProperty('--scrim', scrim);

    // light plates read better with dark type
    el.verse.classList.toggle('text-dark', state.verseTextStyle === 'dark');

    // where the words sit (only the full-frame look uses this)
    const pos = state.verseTextPos === 'top' ? 'pos-top'
              : state.verseTextPos === 'bottom' ? 'pos-bottom' : 'pos-center';
    el.verse.classList.add(pos);

    el.verse.classList.toggle('on', on);
    document.body.classList.toggle('verse-on', on);
    document.body.classList.toggle('bible-keep-gfx', !!state.verseKeepGfx);

    if (el.verseRef) {
      el.verseRef.textContent = ref.toUpperCase();
      el.verseRef.style.display = ref ? '' : 'none';
    }
    if (el.verseText && el.verseText.textContent !== text) el.verseText.textContent = text;
    if (el.verseTrans) {
      el.verseTrans.textContent = (state.verseTranslation || 'KING JAMES VERSION').toUpperCase();
      el.verseTrans.style.display = state.verseShowTranslation === false ? 'none' : '';
    }
    if (on) requestAnimationFrame(fitVerse);
    applyLyrics();
    applyPipVideo();
  }
  window.addEventListener('resize', () => { if (state.showVerse) fitVerse(); });
  // re-fit when the plate or its scrim changes (image load can shift layout)
  if (el.versePlate) el.versePlate.addEventListener('transitionend', () => { if (state.showVerse) fitVerse(); });

  /* ---------- live camera (WebRTC receiver) ----------------
     Two entry points, one peer connection:
       camPip  → inside the PIP frame
       camFull → full-frame program layer
     The server relays offer/answer/ICE; this side is always the answerer.
     See server.py + camera.py for the matching half. */
  const camEls = { pip: document.getElementById('camPip'), full: document.getElementById('camFull') };
  const camPeers = { pip: null, full: null };
  const camSids = { pip: null, full: null };
  const camIce = { pip: [], full: [] };
  let camIceServers = [{ urls: 'stun:stun.l.google.com:19302' }];
  let camFrameTimer = null;
  let camFramePoll = null;
  /* Every overlay window is its own viewer. OBS and the panel preview are two
     separate windows of this same page, so a fixed name would make them fight
     over the phone's single connection — the bug that left OBS black. */
  const CAM_KEY = 'ov-' + Math.random().toString(36).slice(2, 10);
  /* The panel's preview iframe is the same page, but it must never take the
     picture away from the real OBS source. Lower number wins. */
  const CAM_PRIO = /(^|[?&])demo=1(&|$)/.test(location.search) ? 1 : 0;

  /* `?preview=1` marks the panel's own preview window. Editing aids — the
     alignment guides, the PIP safe-area outline, the demo footage — are allowed
     here and are stripped from the real OBS source, so a guide left switched on
     can never reach the congregation. */
  const IS_PREVIEW = /(^|[?&])preview=1(&|$)/.test(location.search);

  function camSend(obj) {
    if (sock && sock.readyState === 1) { sock.send(JSON.stringify(obj)); return true; }
    return false;
  }

  function camAttach(role, stream) {
    const el = camEls[role];
    if (!el) return;
    el.srcObject = stream;
    el.classList.add('on');
    const frame = el.closest('.pip-frame');
    if (frame) frame.classList.add('cam-live');
    document.body.classList.add('has-cam-' + role);
    const p = el.play();
    if (p && p.catch) p.catch(() => {});
    // a phone can take a second or two to send its first frame; if none
    // arrives, say so rather than showing a black box
    clearTimeout(camFrameTimer);
    camFrameTimer = setTimeout(() => {
      if (camHasPicture(role)) return;
      const nb = document.getElementById('camNotice');
      if (nb && nb.classList.contains('on')) return;   // already explained
      if (!camPeers[role]) return;                     // never attached here
      showCamNotice('CAMERA CONNECTED, NO PICTURE',
                    'The phone is paired but is not sending frames. Unlock the phone, '
                    + 'bring the camera app back to the front, then tap Start again.');
    }, 7000);
  }

  function camDetach(role) {
    const el = camEls[role];
    if (el) { el.srcObject = null; el.classList.remove('on'); }
    camSids[role] = null;
    const frame = el && el.closest('.pip-frame');
    if (frame) frame.classList.remove('cam-live');
    document.body.classList.remove('has-cam-' + role);
    if (camPeers[role]) { try { camPeers[role].close(); } catch (_) {} camPeers[role] = null; }
    camSids[role] = null;
    camIce[role] = [];
  }

  function camWatchFrames(role) {
    const el = camEls[role];
    if (!el) return;
    let tries = 0;
    if (camFramePoll) clearInterval(camFramePoll);
    camFramePoll = setInterval(() => {
      tries += 1;
      if (camHasPicture(role)) {
        camClearIfLive(role);
        clearInterval(camFramePoll);
        camFramePoll = null;
      } else if (tries > 14) {
        clearInterval(camFramePoll);
        camFramePoll = null;
      }
    }, 500);
  }

  function camAnswer(role, sid, offerSdp) {
    const pc = new RTCPeerConnection({ iceServers: camIceServers, bundlePolicy: 'max-bundle' });
    camPeers[role] = pc;
    camSids[role] = sid;
    camIce[role] = [];

    pc.ontrack = (ev) => {
      camAttach(role, ev.streams[0] || new MediaStream([ev.track]));
    };
    pc.onicecandidate = (ev) => {
      if (ev.candidate) {
        camSend({ type: 'cam-ice', sid, role, key: CAM_KEY, from: 'viewer', candidate: ev.candidate.toJSON() });
      }
    };
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'failed' || pc.connectionState === 'closed') camDetach(role);
    };

    clearTimeout(camSyncTimer);
    pc.setRemoteDescription({ type: 'offer', sdp: offerSdp })
      .then(() => pc.createAnswer())
      .then((desc) => pc.setLocalDescription(desc))
      .then(() => camSend({ type: 'cam-answer', sid, role, key: CAM_KEY, from: 'viewer', sdp: pc.localDescription.sdp }))
      .catch((err) => { console.warn('[camera] answer failed for', role, err && err.message); });
  }

  function onCamMessage(msg) {
    if (msg.type === 'cam-offer' && msg.sid && msg.sdp) {
      const role = msg.role === 'full' ? 'full' : 'pip';
      // Every offer means "the phone rebuilt its side", so the old peer is
      // dead even when the session id is the same. Closing it here is what
      // makes a re-shown QR code work without reloading OBS.
      if (camPeers[role]) camDetach(role);
      camAnswer(role, msg.sid, msg.sdp);
      camWatchFrames(role);
      setInterval(() => camClearIfLive(role), 1000);
    } else if (msg.type === 'cam-busy') {
      camBusy(msg.role === 'full' ? 'full' : 'pip');
    } else if (msg.type === 'cam-ice' && msg.candidate) {
      Object.keys(camPeers).forEach((role) => {
        const pc = camPeers[role];
        if (!pc || !msg.sid || camSids[role] !== msg.sid) return;
        pc.addIceCandidate(msg.candidate).catch(() => {});
      });
    } else if (msg.type === 'cam-wait') {
      clearTimeout(camSyncTimer);
      camSyncTimer = setTimeout(camSync, 2500);
    } else if (msg.type === 'cam-bye') {
      Object.keys(camPeers).forEach((role) => {
        if (!msg.sid || camSids[role] === msg.sid) camDetach(role);
      });
    }
  }

  /* Another OBS window / browser preview is already holding the phone's single
     peer connection. Say so on the overlay instead of leaving a silent black
     box — that silence is what makes this bug so hard to find. */
  function camBusy(role) {
    document.body.classList.add('cam-busy');
    clearTimeout(camFrameTimer);
    showCamNotice('CAMERA IS IN ANOTHER WINDOW',
                  'This window is not the one holding the camera. Close the other '
                  + 'preview or OBS source, or refresh this one to take over.');
    // try again shortly: the other viewer may go away
    clearTimeout(camFrameTimer);
    clearTimeout(camSyncTimer);
    camSyncTimer = setTimeout(camSync, 5000);
  }

  /* Is a picture actually arriving in this window? */
  function camHasPicture(role) {
    const el = camEls[role];
    return !!(el && el.videoWidth > 0 && el.readyState >= 2);
  }

  /* Called every second while a peer is armed: the moment this window really
     has pixels, the explanation goes away (it may have been for an earlier try). */
  function camClearIfLive(role) {
    if (!camHasPicture(role)) return;
    document.body.classList.remove('cam-busy');
    clearTimeout(camFrameTimer);
    hideCamNotice();
  }

  function showCamNotice(title, note) {
    const box = document.getElementById('camNotice');
    if (!box) return;
    box.querySelector('b').textContent = title;
    box.querySelector('span').textContent = note;
    box.classList.add('on');
  }
  function hideCamNotice() {
    const box = document.getElementById('camNotice');
    if (box) box.classList.remove('on');
    document.body.classList.remove('cam-busy');
  }

  /* ask the server which areas should be watching, then arm the peer connections */
  let camSyncTimer = null;
  function camSync() {
    clearTimeout(camSyncTimer);
    const areas = camWantAreas();
    if (!areas.length) return;

    fetch('/api/camera').then((r) => r.json()).then((cfg) => {
      if (cfg && cfg.urls && cfg.urls.ice) camIceServers = cfg.urls.ice;
      areas.forEach((role) => {
        // Only ask for an area that has no peer yet. The hello can be lost if
        // the socket is still connecting, so keep retrying until the server
        // hands us an offer — never assume one send was enough.
        if (camPeers[role]) return;
        if (sock && sock.readyState === 1) {
          camSend({ type: 'cam-hello', role, key: CAM_KEY, prio: CAM_PRIO,
                    agent: 'overlay', watch: role, watchOnly: IS_PREVIEW });
        }
      });
      // poll while any wanted area is still unfulfilled
      if (areas.some((role) => !camPeers[role])) {
        camSyncTimer = setTimeout(camSync, 3000);
      }
    }).catch(() => {
      camSyncTimer = setTimeout(camSync, 4000);
    });
  }

  let camLastWant = '';
  function camWantAreas() {
    const want = [];
    // The panel preview asks for the feed too — never for the area the OBS
    // source is already using, or the two windows would compete for the
    // phone's single connection.
    if (state.showCam && !IS_PREVIEW) want.push(state.camRole === 'full' ? 'full' : 'pip');
    return want;
  }
  function camSyncIfNeeded() {
    const key = camWantAreas().join(',');
    if (key === camLastWant) return;
    camLastWant = key;
    // Switching area mid-show: drop the peer we no longer need, otherwise the
    // old connection lingers and the next hello is ignored. The phone keeps
    // sending, so the new area simply re-answers.
    Object.keys(camPeers).forEach((role) => {
      if (camWantAreas().indexOf(role) === -1 && camPeers[role]) {
        camDetach(role);
        camSids[role] = null;
      }
    });
    if (key) camSync();
  }

  /* debug probe — inspect the camera state from the console:
     NewsDesk.camDebug()  */
  window.__camDebug = () => ({
    want: camWantAreas(), last: camLastWant,
    peers: Object.keys(camPeers).filter((k) => !!camPeers[k]),
    sids: Object.assign({}, camSids),
    sock: sock ? sock.readyState : 'no-socket',
    timer: !!camSyncTimer,
    video: { pip: camEls.pip && camEls.pip.videoWidth, full: camEls.full && camEls.full.videoWidth }
  });

  /* ---------- boot ---------------------------------------- */
  applyState(false);
  startTicker();
  startTicker2();
  connect();

  /* hotkeys inside the overlay window (useful in a normal browser) */
  window.addEventListener('keydown', (e) => {
    if (e.target.matches('input,textarea')) return;
    if (e.key === 'g') window.NewsDesk.setState({ guides: !state.guides });
    if (e.key === 'h') {
      const hideAll = state.showLowerThird || state.showPip;
      window.NewsDesk.setState({ showLowerThird: !hideAll, showPip: !hideAll, showTicker: true });
    }
    if (e.key === 'p') window.NewsDesk.togglePip();
    if (e.key === 'l') window.NewsDesk.setState({ showLowerThird: !state.showLowerThird });
  });
})();

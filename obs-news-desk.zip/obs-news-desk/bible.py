"""
Bible reference parsing + verse lookup for NewsDesk Studio.

Handles what people actually type in a service, not what a spec says:

    John 3:16                 john 3 16              Jn 3.16
    Romans 8:28-30            Romans 8:28–30         rom 8.28-30
    Psalm 23                  ps 23                   Psalm 23:1-6
    1 Corinthians 13:4-7      1cor 13:4-7             1 Cor. 13:4-7
    Genesis 1                 Gen 1                   gn1
    John 3:16,18              John 3:16; Romans 8:1    (multiple)
    3 John 1:2                1John 3:16              ii timothy 3:16

Everything resolves against a bundled public-domain KJV index (bible/kjv.dat),
so a church with no internet still gets verses on screen. Nothing here touches the
network; the file is read once and cached in memory.

Text is public domain (King James Version, 1611).
"""

import json
import os
import re
import struct
import threading
import zlib

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(HERE, "bible", "kjv.dat")
META_PATH = os.path.join(HERE, "bible", "kjv.json")

_LOCK = threading.Lock()
_BOOKS = None
_LAST_MISS = None          # list of {"name": str, "chapters": [[verse, ...], ...]}
_META = None


# --------------------------------------------------------------- roman numerals

_ROMAN_PREFIX = {"i": 1, "ii": 2, "iii": 3, "1": 1, "2": 2, "3": 3, "first": 1,
                 "second": 2, "third": 3}


def _expand_roman(text):
    """'ii timothy' -> '2 timothy', '1st john' -> '1 john', 'iii jn' -> '3 john'."""
    t = text.strip().lower()
    t = re.sub(r"^(first|second|third)\b", lambda m: str(_ROMAN_PREFIX[m.group(1)]), t)
    t = re.sub(r"\b(1st|2nd|3rd)\b", lambda m: m.group(1)[0], t)
    m = re.match(r"^(iii|ii|i)\s+(.*)$", t)
    if m:
        t = str(_ROMAN_PREFIX[m.group(1)]) + " " + m.group(2)
    return t


def _normalise(book):
    """Loose key: lowercase, no dots/spaces, roman numerals expanded."""
    b = _expand_roman(book)
    b = b.replace(".", "").replace("\u00a0", " ")
    return re.sub(r"\s+", "", b)


# ------------------------------------------------------------------- loading

def _load():
    global _BOOKS, _META
    with _LOCK:
        if _BOOKS is not None:
            return
        if not os.path.exists(DATA_PATH):
            raise FileNotFoundError("bible/kjv.dat is missing — re-download the kit")
        blob = zlib.decompress(open(DATA_PATH, "rb").read())
        pos = 0

        def take(fmt):
            nonlocal pos
            size = struct.calcsize(fmt)
            val = struct.unpack_from(fmt, blob, pos)
            pos += size
            return val

        (nbooks,) = take(">H")
        books = []
        for _ in range(nbooks):
            (nlen,) = take(">B")
            name = blob[pos:pos + nlen].decode("utf-8")
            pos += nlen
            (nch,) = take(">B")
            chapters = []
            for _ in range(nch):
                (nv,) = take(">H")
                verses = []
                for _ in range(nv):
                    (vlen,) = take(">H")
                    verses.append(blob[pos:pos + vlen].decode("utf-8"))
                    pos += vlen
                chapters.append(verses)
            books.append({"name": name, "chapters": chapters})

        meta = {}
        try:
            meta = json.load(open(META_PATH, encoding="utf-8"))
        except Exception:
            pass
        _BOOKS, _META = books, meta


def books():
    _load()
    return [b["name"] for b in _BOOKS]


def _find_book(raw):
    """Resolve a typed book name to an index, or None."""
    _load()
    aliases = (_META or {}).get("aliases") or {}
    key = _normalise(raw)
    if not key:
        return None
    if key in aliases:
        return aliases[key]

    # exact name match, then prefix match ("revel" -> Revelation)
    for i, b in enumerate(_BOOKS):
        if _normalise(b["name"]) == key:
            return i
    candidates = [i for i, n in enumerate((_META or {}).get("names") or [])
                  if _normalise(n).startswith(key)]
    if len(candidates) == 1:
        return candidates[0]
    # 'p' is ambiguous (Psalms / Proverbs / Philippians …) — refuse to guess
    return None


# ------------------------------------------------------------------- parsing

_REF_RE = re.compile(
    r"""^\s*
    (?P<book>(?:[1-3]|i{1,3}|first|second|third|1st|2nd|3rd)?\.?\s*
             [a-z][a-z\s]*?)        # book name, optionally numbered
    \s*\.?\s*
    (?:
       (?P<ch>\d{1,3})
       (?:\s*[:.\s]\s*(?P<v1>\d{1,3})
          (?:\s*(?:-|\u2013|\u2014|to)\s*(?P<v2>\d{1,3}))?
       )?
    )?
    \s*$""",
    re.I | re.X,
)


class Ref:
    """A resolved reference: book, chapter, verse range."""
    __slots__ = ("book_index", "book", "chapter", "v1", "v2")

    def __init__(self, bi, book, chapter, v1=None, v2=None):
        self.book_index = bi
        self.book = book
        self.chapter = chapter
        self.v1 = v1
        self.v2 = v2

    def label(self):
        if self.chapter is None:
            return self.book
        if self.v1 is None:
            return "%s %d" % (self.book, self.chapter)
        if self.v2 and self.v2 != self.v1:
            return "%s %d:%d-%d" % (self.book, self.chapter, self.v1, self.v2)
        return "%s %d:%d" % (self.book, self.chapter, self.v1)

    def as_dict(self):
        return {"book": self.book, "chapter": self.chapter,
                "verse1": self.v1, "verse2": self.v2, "label": self.label()}


def parse_one(text):
    """Parse a single reference. Returns Ref or None."""
    _load()
    raw = (text or "").strip()
    if not raw:
        return None
    m = _REF_RE.match(raw)
    if not m:
        return None
    bi = _find_book(m.group("book") or "")
    if bi is None:
        return None
    global _LAST_MISS
    _LAST_MISS = None

    book = _BOOKS[bi]
    nch = len(book["chapters"])
    ch = int(m.group("ch") or 1)
    if ch < 1 or ch > nch:
        return None
    ch -= 1                            # zero-based chapters inside

    v1 = m.group("v1")
    v2 = m.group("v2")
    nv = len(book["chapters"][ch])
    if v1 is None:
        return Ref(bi, book["name"], ch + 1)
    # Do NOT clamp: an out-of-range verse must fail loudly rather than quietly
    # show a different verse under the reference the operator typed.
    iv1 = int(v1)
    iv2 = int(v2) if v2 else iv1
    if iv1 < 1 or iv2 < 1 or iv1 > nv or iv2 > nv:
        _LAST_MISS = "%s %d has %d verse%s — there is no verse %d." % (
            book["name"], ch + 1, nv, "" if nv == 1 else "s", max(iv1, iv2))
        return None
    return Ref(bi, book["name"], ch + 1, iv1, max(iv1, iv2))


def parse(text):
    """Parse a reference that may contain several comma/semicolon-separated parts."""
    out = []
    for chunk in re.split(r"[;\n]+", text or ""):
        chunk = chunk.strip()
        if not chunk:
            continue
        # "john 3:16,18" -> two refs sharing the same chapter
        parts = re.split(r",\s*", chunk)
        base = parse_one(parts[0])
        if base:
            out.append(base)
        if len(parts) > 1 and base:
            for extra in parts[1:]:
                sub = parse_one(
                    "%s %d:%s" % (base.book, base.chapter, extra)) if base.chapter else None
                if sub:
                    out.append(sub)
    return out


# --------------------------------------------------------------------- text

def verse_text(ref):
    """The verse(s) as one string, with verse numbers when it is more than one."""
    _load()
    book = _BOOKS[ref.book_index]
    verses = book["chapters"][ref.chapter - 1]
    if ref.v1 is None:
        return " ".join(verses)
    lo = ref.v1 - 1
    hi = (ref.v2 or ref.v1)
    picked = verses[lo:hi]
    if len(picked) == 1:
        return picked[0]
    return " ".join("%d %s" % (lo + 1 + i, v) for i, v in enumerate(picked))


# A single verse block larger than this is returned in parts rather than cut.
# The platform carries the whole Bible, so nothing may be silently truncated —
# an ellipsis on air is a wrong verse, not a short one.
MAX_CHARS = 1200


def lookup(text, part=0, max_chars=MAX_CHARS):
    """
    Main entry point.

    Returns {"ok": True, "refs": [...], "label": str, "text": str, "translation": "KJV"}
    or {"ok": False, "error": str}

    A long passage (a whole chapter, a wide range) is never chopped mid-sentence.
    Instead it is split into consecutive parts and `part` selects one, with
    `parts`, `more` and `continues` telling the caller what is left. Part 0 is
    what you want for a single verse.
    """
    global _LAST_MISS
    refs = parse(text)
    if not refs:
        err = _LAST_MISS or "I could not find that reference. Try “John 3:16”."
        _LAST_MISS = None
        return {"ok": False, "error": err}

    # A verse number past the end of the chapter used to be clamped to the last
    # verse, which puts a DIFFERENT verse on air under the wrong reference.
    # Refuse it and say how many verses the chapter actually has.
    for r in refs:
        if r.v1 is None or r.chapter is None:
            continue
        last = verse_count(r.book_index, r.chapter)
        if r.v1 > last or (r.v2 and r.v2 > last):
            return {"ok": False,
                    "error": "%s %d has %d verse%s — there is no verse %d." % (
                        r.book, r.chapter, last, "" if last == 1 else "s",
                        max(r.v1, r.v2 or 0))}

    # one ref covering many verses -> split on verse boundaries
    verses = []                 # [(verse number, text, ref)]
    for r in refs:
        for rv in _explode(r):
            verses.append((rv.v1, verse_text(rv), r))

    numbered = len(verses) > 1
    whole = " ".join(("%d %s" % (n, t)) if numbered else t for n, t, _ in verses).strip()
    label = "; ".join(r.label() for r in refs)

    if len(whole) <= max_chars:
        return {"ok": True, "label": label, "text": whole,
                "refs": [r.as_dict() for r in refs], "translation": "KJV",
                "parts": 1, "part": 0, "more": False, "continues": False}

    # group verse texts into pages that each fit the budget
    pages, cur = [], []
    for v in verses:
        trial = " ".join(("%d %s" % (x[0], x[1])) for x in cur + [v])
        if cur and len(trial) > max_chars:
            pages.append(cur)
            cur = [v]
        else:
            cur.append(v)
    if cur:
        pages.append(cur)

    part = max(0, min(int(part or 0), len(pages) - 1))
    page = pages[part]
    text_out = " ".join(("%d %s" % (n, t)) for n, t, _ in page).strip()
    return {"ok": True, "label": label, "text": text_out,
            "refs": [r.as_dict() for r in refs], "translation": "KJV",
            "parts": len(pages), "part": part,
            "more": part < len(pages) - 1, "continues": part > 0}


def _ref_verses(ref):
    """The verse texts for one parsed reference, in order."""
    return [verse_text(r) for r in _explode(ref)]


def _explode(ref):
    """Re-parse a Ref into one single-verse Ref per verse it covers."""
    bi, book, ch = ref.book_index, ref.book, ref.chapter
    if ch is None:                       # a bare book name -> chapter 1
        ch = 1
    last = verse_count(bi, ch)
    lo = ref.v1 if ref.v1 else 1
    hi = ref.v2 if ref.v2 else (last if ref.v1 is None else ref.v1)
    lo = max(1, min(lo, last))
    hi = max(lo, min(hi, last))
    return [Ref(bi, book, ch, v, v) for v in range(lo, hi + 1)]


def chapter_count(book_index):
    _load()
    return len(_BOOKS[book_index]["chapters"])


def verse_count(book_index, chapter):
    _load()
    return len(_BOOKS[book_index]["chapters"][chapter - 1])


def random_verse():
    """A gentle fallback for a quiet moment on air."""
    import random
    _load()
    bi = random.randrange(len(_BOOKS))
    c = random.randrange(len(_BOOKS[bi]["chapters"])) + 1
    v = random.randrange(len(_BOOKS[bi]["chapters"][c - 1])) + 1
    return lookup("%s %d:%d" % (_BOOKS[bi]["name"], c, v))


if __name__ == "__main__":
    import sys
    for arg in (sys.argv[1:] or ["John 3:16", "ps 23:1-3", "1cor 13:4-7", "ii tim 3:16"]):
        r = lookup(arg)
        print("%-16s -> %s" % (arg, r.get("label", r.get("error"))))
        if r.get("ok"):
            print("   ", r["text"][:110], "…")

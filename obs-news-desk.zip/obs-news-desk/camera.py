"""
Camera-over-WiFi for NewsDesk Studio.

What this does
--------------
Turns a phone (or any WebRTC source: OBS's WebRTC output, MediaMTX, a spare
laptop webcam) into live footage that lands in the *camera area* of the
broadcast — either the full-frame program or the PIP box — with no capture
card, no OBS scene juggling, and no extra software on the phone beyond a
browser.

Two ways footage gets in
------------------------
1. **Phone camera (built in).**
   Open the QR code shown in the panel on the phone → https page →
   tap Start → the phone's camera stream is negotiated with this server over
   WebRTC (P2P, video only, no relay), and the browser source playing
   `/overlay/overlay.html` receives the same stream. Works with any phone,
   tablet, or laptop that has a browser and a camera.

2. **Any other camera (WHEP).**
   Point the session at a WHEP endpoint — OBS 30+ *Tools ▸ WebRTC Output*,
   MediaMTX (`http://host:8889/cam/whep`), Janus, SFU… The server subscribes
   to that stream and forwards it to the overlay. Useful for an IP camera, a
   camcorder on a capture box, or a second OBS machine.

Signaling
---------
Signaling rides the control server's existing WebSocket (`/ws`) as messages
with a `type` of `cam-signal`, so there is no second port to open and no extra
protocol to explain. The phone page is served from a tiny HTTPS listener (port
8443 by default) because browsers refuse `getUserMedia` on an insecure origin —
a LAN IP over plain http is insecure. That listener shares the same handlers.

Zero third-party imports: everything here is stdlib (`http.server`, `ssl`,
`json`, `secrets`, `urllib`). The WebRTC media path lives in the browser/overlay
and in whatever recorder the user points at it; only the WHEP *subscriber* is
server-side.
"""

import json
import os
import secrets
import socket
import ssl
import threading
import time
import urllib.error
import urllib.request

# how long an unused session token stays valid
TOKEN_TTL = 12 * 3600


# A phone sends offers/ICE regularly while it is on air. If it goes quiet for
# this long, its session can no longer deliver video and is reaped.
def _now():
    return time.time()


class CameraSession:
    """One camera source feeding one of the two camera areas."""

    __slots__ = ("sid", "token", "role", "client", "client_prio", "created", "seen", "label",
                 "kind", "whep", "state", "pending_offer", "muted", "last_offer",
                 "replayed")

    def __init__(self, role, kind, label):
        self.sid = secrets.token_hex(4)
        self.token = secrets.token_urlsafe(16)
        self.role = role              # "pip" | "full"
        self.kind = kind              # "phone" | "whep"
        self.label = label
        self.client = None            # the overlay/panel client that gets the track
        self.client_prio = 99         # lower wins: OBS overlay 0, panel preview 1
        self.created = _now()
        self.seen = _now()
        self.state = "waiting"        # waiting | live | error
        self.whep = ""
        self.pending_offer = None
        self.last_offer = None
        self.replayed = False         # has a late viewer already been given the offer?
        self.muted = False

    def public(self):
        return {
            "sid": self.sid,
            "role": self.role,
            "kind": self.kind,
            "label": self.label,
            "state": self.state,
            "whep": self.whep,
            "muted": self.muted,
            "age": round(_now() - self.created, 1),
            "connected": self.client is not None,
        }


class CameraHub:
    """
    Holds the live camera sessions and routes signaling between the phone page,
    the overlay and the control panel. All methods are thread-safe; the HTTP
    server is threaded, so two people can poke the panel at once.
    """

    def __init__(self, owner=None):
        self.lock = threading.RLock()
        self.sessions = {}
        self.owner = owner            # the server module, for broadcast()
        self.whep_stop = threading.Event()
        self.whep_thread = None

    # ------------------------------------------------------------ lifecycle
    def create(self, role="pip", kind="phone", label=None, whep=""):
        with self.lock:
            for s in list(self.sessions.values()):
                if s.role == role:
                    self.sessions.pop(s.sid, None)
            sess = CameraSession(role, kind, label or ("Phone camera" if kind == "phone" else "Network camera"))
            sess.whep = whep
            self.sessions[sess.sid] = sess
            self._prune()
            return sess

    def get(self, sid):
        with self.lock:
            return self.sessions.get(sid)

    def by_token(self, token):
        with self.lock:
            for s in self.sessions.values():
                if secrets.compare_digest(s.token, token or ""):
                    return s
        return None

    def remove(self, sid):
        with self.lock:
            sess = self.sessions.pop(sid, None)
        if sess and self.owner:
            self.owner.camera_update()
        return sess is not None

    def clear(self):
        with self.lock:
            self.sessions.clear()

    def _prune(self):
        dead = [sid for sid, s in self.sessions.items()
                if _now() - s.seen > TOKEN_TTL and s.client is None]
        for sid in dead:
            self.sessions.pop(sid, None)

    def list(self):
        with self.lock:
            self._prune()
            return [s.public() for s in self.sessions.values()]

    def count_live(self):
        with self.lock:
            return sum(1 for s in self.sessions.values() if s.client is not None)

    # ----------------------------------------------------------- signalling
    def debug_dump(self):
        with self.lock:
            return [(s.sid, s.role, s.state, s.client, round(_now() - s.seen, 1),
                     s.replayed) for s in self.sessions.values()]

    def attach_by_role(self, role, role_client, avail_offer=True, key="", prio=99):
        """
        Viewer announces itself with only a role ('pip'/'full'), because it has
        no idea which session id the control room generated. Pick the newest
        live-capable session for that area and hand back any offer already
        waiting for it.

        `key` tells viewers apart. The overlay announces a fixed key
        ('overlay'); the panel preview is a different viewer with the same
        area. Without this, the panel's preview took the phone's single peer
        connection and OBS showed black — the phone only ever serves one.
        """
        with self.lock:
            cands = [s for s in self.sessions.values()
                     if s.role == role and s.state != "ended"]
            if key:
                owned = [s for s in cands if s.client == key]
                if owned:
                    sess = max(owned, key=lambda x: x.created)
                    sess.seen = _now()
                    offer = sess.pending_offer or sess.last_offer
                    sess.pending_offer = None
                    return sess, offer
                # Somebody else is using this area. A phone serves exactly one
                # viewer, so the second one must be refused — but politely, and
                # only when it does not outrank the current holder. That is what
                # stops the panel's preview from silently taking OBS's picture.
                holders = [s for s in cands if s.client and s.client != key]
                if holders:
                    holder = max(holders, key=lambda x: x.created)
                    if holder.client_prio <= prio:
                        return None, None
                    # we outrank it: take the area over
                    holder.client = None
                    holder.pending_offer = holder.last_offer
                    holder.client_prio = 99
                    sess = holder
                    sess.client = key
                    sess.client_prio = prio
                    sess.seen = _now()
                    offer = sess.pending_offer or sess.last_offer
                    sess.pending_offer = None
                    return sess, offer

            # brand-new viewer for a free area
            free = [s for s in cands if not s.client]
            if free:
                sess = max(free, key=lambda x: x.created)
                sess.client = key
                sess.client_prio = prio
                sess.seen = _now()
                offer = sess.pending_offer or sess.last_offer
                sess.pending_offer = None
                return sess, offer
            return None, None
            if not cands:
                return None, None
            sess = max(cands, key=lambda x: x.created)
            sess.client = role_client
            sess.seen = _now()
            offer = None
            if sess.pending_offer:
                offer, sess.pending_offer = sess.pending_offer, None
            if offer is None and avail_offer is not None:
                # the phone is still connected: replay its last offer so the new
                # viewer can build a peer connection without the phone noticing
                offer = sess.last_offer
            return sess, offer

    def detach_by_key(self, key):
        """Called when a viewer's socket dies: free the areas it was holding."""
        freed = []
        with self.lock:
            for s in self.sessions.values():
                if key and s.client == key:
                    s.client = None
                    s.pending_offer = s.last_offer if s.last_offer else None
                    freed.append(s.sid)
        return freed

    def attach_client(self, sid, role_client):
        """Called when the overlay (or the panel preview) announces itself."""
        with self.lock:
            sess = self.sessions.get(sid)
            if not sess:
                return None
            sess.client = role_client
            sess.seen = _now()
            if sess.pending_offer:
                offer, sess.pending_offer = sess.pending_offer, None
                return {"type": "cam-offer", "sid": sid, "sdp": offer, "role": sess.role}
        return None

    def post_offer(self, sid, sdp):
        """Phone → server. Returns the message that must reach the viewer."""
        with self.lock:
            sess = self.sessions.get(sid)
            if not sess:
                return None
            sess.seen = _now()
            sess.last_offer = sdp
            sess.replayed = False
            if sess.client is None:
                sess.pending_offer = sdp
                sess.state = "paired-pending"
                return None
            sess.state = "live"
            return {"type": "cam-offer", "sid": sid, "sdp": sdp, "role": sess.role}

    def post_answer(self, sid, sdp, viewer=""):
        """Viewer → phone. Only the viewer that owns the session may answer."""
        with self.lock:
            sess = self.sessions.get(sid)
            if not sess:
                return None
            sess.seen = _now()
            if viewer and sess.client and viewer != sess.client:
                return None
            if sess.client is not None:
                sess.state = "live"
            return {"type": "cam-answer", "sid": sid, "sdp": sdp}

    def post_ice(self, sid, candidate, sender, viewer=""):
        with self.lock:
            sess = self.sessions.get(sid)
            if not sess:
                return None
            if sender == "viewer" and viewer and sess.client and viewer != sess.client:
                return None
            sess.seen = _now()
            return {"type": "cam-ice", "sid": sid, "candidate": candidate, "from": sender}

    def bye(self, sid, sender):
        with self.lock:
            sess = self.sessions.get(sid)
            if not sess:
                return None
            sess.seen = _now()
            if sender == "camera":
                sess.state = "ended"
                sess.pending_offer = None
            return {"type": "cam-bye", "sid": sid, "from": sender}

    def set_role(self, role):
        """
        Move the live camera into a different area (PIP box <-> full frame).
        The phone does not need to reconnect: only the target element changes.
        Returns the list of affected session ids.
        """
        moved = []
        with self.lock:
            for s in self.sessions.values():
                if s.state == "ended":
                    continue
                if s.role != role:
                    s.role = role
                    s.seen = _now()
                moved.append(s.sid)
        return moved

    def set_state(self, sid, state):
        with self.lock:
            sess = self.sessions.get(sid)
            if sess:
                sess.state = state

    # ---------------------------------------------------------- URL helpers
    def phone_url(self, base):
        """base is like https://192.168.1.60:8443 ; token is per session."""
        out = []
        with self.lock:
            for s in self.sessions.values():
                if s.kind == "phone" and s.state != "ended":
                    out.append((s.sid, "%s/cam?t=%s&sid=%s&role=%s" % (base, s.token, s.sid, s.role)))
        return out


# --------------------------------------------------------------- WHEP client

class WhepSubscriber:
    """
    Minimal WHEP (WebRTC-HTTP Egress Protocol) client, stdlib only.

    We cannot *render* media server-side in pure Python, so the practical use is
    a "proxy handoff": we POST a receive-only offer to the WHEP endpoint, get an
    answer back, and hand that answer to the browser so the *browser* is the one
    decoding. This keeps the server thin and works with MediaMTX / OBS WebRTC
    output / any RFC-compatible WHEP server.

    If the endpoint answers with `Location:` we keep it so a later DELETE tears
    the resource down properly.
    """

    def __init__(self, url, timeout=8):
        self.url = url
        self.timeout = timeout
        self.resource = None
        self.last_error = None

    def start(self, offer_sdp):
        body = offer_sdp.encode("utf-8")
        req = urllib.request.Request(self.url, data=body, method="POST", headers={
            "Content-Type": "application/sdp",
            "Accept": "application/sdp",
        })
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                answer = resp.read().decode("utf-8", "replace")
                self.resource = resp.headers.get("Location")
                return answer
        except urllib.error.HTTPError as exc:
            self.last_error = "WHEP %s: %s" % (exc.code, exc.reason)
            return None
        except Exception as exc:
            self.last_error = "WHEP unreachable: %s" % exc
            return None

    def stop(self):
        if not self.resource:
            return
        try:
            req = urllib.request.Request(self.resource, method="DELETE")
            urllib.request.urlopen(req, timeout=4).close()
        except Exception:
            pass
        self.resource = None


def probe_whep(url, timeout=4):
    """Cheap reachability check used by the panel before it commits."""
    try:
        req = urllib.request.Request(url, method="OPTIONS")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return True, "HTTP %s" % resp.status
    except urllib.error.HTTPError as exc:
        # 405/501 means "speaks HTTP, refuses OPTIONS" — good enough
        if exc.code in (405, 501, 400):
            return True, "HTTP %s (OPTIONS refused, endpoint answers)" % exc.code
        return False, "HTTP %s" % exc.code
    except Exception as exc:
        return False, str(exc)


# ------------------------------------------------------------ https listener

class CamHTTPSServer:
    """
    A second listener on its own port, wrapped in TLS, serving the phone camera
    page. Deliberately separate from the main server: wrapping the main socket
    in TLS would break every existing http:// overlay source in OBS.
    """

    def __init__(self, handler_class, port, cert_path, key_path, quiet=False):
        import http.server
        self.quiet = quiet
        self.httpd = http.server.ThreadingHTTPServer(("0.0.0.0", port), handler_class)
        self.httpd.daemon_threads = True
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(cert_path, key_path)
        self.httpd.socket = ctx.wrap_socket(self.httpd.socket, server_side=True)
        self.port = self.httpd.server_address[1]

    def serve_forever(self):
        try:
            self.httpd.serve_forever()
        except Exception:
            pass

    def stop(self):
        try:
            self.httpd.shutdown()
            self.httpd.server_close()
        except Exception:
            pass


def free_port(preferred, tries=20):
    for port in range(preferred, preferred + tries):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("0.0.0.0", port))
                return port
            except OSError:
                continue
    return None

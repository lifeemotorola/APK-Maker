"""
Self-signed TLS certificate generation with nothing but the standard library.

Why: phones only allow camera access (getUserMedia) on a *secure* origin. A LAN
IP served over plain http is not secure, so https is mandatory for the phone
camera page. `openssl` is not present on a stock Windows Python install, so this
module builds an RSA key and an X.509 v3 certificate itself, in pure Python, and
caches them next to the server.

Everything here is textbook DER/ASN.1 + PKCS#1 v1.5. It is deliberately small:
one key, one self-signed leaf certificate with IP/DNS subjectAltNames.

    ensure_cert(cert_path, key_path, san_ips=[...], san_dns=[...])
        -> (cert_path, key_path), generating the pair on first run.

The result triggers the normal browser "not private" interstitial — expected for
a self-signed cert; the docs tell the user to accept it once. It is not a
substitute for a real CA, and nothing here is meant for the public internet.
"""

import base64
import hashlib
import json
import os
import random
import time

# --------------------------------------------------------------------- ASN.1

def _len(n):
    if n < 0x80:
        return bytes([n])
    body = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(body)]) + body


def _tlv(tag, payload):
    return bytes([tag]) + _len(len(payload)) + payload


def _der_int(v):
    if v == 0:
        body = b"\x00"
    else:
        body = v.to_bytes((v.bit_length() + 8) // 8, "big")
        if body[0] & 0x80:            # keep it positive
            body = b"\x00" + body
    return _tlv(0x02, body)


def _der_seq(*items):
    return _tlv(0x30, b"".join(items))


def _der_oid(dotted):
    parts = [int(p) for p in dotted.split(".")]
    body = bytes([parts[0] * 40 + parts[1]])
    for p in parts[2:]:
        chunk = [p & 0x7F]
        p >>= 7
        while p:
            chunk.append((p & 0x7F) | 0x80)
            p >>= 7
        body += bytes(reversed(chunk))
    return _tlv(0x06, body)


def _der_null():
    return b"\x05\x00"


def _der_bool(v):
    return _tlv(0x01, b"\xff" if v else b"\x00")


def _der_octets(data):
    return _tlv(0x04, data)


def _der_bitstring(data, unused=0):
    return _tlv(0x03, bytes([unused]) + data)


def _der_time(when):
    t = time.gmtime(when)
    if 1950 <= t.tm_year < 2050:
        return _tlv(0x17, time.strftime("%y%m%d%H%M%SZ", t).encode())
    return _tlv(0x18, time.strftime("%Y%m%d%H%M%SZ", t).encode())


def _der_utf8(s):
    return _tlv(0x0C, s.encode("utf-8"))


def _der_ia5(s):
    return _tlv(0x16, s.encode("ascii"))


def _der_explicit(tag_no, payload):
    return _tlv(0xA0 | tag_no, payload)


# ----------------------------------------------------------------------- RSA

_SMALL_PRIMES = [p for p in range(3, 2000) if all(p % d for d in range(2, int(p ** 0.5) + 1))]


def _is_probable_prime(n, rounds=40):
    if n < 2:
        return False
    for p in _SMALL_PRIMES:
        if n % p == 0:
            return n == p
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    for _ in range(rounds):
        a = random.randrange(2, n - 1)
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


def _gen_prime(bits):
    while True:
        cand = random.getrandbits(bits) | (1 << (bits - 1)) | 1
        # keep e=65537 valid
        if (cand - 1) % 65537 == 0:
            continue
        if _is_probable_prime(cand):
            return cand


def gen_rsa(bits=2048):
    """Return (n, e, d, p, q, dp, dq, qinv)."""
    e = 65537
    half = bits // 2
    while True:
        p, q = _gen_prime(half), _gen_prime(half)
        if p == q:
            continue
        n = p * q
        if n.bit_length() != bits:
            continue
        phi = (p - 1) * (q - 1)
        if phi % e == 0:
            continue
        d = pow(e, -1, phi)
        dp, dq = d % (p - 1), d % (q - 1)
        qinv = pow(q, -1, p)
        return n, e, d, p, q, dp, dq, qinv


def _rsa_private_der(key):
    n, e, d, p, q, dp, dq, qinv = key
    return _der_seq(_der_int(0), _der_int(n), _der_int(e), _der_int(d),
                    _der_int(p), _der_int(q), _der_int(dp), _der_int(dq), _der_int(qinv))


def _rsa_public_der(n, e):
    return _der_seq(_der_int(n), _der_int(e))


def _pem(label, der):
    b64 = base64.encodebytes(der).decode("ascii").replace("\n", "")
    chunks = [b64[i:i + 64] for i in range(0, len(b64), 64)]
    return "-----BEGIN %s-----\n%s\n-----END %s-----\n" % (label, "\n".join(chunks), label)


# -------------------------------------------------------------- signature

_SHA256_DIGESTINFO = bytes.fromhex("3031300d060960864801650304020105000420")


def _rsa_sign_sha256(key, message):
    n, e, d, p, q, dp, dq, qinv = key
    digest = hashlib.sha256(message).digest()
    t = _SHA256_DIGESTINFO + digest
    k = (n.bit_length() + 7) // 8
    em = b"\x00\x01" + b"\xff" * (k - len(t) - 3) + b"\x00" + t
    m = int.from_bytes(em, "big")
    # CRT for speed
    m1 = pow(m, dp, p)
    m2 = pow(m, dq, q)
    h = (qinv * (m1 - m2)) % p
    s = m2 + h * q
    return s.to_bytes(k, "big")


_SHA256_RSA = _der_seq(_der_oid("1.2.840.113549.1.1.11"), _der_null())


def make_cert(n, e, key, san_ips, san_dns, days=825, common_name="NewsDesk Local"):
    """Build a self-signed X.509 v3 certificate (DER) and sign it."""
    serial = int.from_bytes(os.urandom(8), "big") >> 1
    if serial == 0:
        serial = 1
    now = time.time()

    name = _der_seq(_tlv(0x31, _der_seq(_der_oid("2.5.4.3"), _der_utf8(common_name))))

    general_names = b""
    for ip in san_ips:
        try:
            import socket
            packed = socket.inet_aton(ip)
            general_names += _tlv(0x87, packed)     # [7] iPAddress
        except OSError:
            general_names += _tlv(0x82, ip.encode("ascii"))   # [2] dNSName
    for dns in san_dns:
        general_names += _tlv(0x82, dns.encode("ascii"))

    # Extension ::= SEQUENCE { extnID OID, critical BOOLEAN OPTIONAL, extnValue OCTET STRING }
    # Note: _der_seq(...) here IS the Extension SEQUENCE — do not wrap it again.
    san = _der_seq(_der_oid("2.5.29.17") + _der_octets(_der_seq(general_names)))
    basic = _der_seq(_der_oid("2.5.29.19") + _der_bool(True) + _der_octets(_der_seq()))
    # digitalSignature + keyEncipherment  (bits 7 and 5 of the first octet)
    usage = _der_seq(_der_oid("2.5.29.15") + _der_bool(True)
                     + _der_octets(_der_bitstring(b"\xa0", 5)))
    eku = _der_seq(_der_oid("2.5.29.37")
                   + _der_octets(_der_seq(_der_oid("1.3.6.1.5.5.7.3.1"))))

    tbs = _der_seq(
        _der_explicit(0, _der_int(2)),                    # v3
        _der_int(serial),
        _SHA256_RSA,
        name,
        _der_seq(_der_time(now - 3600), _der_time(now + days * 86400)),
        name,
        # SubjectPublicKeyInfo ::= SEQUENCE { AlgorithmIdentifier, BIT STRING }
        # The inner SEQUENCE is required — without it OpenSSL reports a bare
        # "PEM lib" error that says nothing about the real problem.
        _der_seq(_der_seq(_der_oid("1.2.840.113549.1.1.1"), _der_null()),
                 _der_bitstring(_rsa_public_der(n, e))),
        _der_explicit(3, _der_seq(san, basic, usage, eku)),
    )
    sig = _rsa_sign_sha256(key, tbs)
    return _der_seq(tbs, _SHA256_RSA, _der_bitstring(sig))


# ------------------------------------------------------------------ public

def _cert_is_usable(cert_path, key_path, san_ips):
    """
    Reuse an existing pair if it still covers this machine's IPs.

    The SANs are stored as packed 4-byte addresses inside the DER, so searching
    the PEM for "192.168.1.60" never matches — that made every restart mint a
    fresh certificate and re-trigger the browser warning. We keep a small
    sidecar with the SAN list instead.
    """
    try:
        if not (os.path.exists(cert_path) and os.path.exists(key_path)):
            return False
        if os.path.getsize(cert_path) < 200 or os.path.getsize(key_path) < 200:
            return False
        if time.time() - os.path.getmtime(cert_path) > 700 * 86400:
            return False
        meta_path = cert_path + ".json"
        if not os.path.exists(meta_path):
            return False
        with open(meta_path, "r", encoding="utf-8") as fh:
            meta = json.load(fh)
        have = set(meta.get("ips") or [])
        return all(ip in have for ip in san_ips)
    except (OSError, ValueError):
        return False


def ensure_cert(cert_path, key_path, san_ips, san_dns=("localhost",),
                common_name="NewsDesk Local", bits=2048, force=False, quiet=False):
    """
    Make sure a self-signed cert/key pair exists and covers san_ips.
    Returns (cert_path, key_path).
    """
    san_ips = [ip for ip in dict.fromkeys(san_ips) if ip]
    if not force and _cert_is_usable(cert_path, key_path, san_ips):
        return cert_path, key_path

    os.makedirs(os.path.dirname(os.path.abspath(cert_path)) or ".", exist_ok=True)
    if not quiet:
        print("  · creating a self-signed certificate for the phone camera page…")

    key = gen_rsa(bits)
    n = key[0]
    e = key[1]
    private_pem = _pem("RSA PRIVATE KEY", _rsa_private_der(key))
    cert_der = make_cert(n, e, key, san_ips, list(san_dns), common_name=common_name)
    cert_pem = _pem("CERTIFICATE", cert_der)

    # write then rename, so a half-written file can never be picked up
    meta = {"ips": san_ips, "dns": list(san_dns), "created": int(time.time()),
            "common_name": common_name}
    meta_path = cert_path + ".json"
    for path, data in ((meta_path, json.dumps(meta, indent=2)),
                       (key_path, private_pem), (cert_path, cert_pem)):
        tmp = path + ".tmp"
        with open(tmp, "w", newline="\n") as fh:
            fh.write(data)
        os.replace(tmp, path)
    try:
        os.chmod(key_path, 0o600)
    except OSError:
        pass
    if not quiet:
        print("    certificate ready (%d-bit, valid 825 days)" % bits)
    return cert_path, key_path


def fingerprint(cert_path):
    """SHA-256 fingerprint of the DER, colon separated — for the panel UI."""
    try:
        pem = open(cert_path, "r").read()
    except OSError:
        return ""
    body = "".join(l for l in pem.splitlines() if l and not l.startswith("-----"))
    der = base64.b64decode(body)
    h = hashlib.sha256(der).hexdigest().upper()
    return ":".join(h[i:i + 2] for i in range(0, len(h), 2))


if __name__ == "__main__":
    import ssl
    import tempfile
    import socket

    d = tempfile.mkdtemp()
    c, k = ensure_cert(os.path.join(d, "c.pem"), os.path.join(d, "k.pem"),
                       ["127.0.0.1", "192.168.1.60"])
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(c, k)
    print("ssl context loaded OK:", c)
    print("fingerprint:", fingerprint(c)[:60], "…")
    print("cert bytes:", os.path.getsize(c), "key bytes:", os.path.getsize(k))

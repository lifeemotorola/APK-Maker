# NewsDesk Studio — broadcast graphics for OBS

**Maintained by Emmanuel Suah** · version 1.5

A complete **"news channel" lower-third system** for OBS, modelled on the reference
screenshot: anchor shot with a framed guest feed, white headline bar with red kicker,
scrolling ticker, clock and brand bug. Works for news, sport, interviews and church
services alike — plus scripture on air and a phone as a live camera.

It ships as three pieces that work together:

| Piece | What it is | Where |
|---|---|---|
| **Overlay** | Transparent 1920×1080 browser source with every graphic | `overlay/` |
| **Control panel** | Web app: type the headline, flip switches, instantly on air | `control/` |
| **OBS dock (plugin)** | Native C++ dock inside OBS with the same controls + a one-click "Add to scene" | `obs/` |

Everything is driven live over a WebSocket, so the control panel, a phone on the same
wifi, and the OBS dock all stay in sync.

📘 **New here?** [`docs/NewsDesk-Studio-Guide.pdf`](docs/NewsDesk-Studio-Guide.pdf) — a
29-page illustrated guide, A4 and print-ready. Thirteen numbered sections with real
screenshots of this build: installing the server, adding the overlay to OBS, running the
panel, the five looks, images and slides, the Bible card, camera over wifi, run of show and
presets, the OBS dock plugin, a Sunday-morning checklist, troubleshooting, and a reference
appendix. Every page is footed *Emmanuel Suah*.

**What is inside**

* Lower thirds, ticker, clock, brand bug, PIP frame — the reference news layout
* Five one-click looks: Breaking, Straight news, Interview, Sport, **Church**
* Run of show, countdown, second crawl, now playing, name card, score bug
* Media library with six image slots — logos, slides, backgrounds, sponsor art
* **Camera over wifi** — a phone becomes a live feed by scanning a QR code
* **Bible** — the whole KJV offline; type `John 3:16` and it is on air
* **20 scripture backgrounds** — photographs and clean plates behind the verse, with a
  scrim, text position and light/dark type
* Custom presets, hotkeys, and a native OBS dock

---

## 1. Quick start (2 minutes)

```bash
cd obs-news-desk
python server.py --open        # python3, no dependencies
```

Open the panel it launches (`http://127.0.0.1:8770/`), then in OBS:

1. **Sources → + → Browser**
2. URL: `http://127.0.0.1:8770/overlay/overlay.html`
3. Width **1920**, Height **1080**
4. Untick *Shutdown source when not visible* (keeps the clock correct)

Your camera / game / screen capture goes **in a scene below** the browser source.
Type in the panel — the graphics update instantly.

Two extra addresses come up with the server:

| Address | What it is |
|---|---|
| `http://<your-ip>:8770/` | control panel (open it on a phone too — it is responsive) |
| `https://<your-ip>:8443/cam` | phone camera page — reach it by scanning the QR in the panel |

The https listener exists only because browsers refuse camera access on plain http.
It uses a certificate the server makes for itself on first start; see §7.

> **Note on OBS builds:** the overlay needs the **Browser source**. Official builds
> from obsproject.com (Windows, macOS, AppImage, Flatpak) include it. Some distro
> packages (Debian/Ubuntu `obs-studio`) ship **without** it — the plugin detects this
> and shows you the URL to add manually instead of failing silently.

---

## 2. The reference layout

```
┌──────────────────────────────────────────────────────────────┐
│ [brand bug]                                    [clock/date]  │
│                                    ┌───────────────────────┐ │
│                                    │ ● LIVE                │ │
│              ANCHOR                │      GUEST FEED       │ │
│             (your cam)             │                       │ │
│                                    └───────────────────────┘ │
│                                     FEED 02  Credit: …       │
│ ▌BREAKING NEWS                                                │
│ ▌ WORLD BRACES FOR THE PEACEFUL YEAR               [NEWS]    │
│ ▌DAILY REPORT │ ticker text scrolling …              [29 OCT]│
└──────────────────────────────────────────────────────────────┘
```

Two ways to get the guest into the box:

**A. Scene item + Crop/Pad (recommended, no extra plugins)**
1. Add the second camera/window to the scene, drag it roughly into place.
2. Right-click it → **Filters** → **+** → **Crop/Pad**
3. Set *Crop* to leave **780 × 439**, *Position* → *Offset* `1044, 168` (Top-Left crop)
4. Put it **below** the NewsDesk browser source so the frame sits on top.

**B. Scene source on a nested scene** — same idea, use *Transform → Edit Transform*
to set exactly `X 1044`, `Y 168`, `W 780`, `H 439`.

The overlay's **Guides** toggle (panel → ⌗ Guides) draws the exact PIP hole, so you can
line sources up in 5 seconds.

---

## 3. The control panel

`http://127.0.0.1:8770/` (works on a phone too — it shows the LAN address on startup)

* **Live preview** — the actual overlay render, 16:9, updating as you type
* **On-air text** — headline, kicker, chip, ticker items (one per line, `**bold**` works)
* **PIP / feed text** — tag, source label, credit line
* **Switches** — lower third, PIP, ticker, breaking mode, clock, brand bug, guides
* **Look** — 7 accent colours, ticker speed, headline max size
* **Presets** — Breaking · Straight news · Interview · Sport · **Church**
* **Run of show** — playlist that advances the lower third on a timer
* **Extra graphics** — countdown, second crawl, now playing, name card, score, poster
* **Media & uploads** — one library feeding six image slots across the whole platform
* **My presets** — save your own looks, server-side
* **Sting** — one-shot red wipe between items

Keyboard: `L` lower third · `P` PIP · `T` ticker · `B` breaking · `G` guides · `S` sting

---

## 4. The Church preset

Built for services and church livestreams. One click sets the whole look:

| | |
|---|---|
| **Accent** | warm gold `#C9A227` on deep navy `#0E1B33` |
| **Headline** | serif face instead of the condensed news type |
| **Brand mark** | a cross instead of the "N" |
| **Copy** | `SUNDAY SERVICE` / `WELCOME HOME — WORSHIP WITH US THIS MORNING` |
| **Ticker** | service times, midweek study, youth night, giving link |
| **PIP labels** | `SANCTUARY` · `Grace Chapel · Main Hall` |
| **Pace** | ticker slows to 80 px/s, clock and brand on |
| **Sample plate** | switches the demo footage to a sanctuary shot |

To make it yours, edit the `church` entry in `control/index.html` (`PRESETS`), or just
change the text fields and save — the panel remembers your settings in `state.json`.
The OBS dock has the same **Church** button.

Everything the preset sets is also available as individual switches, so you can run
gold-on-navy without the serif, or the cross with the news headline face.

---

## 5. Go live — and why the panel never leaks into the broadcast

The **Go live** button sits in the top bar. One press:

* switches the platform to on-air (`onAir: true`) and starts the on-air clock;
* **clears the countdown**, since the service has started;
* switches **off the alignment guides and the sample footage**, and pushes the same
  clean picture to every overlay window;
* tells every open overlay to reload its state, so OBS and any second window agree.

Press it again (or **End the broadcast** in the green bar) to come off air.

### The panel's preview is an editing view

The preview inside the panel loads `/overlay/overlay.html?preview=1`. In that window you
get the **alignment guides**, the **sample footage** and the **safe-area outlines** —
everything you need while placing graphics. The URL you paste into OBS is the plain
`/overlay/overlay.html`, and that window **never** shows any of it, whatever the panel
has switched on. A guide left on by accident can no longer reach the congregation.

The preview is also a *looker*, not a viewer: it will watch the camera if the feed is
free, but it always yields to the OBS source rather than competing for it.

## 6. Extra graphics

Beyond the news plate, seven more graphics are independent switches — stack them in any
combination; the layout re-flows so they never overlap.

| Graphic | What it does | Keys |
|---|---|---|
| **Countdown** | Pre-service timer with progress bar, turns red in the last minute, and **removes itself the moment it reaches zero** | `showCountdown`, `countdown` (sec), `countdownEndsAt` (epoch), `countdownLabel` |
| **Second crawl** | Announcements strip above the main ticker, own colour + speed | `showTicker2`, `ticker2`, `tk2Brand`, `ticker2Speed` |
| **Now playing** | Song title + artist with a note icon | `showSong`, `songTitle`, `songArtist` |
| **Name card** | Speaker / worship leader card, left side | `showTalent`, `talentName`, `talentRole` |
| **Score bug** | Home / away with scores, centred | `showScore`, `scoreHome`, `scoreAway`, `scoreTeamHome`, `scoreTeamAway` |
| **Poster / slide** | Uploaded image as a **bottom band** or **full frame** | `showPoster`, `poster`, `posterMode` |

**Uploading a poster:** panel → *Extra graphics* → *Poster image* → click or drag a
PNG/JPG/WEBP in. It is stored in `uploads/` and served from `/uploads/…`, so OBS picks it
up immediately — use it for scripture slides, sermon points, sponsor logos or
announcements. `uploads/sample-scripture.jpg` ships as an example.

### Platform API (v1.5)

```
POST /api/live            {"on": true|false}   go live / off air — cleans the output
POST /api/countdown/start {"seconds": 300}     arm the clock; it removes itself at zero
POST /api/countdown/stop                       take it down early
GET  /api/camera/live                          plain-language camera health
```

## 7. Media & uploads

The panel's **Media & uploads** card is the single place to feed images to the whole
platform. Drop files in, then click a slot's preview to place them.

### The six image slots

| Slot | Where it appears | Key |
|---|---|---|
| **Poster / slide** | Bottom band or full frame — scripture, sermon points, sponsors | `poster` + `posterMode` |
| **Brand logo** | Replaces the top-left bug mark (SVG/PNG with transparency works best) | `logoImage` |
| **Headline chip** | Image inside the lower-third lockup instead of the text chip | `ltLogoImage` |
| **PIP slate** | Standby slide shown inside the guest box when no camera is composited | `pipImage` |
| **Background plate** | Full-frame backdrop behind all graphics (transparent plate stays on top) | `bgImage` + `showBg` |
| **Sponsor mark** | Corner watermark — pick top-left / top-right / bottom-left / bottom-right | `sponsorImage`, `showSponsor`, `sponsorPos` |

### Uploading

* **Drop or click** the dashed area at the top of the card — multiple files at once
* PNG · JPG · WEBP · GIF · SVG, up to **16 MB each**, stored in `uploads/` on your machine
  (nothing leaves it)
* **Same file twice is one file.** The server fingerprints the bytes and returns the
  existing URL with `"reused": true` instead of writing a duplicate. Screenshot-style
  names like `6015-636658.png` are rewritten to a readable `20261030-161145.png`; every
  stored name gets a short fingerprint suffix (`logo-4a1c2e.png`) so two different
  `logo.png` files never overwrite each other
* Click any **slot preview** (or ◫) to open the picker: choose a library file, upload a
  new one, or pick **No image** to clear
* Every slot has ⏻ (show/hide, where relevant) and ✕ (clear)
* The **Library** grid shows everything you have uploaded — hover a thumbnail for ✕ to
  delete the file from the server (slots using it are cleared automatically)

### Images follow the show

* **Run of show** items can carry an image: pick one in *Attach image* when adding an
  item. Jumping to that item turns the slide on; the next item without one clears it.
* **My presets** capture the image slots too, so a saved "Sunday 9am" look restores the
  logo, background and sponsor art along with the text.

```bash
# list / upload / delete
curl http://127.0.0.1:8770/api/uploads
curl -X POST http://127.0.0.1:8770/api/upload -F "file=@logo.png"
curl -X POST http://127.0.0.1:8770/api/uploads/delete \
     -H 'Content-Type: application/json' -d '{"url":"/uploads/logo.png"}'
```

Included sample art in `uploads/`: `grace-chapel-logo.png`, `sponsor-meridian.png`,
`studio-bg-navy.jpg`, `sample-scripture.jpg`, `sample-scripture-2.jpg`.

## 8. Camera over wifi — phone, tablet or any camera

No capture card, no HDMI box. A phone becomes a live feed that drops straight into
the **camera area** — the PIP box or the whole frame.

### Pair a phone (30 seconds)

1. Panel → **Camera over wifi** → choose **Inside PIP box** or **Full frame**.
2. Tap **📱 Show QR code for a phone**.
3. Scan it with the phone's camera app → open the link → **Start camera** → **Allow**.
4. Flip **Camera on air**. The footage appears; move it later with the same
   area buttons — the phone keeps streaming, nothing to rescan.

The phone page is deliberately bare: start/stop, front↔rear switch, quality
(720p / 1080p / 4K), mute, a 16:9 safe-area guide, and an fps read-out. It keeps the
screen awake while live and reconnects by itself if wifi hiccups.

### "Not private" warning on the phone

Browsers only allow camera access on **https**. The server makes its own certificate
on first run (`certs/newsdesk-cert.pem`) and serves the camera page on
**port 8443**. The phone will warn once because the certificate is self-signed —
tap **Advanced ▸ Proceed**. That is expected: the certificate is generated locally,
covers your LAN IP, and never leaves your network. Nothing is sent to the internet;
video goes phone → OBS over your own wifi (peer-to-peer, with a public STUN server
only telling the two ends how to find each other).

Turn the camera page off with `--no-camera`, or move the port with
`--cam-port 9443`.

### A video clip in the PIP box

Below the camera controls there is **Feed from a video**. Upload an MP4 or WebM (up to
300 MB) or pick one already in the library, then press **Play**. It plays in the PIP hole
exactly where the phone feeds, so you can cut between a live guest and a pre-recorded
message with one switch:

* **Video on air** shows/hides the clip; turning it on can switch the camera off so the
  two never fight for the same box.
* **Loop** repeats the clip; **Sound** chooses muted (the safe default on air) or audible.
* **Fit** fills and crops, or letterboxes the whole frame.
* **From start** rewinds and puts it up again — the usual move for a notice reel.
* The panel's own player under the file name lets you scrub and find a start point
  *before* it goes on air.

Videos are served with byte-range support, so OBS can seek a long clip instead of
downloading all of it first.

### Any other camera (WHEP)

Anything that speaks **WHEP** also works — OBS's own **Tools ▸ WebRTC Output**,
MediaMTX (`http://192.168.1.50:8889/cam/whep`), Janus, an SFU, or an IP camera with a
WebRTC output. Paste the URL under *Or another camera* → **Connect**. The server
checks it is reachable, then the overlay subscribes and decodes it. A second OBS
machine, a camcorder on a spare laptop, or a remote site all work this way.

### Framing controls

| Control | What it does |
|---|---|
| **Camera area** | PIP box (guest/interview) or full frame (the whole program) |
| **Camera on air** | show / hide the live feed; hiding shows the standby slate |
| **Fit** | *Fill & crop* to cover the area, or *Fit whole* to letterbox |
| **Crop anchor** | which edge survives when filling (centre / top / bottom) |
| **Mirror** | flip horizontally — flattering for a selfie feed |

When the camera fills the frame, an empty PIP box is hidden automatically so it does
not punch a hole in your shot.

### Troubleshooting

* **Phone says "This page needs HTTPS"** — you typed the address by hand. Use the QR
  link; it always starts with `https://` and port `8443`.
* **"Camera did not start: NotReadableError"** — another app owns the camera (Zoom,
  the Camera app, another tab). Close it and tap Start.
* **Nothing on air but the phone says LIVE** — read the box under the camera card in
  the panel. It names the fault in one line, and `GET /api/camera/live` gives the same
  answer as JSON. The usual cause is **two windows subscribed**: a phone serves exactly
  one viewer, so if the panel preview, a second browser tab and OBS all ask at once,
  only the first keeps the picture. Since v1.4 the OBS source always outranks the
  panel preview, the loser shows *"CAMERA IS IN ANOTHER WINDOW"* on the overlay
  instead of a silent black box, and closing the extra window recovers by itself.
* **"Camera connected, no picture"** — the phone is paired but sending no frames:
  unlock the phone and bring the browser back to the front. The overlay says so on
  screen rather than leaving a black rectangle.
* **Black frame, no error** — some networks block UDP between clients (guest wifi with
  client isolation). Put the phone and the streaming PC on the same router, or use
  a WHEP endpoint that relays.

### How the feed is assigned (why OBS wins)

Each overlay window identifies itself when it asks for the camera. The **OBS browser
source** has priority 0, the **panel preview** has priority 1. If a lower-priority
window already holds the feed and a higher-priority one asks, the feed moves to the
higher one and the other window is told why. Every offer, answer and ICE candidate is
delivered to the owning window only — early versions broadcast them, which let two
windows answer the same phone and left both black.
* **Certificate warning every time** — accept it for that address once; browsers
  remember per-host. Using the same USB/wifi address each time keeps it remembered.

## 9. Worship lyrics — the prompter

The words on screen, one line at a time, stepped by the operator.

1. Panel → **Worship lyrics**. Type the song title, paste the words into **Lines** —
   **one line per screen**, the way you want them to appear.
2. **Load lines.** They become a numbered list.
3. **Next line** (or **Alt + →**) puts the current line on air; each press advances.
   **Previous** / **Alt + ←** goes back. Clicking any line jumps straight to it, so a
   chorus you have already sung is one click away.
4. **Take down** clears the words; **Put on air** brings the current line back.

The overlay shows the title, the line, the **next line small underneath** (so you can
mouth along), and a dot per line so you can see where you are in the song. Two looks:
**lower band** (sits above the ticker, same geometry as the scripture band) or
**full frame** (large centred type over a dark wash — good for a hymn sing). Text size
is adjustable from 28 to 86 px.

**Save to library** keeps the song in `presets.json`. It comes back after a restart and
loads with one pick from the **Song** list; **Delete** removes it.

Lyrics and scripture never overlap: when a lyric line is on air, a verse is held back,
because two different sets of words on screen at once reads as a mistake.

### API

```
GET  /api/lyrics                      → saved songs + what is on air
POST /api/lyrics/save   {title, lines} → add or replace a song
POST /api/lyrics/delete {id}           → remove a song
```

Lines go on air through the normal state patch:
```
POST /api/state {"showLyrics":true,
                 "lyricSong":"Amazing Grace",
                 "lyricLines":["Amazing grace, how sweet the sound","That saved a wretch like me"],
                 "lyricIndex":0,
                 "lyricMode":"lower",     // lower | full
                 "lyricSize":46,
                 "lyricAlign":"left"}     // left | center
```

## 10. Bible — scripture on air in one click

The whole King James text (66 books, 1,189 chapters, 31,102 verses) ships **inside the
kit** as a 1.25 MB file. No internet, no Bible website, no API keys — a church hall with
no wifi still gets verses on screen.

### Put a verse on air

1. Panel → **Bible** card.
2. Type a reference — `John 3:16`, `ps 23`, `1cor 13:4-7`, or just `Genesis` — or search by
   words: `shepherd`, `fear not`, `grace`. A reference match is always listed first.
3. Click a result to preview it, then **Put on air**.

The reference chip, the verse text and the KJV label are all editable afterwards.

### Browsing the whole Bible

The card has a **Browse the whole Bible** row above the search box: pick a book, pick a
chapter, press **Open** and every verse of that chapter is listed. Click any verse to preview
it and put it on air. The count in the corner is measured from the file, not typed in:
**66 books · 1,189 chapters · 31,102 verses**.

Nothing is truncated. A chapter too long for one screen — Psalm 119 is 176 verses — is split
into parts, and the panel shows **‹ Back / Next ›** with `Part 1 of 12`. Arrow keys work too.
Every part is real scripture; the last part of Psalm 119 ends on verse 176.

An impossible reference is refused rather than quietly replaced: `Genesis 1:32` returns
*"Genesis 1 has 31 verses — there is no verse 32"* instead of silently showing verse 31.

### Looking up a passage, or searching for words

The box does both, and always tries the passage reading first. Type a book name and you get
that book, not the verses that happen to mention it:

| You type | You get |
|---|---|
| `Genesis`, `John`, `Romans`, `1 Corinthians` | the book, opening at chapter 1 |
| `John 3` | chapter 3 |
| `John 3:16`, `ps 23:1`, `rom 8:28-30` | that verse or range |
| `shepherd`, `fear not`, `love` | verses containing those words |

A passage match appears at the top of the list marked **passage**, with word matches
underneath — so `mark` gives you Mark 1 *and* the verses that mention a mark. Passages are
resolved on the server, which is why a book name works even though the word "Genesis" never
appears in the text itself.

### Everything it understands

| You type | You get |
|---|---|
| `John 3:16`, `john 3.16`, `Jn 3:16`, `John3:16` | John 3:16 |
| `Psalm 23`, `ps 23`, `psalm 23:1-6` | Psalms 23 (the correct canonical name) |
| `1 Cor 13:4-7`, `1cor 13:4-7`, `I Cor 13:4` | 1 Corinthians 13:4-7 |
| `ii tim 3:16`, `2nd Timothy 3:16` | 2 Timothy 3:16 |
| `rom 8:28 to 30` | Romans 8:28-30 |
| `John 3:16; Romans 8:1` | both, joined |
| `Genesis`, `Exodus`, `Revelation` | a book with no chapter number — chapter 1 |
| `shepherd`, `fear not`, `love` | word search, well-known verses first |

Ambiguous input is refused rather than guessed (`Genesis 51` tells you it does not exist).

### Three looks

* **Band** — sits above the ticker, over your live picture. The everyday choice.
* **Card** — centred panel, good for a quiet moment or an altar call.
* **Full** — the verse replaces the picture entirely, on a deep navy field or a picture.

Text auto-fits: a single verse renders large, a whole chapter steps down so nothing ever
spills off the frame. **Keep graphics** lets the lower third stay visible underneath.

### Twenty scripture backgrounds

The kit ships 20 broadcast plates in `scripture/` — mountains at dawn, a star field, ocean
dusk, a stone chapel, an autumn path, a church auditorium, plus clean gradients, bokeh,
linen and charcoal for when a photograph is too much. They load from disk, so this works
with no internet.

1. Panel → **Bible** card → **Background**.
2. Click any thumbnail. It appears behind the verse instantly, in all three looks.
3. **Darken behind text** (0–100%) sets how much scrim sits between the picture and the
   words. 55% is the default and is readable on every shipped plate.
4. **Text sits** — Top / Centre / Bottom, for the Full look. Pinning the words low leaves
   the sky clear; pinning them high leaves room for a band.
5. **Type** — Light (white) or Dark (charcoal). Picking the linen or paper plate switches
   this automatically.

None is a real choice: click **None** and you are back to the plain navy field.

Anything you have already uploaded also works as a plate — the panel accepts any
`/scripture/…` or `/uploads/…` path in `verseBg`.

### In the OBS dock

The dock has a scripture row: type the reference, press **↗** (or Enter) and it goes on
air; **Off** takes it down. The dock asks the server to resolve the text, so the plugin
stays small and the panel, dock and overlay always show the same verse.

### Reference API

```bash
curl "http://127.0.0.1:8770/api/bible/lookup?ref=John+3:16"
curl "http://127.0.0.1:8770/api/bible/lookup?ref=Psalms+119&part=3"   # long passages page
curl "http://127.0.0.1:8770/api/bible/chapter?book=Romans&chapter=8"  # verse by verse
curl "http://127.0.0.1:8770/api/bible/search?q=shepherd"
curl "http://127.0.0.1:8770/api/bible/books"                          # 66 books + chapter counts
curl "http://127.0.0.1:8770/api/bible/random"
```

Text is the **King James Version (1611)**, public domain in every country, which is why it
can be bundled. Other translations are copyrighted and are deliberately not included.

## 11. Run of show (playlist)

Turn a whole service into a click-free sequence.

1. Type a headline + kicker, set how many seconds it stays up, **Add to run of show**
2. **▶ Play** — the server walks the list, swapping the lower third automatically
3. **⏭ Next** to skip, **⏸ Stop** to hold, click any row to **cut to it instantly**

The timer lives on the server, so it keeps running if you close the panel tab, and the
OBS dock's **Next item** button drives the same list.

```bash
curl -X POST http://127.0.0.1:8770/api/playlist/start -d '{}'
curl -X POST http://127.0.0.1:8770/api/playlist/next
curl http://127.0.0.1:8770/api/playlist
```

## 12. My presets

Dial in a look (accent, fonts, copy, switches — everything) and **Save preset**. It is
written to `presets.json` on the server, so it follows you across browsers, phones and the
OBS dock, and survives restarts.

```bash
curl http://127.0.0.1:8770/api/presets
curl -X POST http://127.0.0.1:8770/api/presets/save \
     -H 'Content-Type: application/json' \
     -d '{"name":"Sunday 9am","data":{"accent":"#C9A227","headlineStyle":"serif"}}'
```

## 13. The OBS dock (plugin)

A native dock so you never leave OBS:

* text fields for headline / kicker / ticker / PIP labels
* on/off switches, accent picker, presets (including **Church**)
* **Add to scene** — inserts `NewsDesk Overlay` as a 1920×1080 browser source
* **Sting** and **Reload** buttons
* **Camera on / Cam off / PIP ⟷ Full** — moves a paired phone between the PIP box and
  the full frame without touching the phone
* **Scripture row** — type `John 3:16`, press Enter, it is on air
* link status dot (`● linked`) and a configurable server address

It talks to the same `server.py` over its HTTP API, so panel + dock + phone all agree.

### Building it

```bash
cd obs
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
```

Requirements: **OBS headers** (`libobs-dev` + `obs-frontend-api` on Linux, the OBS
source tree on Windows/macOS) and **Qt** — *matching the Qt major version of your OBS
build*. The CMakeLists picks Qt6 if available, else Qt5. OBS refuses to load a plugin
built against the wrong Qt major (`Skipping module … possible import conflicts`).

**Install**

* Linux: `sudo cp build/rundir/lib/obs-plugins/newsdesk.so /usr/lib/<arch>/obs-plugins/`
  and `sudo cp -r data/* /usr/share/obs/obs-plugins/newsdesk/`
* Windows: copy `newsdesk.dll` to `C:\Program Files\obs-studio\obs-plugins\64bit\`
* macOS: copy `newsdesk.so` into `OBS.app/Contents/PlugIns/`

Then restart OBS → **Docks → NewsDesk — On Air**.

A prebuilt Linux x86-64 binary built and tested against **OBS 30.2.3 / Qt 6** is in
`obs/install/` (drop-in `.so` + locale file) — see `obs/install/README.md`.

> Verified here in a real OBS instance: module loads, dock registers in **Docks**,
> Church preset pushes to the server, and the missing-browser-source guard appears
> when appropriate.

---

## 14. URL parameters (for Stream Deck / Companion / scripts)

Every setting is addressable, so a browser source or a hotkey can carry its own look:

```
/overlay/overlay.html?headline=HELLO&showPip=0&accent=%230A6CFF&logoText=WORLD%20NEWS
```

Useful keys: `headline`, `eyebrow`, `logoText`, `ticker` (pipe-separated),
`tkBrand`, `tkMeta`, `pipTag`, `pipSource`, `pipCredit`, `accent`, `accent2`,
`pipFill`, `headlineStyle=news|serif`, `brandIcon=n|cross|dot`, `demoPlate`,
`showLowerThird`, `showPip`, `showTicker`, `showClock`, `showBrand`, `alert`,
`guides`, `tickerSpeed`, `headlineMax`, `clock24`,
`poster`, `posterMode`, `ticker2`, `tk2Brand`, `ticker2Speed`, `countdown`, `countdownEndsAt`, `countdownLabel`,
`onAir`, `airStartedAt`, `pipVideo`, `showPipVideo`, `pipVideoLoop`, `pipVideoMuted`, `pipVideoFit`,
`songTitle`, `songArtist`, `talentName`, `talentRole`, `scoreHome`, `scoreAway`,
`logoImage`, `ltLogoImage`, `pipImage`, `bgImage`, `showBg`, `sponsorImage`, `showSponsor`,
`sponsorPos=br|bl|tr|tl`.

Boolean keys accept `1/0`. URL params always win over the saved state — handy for
locking a source to one look.

### HTTP API

```bash
curl -X POST http://127.0.0.1:8770/api/state \
     -H 'Content-Type: application/json' \
     -d '{"headline":"POWER RESTORED ACROSS THE CITY","eyebrow":"UPDATE"}'

curl -X POST "http://127.0.0.1:8770/api/sting?kind=wipe"
curl http://127.0.0.1:8770/api/state
```

`POST /api/state` merges any subset of the keys above and broadcasts to every overlay.
`POST /api/sting?kind=wipe|flash` fires a transition. `POST /api/reload` refreshes
all overlays.

---

## 15. Files

```
obs-news-desk/
├── server.py              zero-dependency control server (http + websocket)
├── camera.py              camera sessions, signalling relay, WHEP client, https listener
├── certgen.py             self-signed certificate generator (pure stdlib, no openssl)
├── qr.py                  QR code encoder + PNG writer (pure stdlib, no Pillow)
├── bible.py               reference parser + verse lookup (KJV)
├── bible/kjv.dat          the whole KJV, compressed (1.25 MB, public domain)
├── scripture/             20 background plates behind the verse (1920×1080)
│   └── thumbs/            340×191 previews for the panel picker
├── camera/index.html      the phone camera page (https, WebRTC sender)
├── state.json             saved on-air state
├── overlay/
│   ├── overlay.html       the graphics plate (transparent)
│   ├── overlay.css        all styling, 1920×1080
│   └── overlay.js         state engine, live link, ticker, auto-fit text
├── control/index.html     the control panel (single file)
├── presets.json           your saved looks
├── uploads/               media library — logos, slides, backgrounds (served at /uploads/…)
├── demo/demo.html         standalone demo, no server needed if opened with server
├── certs/                 generated on first run (self-signed, LAN only)
├── tests/                 signalling + end-to-end camera tests
├── obs/
│   ├── newsdesk.cpp       the OBS dock plugin
│   ├── CMakeLists.txt
│   ├── data/locale/       plugin locale strings
│   └── install/           prebuilt Linux .so (OBS 30 / Qt6)
├── assets/
│   ├── fonts/             Oswald, Barlow, Barlow Condensed, Playfair Display
│   └── img/               sample studio / guest / church plates
└── docs/INSTALL.md        longer walkthrough + troubleshooting
```

## 16. Fonts & licences

Oswald, Barlow, Barlow Condensed and Playfair Display are **SIL Open Font License 1.1**
— free for commercial broadcast use, bundled in `assets/fonts/`.
Sample video plates are AI-generated stand-ins; replace them with your own footage.

## 17. Good to know

* The overlay is a **browser source** — it costs some CPU/GPU. Keep it at 30 FPS and
  avoid stacking several; one plate is enough.
* OBS's browser is Chromium: CSS animations, custom fonts and `backdrop-filter` all work.
* Keep `server.py` running while you stream. If it stops, the overlay keeps its last
  state (graphics don't vanish) — you just can't change them until it's back.
* **The console stays quiet on purpose.** OBS's browser source and phones drop
  connections constantly; those are ignored instead of printing `ConnectionResetError`
  or `BrokenPipeError` tracebacks. Only page loads and real events appear in the window.
  If a traceback ever shows up, it is a genuine bug worth reporting.
* Everything also works **without** the plugin: OBS + browser source + panel page.

---

## Credits

**NewsDesk Studio** is built and maintained by **Emmanuel Suah**.

* Application, overlay, control panel, plugin and documentation — Emmanuel Suah
* Bible text — King James Version (1611), public domain
* Fonts — Oswald, Barlow, Barlow Condensed, Archivo Black, Playfair Display,
  all under the SIL Open Font License
* Reference layout — modelled on a broadcast news screenshot supplied as a design brief

Questions, fixes and feature requests: contact the maintainer.

"""
Tiny, dependency-free QR code encoder.

Why this exists: the camera page has to be opened on a phone, and typing
https://192.168.1.60:8443/cam on a phone keyboard while holding a phone is
miserable. So NewsDesk prints a QR code next to the URL. That code is generated
here with nothing but zlib (already in the stdlib) — no Pillow, no qrcode lib.

Scope: byte mode, versions 1–10, EC levels L and M, automatic mask selection.
That is far more than a LAN URL needs (a 40-character URL is a version 3-M).

Public API
    png_b64(text)          -> base64 PNG (drop straight into a data: URI)
    png(text, scale=8)     -> raw PNG bytes
    modules(text)          -> (size, [[bool, …], …]) for testing / ASCII art
"""

import zlib
import struct

# ---------------------------------------------------------------- GF(256) math

_EXP = [0] * 512
_LOG = [0] * 256


def _init_tables():
    x = 1
    for i in range(255):
        _EXP[i] = x
        _LOG[x] = i
        x <<= 1
        if x & 0x100:
            x ^= 0x11D
    for i in range(255, 512):
        _EXP[i] = _EXP[i - 255]


_init_tables()


def _mul(a, b):
    if a == 0 or b == 0:
        return 0
    return _EXP[_LOG[a] + _LOG[b]]


def _rs_generator(n):
    """Generator polynomial for n error-correction codewords."""
    g = [1]
    for i in range(n):
        ng = [0] * (len(g) + 1)
        for j in range(len(g)):
            ng[j] ^= g[j]
            ng[j + 1] ^= _mul(g[j], _EXP[i])
        g = ng
    return g


def _rs_remainder(data, n):
    g = _rs_generator(n)
    res = [0] * n
    for byte in data:
        factor = byte ^ res[0]
        res = res[1:] + [0]
        for i in range(n):
            res[i] ^= _mul(g[i + 1], factor)
    return res


# ------------------------------------------------------------------- tables

# (ec codewords per block, [(block count, data codewords per block), …])
_RS = {
    ("L", 1): (7, [(1, 19)]),
    ("L", 2): (10, [(1, 34)]),
    ("L", 3): (15, [(1, 55)]),
    ("L", 4): (20, [(1, 80)]),
    ("L", 5): (26, [(1, 108)]),
    ("L", 6): (18, [(2, 68)]),
    ("L", 7): (20, [(2, 78)]),
    ("L", 8): (24, [(2, 97)]),
    ("L", 9): (30, [(2, 116)]),
    ("L", 10): (18, [(2, 68), (2, 69)]),
    ("M", 1): (10, [(1, 16)]),
    ("M", 2): (16, [(1, 28)]),
    ("M", 3): (26, [(1, 44)]),
    ("M", 4): (18, [(2, 32)]),
    ("M", 5): (24, [(2, 43)]),
    ("M", 6): (16, [(4, 27)]),
    ("M", 7): (18, [(4, 31)]),
    ("M", 8): (22, [(2, 38), (2, 39)]),
    ("M", 9): (22, [(3, 36), (2, 37)]),
    ("M", 10): (26, [(4, 43), (1, 44)]),
}

_ALIGN = {
    1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30],
    6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50],
}

_VERSION_BITS = {  # BCH(18,6) version information, versions 7+
    7: 0x07C94, 8: 0x085BC, 9: 0x09A99, 10: 0x0A4D3,
}

_EC_BITS = {"L": 0b01, "M": 0b00, "Q": 0b11, "H": 0b10}


# ---------------------------------------------------------------- encoding

def _choose_version(nbytes, ec):
    for v in range(1, 11):
        if (ec, v) not in _RS:
            continue
        _ecc, groups = _RS[(ec, v)]
        capacity = sum(cnt * dcw for cnt, dcw in groups)
        # 4 bits mode + 8 bits length (versions 1–9) / 16 bits (10+)
        header = 12 if v < 10 else 20
        if capacity * 8 - header >= nbytes * 8:
            return v
    raise ValueError("text too long for this encoder (max ~200 bytes)")


def _data_codewords(text, version, ec):
    data = text.encode("utf-8")
    bits = []

    def push(val, n):
        for i in range(n - 1, -1, -1):
            bits.append((val >> i) & 1)

    push(0b0100, 4)                     # byte mode
    push(len(data), 8 if version < 10 else 16)
    for byte in data:
        push(byte, 8)

    _ecc, groups = _RS[(ec, version)]
    total = sum(cnt * dcw for cnt, dcw in groups)

    # terminator + pad to a byte boundary
    push(0, min(4, total * 8 - len(bits)))
    while len(bits) % 8:
        bits.append(0)

    words = [int("".join(str(b) for b in bits[i:i + 8]), 2) for i in range(0, len(bits), 8)]
    pad = (0xEC, 0x11)
    i = 0
    while len(words) < total:
        words.append(pad[i % 2])
        i += 1
    return words


def _interleave(words, version, ec):
    ecc_per_block, groups = _RS[(ec, version)]
    blocks, pos = [], 0
    for count, dcw in groups:
        for _ in range(count):
            blocks.append(words[pos:pos + dcw])
            pos += dcw

    eccs = [_rs_remainder(b, ecc_per_block) for b in blocks]

    out = []
    for i in range(max(len(b) for b in blocks)):
        for b in blocks:
            if i < len(b):
                out.append(b[i])
    for i in range(ecc_per_block):
        for e in eccs:
            out.append(e[i])
    return out


# ------------------------------------------------------------------ matrix

def _new_matrix(size):
    return [[None] * size for _ in range(size)]


def _place_finder(m, reserved, row, col):
    for r in range(-1, 8):
        for c in range(-1, 8):
            rr, cc = row + r, col + c
            if not (0 <= rr < len(m) and 0 <= cc < len(m)):
                continue
            reserved[rr][cc] = True
            if 0 <= r <= 6 and 0 <= c <= 6:
                on = (r in (0, 6) or c in (0, 6)) or (2 <= r <= 4 and 2 <= c <= 4)
                m[rr][cc] = 1 if on else 0
            else:
                m[rr][cc] = 0


def _place_alignment(m, reserved, version):
    centers = _ALIGN[version]
    for r in centers:
        for c in centers:
            # skip the three corners occupied by finders
            if (r == 6 and c == 6) or (r == 6 and c == centers[-1]) or (r == centers[-1] and c == 6):
                continue
            for dr in range(-2, 3):
                for dc in range(-2, 3):
                    rr, cc = r + dr, c + dc
                    reserved[rr][cc] = True
                    m[rr][cc] = 1 if max(abs(dr), abs(dc)) != 1 else 0


def _place_format(m, reserved, ec, mask):
    data = (_EC_BITS[ec] << 3) | mask
    rem = data << 10
    g = 0b10100110111
    for i in range(4, -1, -1):
        if rem & (1 << (i + 10)):
            rem ^= g << i
    bits = ((data << 10) | rem) ^ 0b101010000010010

    def bit(i):
        return (bits >> i) & 1

    # around the top-left finder
    for i in range(6):
        _set(m, reserved, i, 8, bit(i))
    _set(m, reserved, 7, 8, bit(6))
    _set(m, reserved, 8, 8, bit(7))
    _set(m, reserved, 8, 7, bit(8))
    for i in range(9, 15):
        _set(m, reserved, 8, 14 - i, bit(i))

    # mirrored copy
    size = len(m)
    for i in range(8):
        _set(m, reserved, 8, size - 1 - i, bit(i))
    for i in range(8, 15):
        _set(m, reserved, size - 15 + i, 8, bit(i))
    _set(m, reserved, size - 8, 8, 1)  # dark module


def _set(m, reserved, r, c, v):
    m[r][c] = v
    reserved[r][c] = True


def _place_version(m, reserved, version):
    if version < 7:
        return
    bits = _VERSION_BITS[version]
    size = len(m)
    for i in range(18):
        b = (bits >> i) & 1
        r, c = i // 3, i % 3
        _set(m, reserved, r, size - 11 + c, b)
        _set(m, reserved, size - 11 + c, r, b)


def _reserve(m, reserved, version):
    size = len(m)
    _place_finder(m, reserved, 0, 0)
    _place_finder(m, reserved, 0, size - 7)
    _place_finder(m, reserved, size - 7, 0)
    for i in range(8, size - 8):
        reserved[6][i] = True
        m[6][i] = 1 if i % 2 == 0 else 0
        reserved[i][6] = True
        m[i][6] = 1 if i % 2 == 0 else 0
    _place_alignment(m, reserved, version)
    for i in range(9):
        reserved[8][i] = True
        reserved[i][8] = True
    for i in range(size - 8, size):
        reserved[8][i] = True
        reserved[i][8] = True
    reserved[size - 8][8] = True


def _mask_bit(mask, r, c):
    if mask == 0:
        return (r + c) % 2 == 0
    if mask == 1:
        return r % 2 == 0
    if mask == 2:
        return c % 3 == 0
    if mask == 3:
        return (r + c) % 3 == 0
    if mask == 4:
        return (r // 2 + c // 3) % 2 == 0
    if mask == 5:
        return (r * c) % 2 + (r * c) % 3 == 0
    if mask == 6:
        return ((r * c) % 2 + (r * c) % 3) % 2 == 0
    return ((r + c) % 2 + (r * c) % 3) % 2 == 0


def _penalty(m):
    size = len(m)
    score = 0
    # rule 1: runs of five or more
    for line in list(m) + [list(col) for col in zip(*m)]:
        run, prev = 1, line[0]
        for v in line[1:]:
            if v == prev:
                run += 1
            else:
                if run >= 5:
                    score += 3 + (run - 5)
                run, prev = 1, v
        if run >= 5:
            score += 3 + (run - 5)
    # rule 2: 2×2 blocks
    for r in range(size - 1):
        for c in range(size - 1):
            if m[r][c] == m[r][c + 1] == m[r + 1][c] == m[r + 1][c + 1]:
                score += 3
    # rule 3: finder-like patterns
    pat1 = [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0]
    pat2 = pat1[::-1]
    for line in list(m) + [list(col) for col in zip(*m)]:
        for i in range(size - 10):
            seg = line[i:i + 11]
            if seg == pat1 or seg == pat2:
                score += 40
    # rule 4: dark/light balance
    dark = sum(sum(row) for row in m)
    pct = dark * 100.0 / (size * size)
    score += int(abs(pct - 50) / 5) * 10
    return score


def modules(text, ec="M"):
    """Return (size, matrix) where matrix[r][c] is 1 for a dark module."""
    version = _choose_version(len(text.encode("utf-8")), ec)
    size = version * 4 + 17

    codewords = _interleave(_data_codewords(text, version, ec), version, ec)
    bits = []
    for cw in codewords:
        for i in range(7, -1, -1):
            bits.append((cw >> i) & 1)

    base = _new_matrix(size)
    reserved = [[False] * size for _ in range(size)]
    _reserve(base, reserved, version)
    _place_version(base, reserved, version)

    # zig-zag fill, right to left in two-column pairs
    idx = 0
    col = size - 1
    upward = True
    filled = [[None] * size for _ in range(size)]
    while col > 0:
        if col == 6:  # skip the vertical timing column
            col -= 1
        rows = range(size - 1, -1, -1) if upward else range(size)
        for row in rows:
            for c in (col, col - 1):
                if not reserved[row][c]:
                    filled[row][c] = bits[idx] if idx < len(bits) else 0
                    idx += 1
        upward = not upward
        col -= 2

    best, best_score = None, None
    for mask in range(8):
        m = [row[:] for row in base]
        for r in range(size):
            for c in range(size):
                if filled[r][c] is not None:
                    v = filled[r][c]
                    if _mask_bit(mask, r, c):
                        v ^= 1
                    m[r][c] = v
        _place_format(m, [[True] * size for _ in range(size)], ec, mask)
        score = _penalty(m)
        if best_score is None or score < best_score:
            best, best_score = m, score
    return size, best


# ------------------------------------------------------------------- render

def png(text, scale=8, border=4, ec="M"):
    """Encode as a PNG: black modules on white, quiet zone included."""
    size, m = modules(text, ec)
    dim = (size + border * 2) * scale
    raw = bytearray()
    for y in range(dim):
        raw.append(0)  # filter: none
        my = y // scale - border
        for x in range(dim):
            mx = x // scale - border
            dark = 0 <= my < size and 0 <= mx < size and m[my][mx]
            raw.append(0 if dark else 255)

    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", dim, dim, 8, 0, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(bytes(raw), 9))
            + chunk(b"IEND", b""))


def png_b64(text, scale=8, ec="M"):
    import base64
    return base64.b64encode(png(text, scale, ec=ec)).decode("ascii")


def ascii_art(text, ec="M"):
    size, m = modules(text, ec)
    lines = []
    for row in m:
        lines.append("".join("██" if v else "  " for v in row))
    return "\n".join(lines)


if __name__ == "__main__":
    import sys
    print(ascii_art(sys.argv[1] if len(sys.argv) > 1 else "https://192.168.1.60:8443/cam"))

# Install walkthrough & troubleshooting

**NewsDesk Studio** — maintained by **Emmanuel Suah**.

> Prefer pictures? `docs/NewsDesk-Studio-Guide.pdf` is the illustrated step-by-step
> version of this document.

## Fastest path (no plugin)

1. `python server.py --open`
2. OBS → **Sources + → Browser**
   * URL `http://127.0.0.1:8770/overlay/overlay.html`
   * 1920 × 1080
   * Untick *Shutdown source when not visible*
3. Control from the panel.

That is a complete, shippable setup. The plugin is a convenience layer on top.

---

## Scene layout

Sources panel, top to bottom:

```
NewsDesk Overlay        ← the browser source (graphics, transparent)
GUEST CAM  (Crop/Pad)   ← 780×439 at 1044,168
ANCHOR CAM              ← full frame
```

If the guest feed must be **above** the overlay, don't — you'd cover the frame border.
Keep the overlay on top; the PIP hole is transparent so the lower source shows through.

### Crop/Pad recipe (second camera into the box)

1. Select the source → **Filters → + → Crop/Pad**
2. Tick **Relative**, then set:
   * Left `0`, Top `0`, Right `cx-780`, Bottom `cy-439`
     (e.g. a 1920×1080 source → Right `1140`, Bottom `641`)
3. In **Transform** (Ctrl+E on Windows), set Position `1044, 168`, Size `780 × 439`

Turn on **⌗ Guides** in the panel to see the exact hole while you line it up.

---

## Which Qt does my OBS use?

The plugin must be built against the **same Qt major** as OBS, or OBS logs
`Skipping module '…newsdesk.so' due to possible import conflicts` and ignores it.

* OBS 30.x official builds (Win/macOS/AppImage/Flatpak): **Qt 6**
* OBS 29.x and older: **Qt 5**
* Linux: check with `ldd /usr/bin/obs | grep -i qt`

The bundled CMakeLists auto-detects (`Qt6` preferred). To force one:

```bash
cmake -B build -DQt6_DIR=/usr/lib/x86_64-linux-gnu/cmake/Qt6   # or Qt5_DIR=…
```

## “Add to scene” says this build has no browser source

Your OBS was packaged without the browser source (Debian/Ubuntu do this). Fixes:

* Install the official **AppImage** or **Flatpak** build (both include it), or
* Add the browser source manually — the dialog prints the URL — or
* Keep using the overlay in a plain browser window captured with a Window Capture source.

## Overlay is blank / black in OBS

* Is `server.py` running? Open `http://127.0.0.1:8770/overlay/overlay.html` directly.
* Did you set the source to **1920 × 1080**? Smaller sizes scale the whole plate down.
* Check **Custom CSS** on the browser source is empty (the plugin sets
  `body{background:transparent;}` — that is fine, anything else may not be).
* Right-click the source → **Refresh cache of current page** after editing files.

## Ticker doesn't move

* `showTicker` must be on and the ticker field must not be empty.
* Very low `tickerSpeed` (under 40) looks frozen — try 80–160.
* In OBS, browser sources pause when hidden if *Shutdown source when not visible* is
  ticked **and** the scene isn't live; the overlay resumes on show.

## Text too big / clipped

The headline auto-fits between `headlineMin` (30 px) and `headlineMax` (56 px), then
scrolls sideways if it still overflows. Raise `headlineMax` in the panel if you want it
bigger, or shorten the headline.

## Church preset looks “too gold” / dark text

Light accents (gold, sand) automatically switch the chips to **dark text** for
contrast — that's deliberate, not a bug. Prefer white text? Pick a darker accent.

## Two overlays fighting

Every overlay shares one `state.json`. If you want two different looks at once
(e.g. a lower-third-only source and a full plate), give each browser source URL
parameters — URL params override the shared state.

## Recording with transparency

The browser source is already transparent over your scene; no green screen needed.
To export *just the graphics* (e.g. for an editor), open the overlay in Chrome and use
`?demo=0`, then capture the window with OBS's *Window Capture* + *Allow Transparency*.

---

## Uploads, slots and the media library

* Images land in `uploads/` and are served at `/uploads/<file>`. Nothing leaves your machine.
* Six slots can each hold an image: poster, brand logo, headline chip, PIP slate,
  background plate, sponsor mark. Open the picker by clicking a slot preview.
* Deleting a file from the library clears every slot that was pointing at it.
* **Background plate shows nothing?** It renders *behind* the transparent overlay, so if
  you use it, remove your camera source beneath it (or the plate is simply hidden by the
  camera). It is meant for title cards and interstitials.
* **Logo looks blurry or too big?** Brand logo is height-locked at 50 px; supply a
  transparent PNG around 2–4× that height for crispness. The headline chip is capped at
  250 × 104 px.
* **PIP slate only shows when nothing is composited there.** If a camera source sits in
  the PIP position it covers the slate — that is expected.
* If an upload fails, confirm `server.py` is running and the file is under 16 MB.
  Bigger files are rejected with **HTTP 413** and nothing is written to disk.
* **Uploading the same picture twice** does not make a second copy. The server
  fingerprints the bytes and hands back the existing URL (`"reused": true` in the
  response), so your library stays tidy. Rename the file first if you want two copies.
* **Screenshots get readable names.** Uploading `6015-636658.png` stores it as
  `20261030-161145.png` (the original timestamp looks like a typo); any other name is
  kept and suffixed with a short fingerprint (`hebrews-13a4f9.jpg`).
* Use a **wide** image (1920×1080 or 1920×900). *Bottom band* crops to the lower 470 px,
  *full frame* covers the whole screen.
* `uploads/sample-scripture.jpg` ships as a layout template.

## The console shows ConnectionResetError / BrokenPipeError

You are on an older `server.py`. Those tracebacks are just OBS's browser source
(or a phone) closing the socket — normal, never fatal — but they were noisy.
The current build catches them (`CONN_ERRORS`) and logs nothing.

Symptom to recognise:

```
ConnectionResetError: [WinError 10054] An existing connection was forcibly closed
BrokenPipeError: [WinError 10058] ...
```

To confirm you are running the fixed file, start it and look at the banner — every
silent disconnect after that prints nothing, while real events still log:

```
GET /
= upload matches /uploads/sample-scripture.jpg (reused)
↑ upload /uploads/church-crest-4a1c2e.png (8.2 KB)
```

Routine traffic to `/assets/`, `/api/`, `/ws`, `/uploads/` and `/favicon.ico` is
deliberately quiet. If a disconnect ever *does* print a traceback, that is a real bug —
copy it back here.

## Phone camera: the page won't open, or the phone won't allow the camera

Camera access requires a **secure origin**. A LAN IP over plain `http://` is not one,
which is why the camera page lives on its own https port.

| What you see | Cause | Fix |
|---|---|---|
| `ERR_CONNECTION_REFUSED` on `:8443` | server started with `--no-camera`, or the port is taken | restart without the flag; check the banner line `Phone camera …` |
| Certificate warning | self-signed cert, by design | **Advanced ▸ Proceed**. It is generated on your machine and covers only your LAN IP |
| “This page needs HTTPS” | address typed by hand without `https://` | use the QR code, or type `https://<ip>:8443/cam` |
| Portal opens the camera page in a browser that blocks camera | in-app browsers (Instagram, Messenger) deny camera | use Safari / Chrome directly — **Copy link** in the panel and paste it |
| `NotAllowedError` | permission denied | site settings on the phone → allow camera → reload |
| `NotReadableError` | camera busy in another app | close Zoom / Camera / other tabs |
| Page loads, “Start” does nothing | mixed-content block: page is https but the socket is on http | already handled — make sure you are on this build; the socket must be `ws://` on port 8770 |

### Video is on the phone but not in OBS

* Panel pill must read **1 live**, and **Camera on air** must be switched on.
* Check the area: **Inside PIP box** draws inside the PIP frame; **Full frame** covers
  the program and hides the PIP box.
* If the phone shows `LIVE` but the overlay stays black, the two ends cannot reach
  each other: guest wifi with **client isolation** blocks the peer-to-peer traffic.
  Same router, no isolation, or use a WHEP relay.
* OBS must have the overlay browser source visible; a hidden source with
  *Shutdown source when not visible* ticked will not decode video.

### The certificate keeps warning

Browsers remember a certificate per host **and port**. If your machine's IP changes
(new DHCP lease), the old warning returns. Use a static lease for the streaming PC, or
delete `certs/` and restart to regenerate (it re-reads the current IP).

### Ports being used

* `8770` — panel, overlay, websocket signalling, uploads
* `8443` — https camera page (change with `--cam-port`, disable with `--no-camera`)
* Windows Firewall: allow Python on **private** networks, or both ports stay invisible
  to the phone even though they work on the PC.

## The verse bar says “I could not find that reference”

The parser is strict about books that do not exist, and it refuses to guess when a
short name is ambiguous.

| Typed | Why it fails | Type instead |
|---|---|---|
| `Genesis 51` | Genesis has 50 chapters | `Genesis 50` |
| `John 99:1` | John has 21 chapters | `John 21` |
| `p 23` | `p` matches Psalms, Proverbs, Philippians… | `ps 23` |
| `2 Kings 3:99` | the chapter ends earlier | verse is clamped to the last one |

Common abbreviations work: `gn gen ex lv nm dt js jdg rt 1sm 1kgs 1ch ezr ne est jb ps
pr ec so is jr lm ez dn ho jl am ob jn mi na hk zp hg zc ml mt mk lk jn ac rm 1co 2co
gl ep ph cl 1th 2th 1tm 2tm tt phm hb jm 1pe 2pe 1jn 2jn 3jn jd rv`. Roman numerals and
ordinals work too: `ii tim 3:16`, `1st john 4:8`, `first corinthians 13`.

### The verse is on air but nothing shows

* **Keep graphics** off is normal; the verse hides the lower third and PIP on purpose so
  the words have room. Turn *Keep graphics* on to show both.
* Check **Look**: `Band` sits above the ticker, `Card` is centred, `Full` replaces the
  picture. If you are looking at the PIP box, a full-frame verse will not appear there.
* A verse with no text (`verseText` empty) is treated as “off”, even if the toggle is on.

### Searching words returns odd verses

Word search ranks famous references first and prefers short verses, but it is a plain
substring search over the KJV — it is not a concordance. Typing the reference is always
more precise.

### Can I add another translation?

Not out of the box. The KJV is public domain, which is why it can be shipped inside the
kit; modern translations (NIV, ESV, NKJV…) are copyrighted and cannot be redistributed.
You can paste any text into the verse fields by hand — the panel treats `verseText` as
plain text.

## Run of show doesn't advance

* The clock runs on the **server**, not the browser. Restarting `server.py` mid-run means
  pressing ▶ Play again.
* Each item needs a duration; `0` falls back to 8 seconds.
* `POST /api/playlist/start` returns `{"ok":false,"error":"playlist is empty"}` with no rows.

## Countdown keeps resetting

`countdown` is a **duration in seconds**, not a target time. Toggling `showCountdown` on
(or reloading the overlay) restarts the visual timer from that many seconds. For a fixed
start time, set it to the minutes remaining and leave it on, or re-arm it with the dock's
**Countdown 30m** button.

## Where did my custom presets go?

They live in `presets.json` next to `server.py`. Back up `presets.json`, `state.json` and
`uploads/` to move the entire station setup to another machine.

## Scripture backgrounds

The Bible card has a **Background** row with twenty plates that ship in `scripture/`. Click a
thumbnail and it appears behind the verse; **None** returns to the plain navy field.

| Symptom | Cause and fix |
|---|---|
| The picker is empty | `scripture/` is missing from the kit folder. It is not generated — restore it from the zip. |
| Plate chosen, verse still navy | The verse is not on air. Press **Put on air** — the background applies to the verse, not the panel. |
| Words disappear into a bright photograph | Raise **Darken behind text** to 70–80%. If it is a pale plate, switch **Type** to Dark. |
| Plate looks stretched | Plates are served at 1920×1080 and cropped to fill. Use a 16:9 picture if you add your own. |

Your own pictures work too: any file in `uploads/` can be used as a background from the panel.
